import { useState, useEffect, useRef, useCallback } from 'react';
import { calculateDistanceMeters, calculateBearing, isValidGpsUpdate } from '../utils/navigationService';

/**
 * High-Accuracy Browser Geolocation Hook
 * Handles browser permissions, continuous watch tracking, error states,
 * noise filtering, heading calculation, and lifecycle cleanup.
 */
export function useGeolocation(options = {}) {
  const {
    enableHighAccuracy = true,
    timeout = 10000,
    maximumAge = 3000,
    autoStart = false,
    minDistanceThresholdMeters = 2.5
  } = options;

  const [userLocation, setUserLocation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [errorCode, setErrorCode] = useState(null);
  const [isTracking, setIsTracking] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState('prompt');

  const watchIdRef = useRef(null);
  const prevLocationRef = useRef(null);

  // Parse GeolocationPositionError to user-friendly messages
  const parseGeolocationError = useCallback((err) => {
    let msg = 'Unable to retrieve GPS location.';
    let code = 'UNKNOWN_ERROR';

    if (err.code === 1) { // PERMISSION_DENIED
      code = 'PERMISSION_DENIED';
      msg = 'Location permission was denied. Please allow location access in your browser settings to enable GPS navigation.';
    } else if (err.code === 2) { // POSITION_UNAVAILABLE
      code = 'POSITION_UNAVAILABLE';
      msg = 'GPS signal is currently unavailable. Please verify device location/GPS is enabled.';
    } else if (err.code === 3) { // TIMEOUT
      code = 'TIMEOUT';
      msg = 'GPS location request timed out. Retrying satellite lock...';
    } else if (typeof window !== 'undefined' && window.isSecureContext === false) {
      code = 'INSECURE_CONTEXT';
      msg = 'Geolocation requires a secure context (HTTPS or localhost).';
    }

    return { message: msg, code };
  }, []);

  // Check initial permission status if Permissions API is supported
  useEffect(() => {
    if (typeof navigator !== 'undefined' && navigator.permissions && navigator.permissions.query) {
      navigator.permissions.query({ name: 'geolocation' })
        .then((status) => {
          setPermissionStatus(status.state);
          status.onchange = () => setPermissionStatus(status.state);
        })
        .catch(() => {
          // Permissions API query not supported on some mobile browsers
        });
    }
  }, []);

  // Process raw GPS position with smoothing and heading calculation
  const handlePositionSuccess = useCallback((pos) => {
    setLoading(false);
    setError(null);
    setErrorCode(null);

    const { latitude, longitude, accuracy, heading, speed, altitude } = pos.coords;
    const timestamp = pos.timestamp || Date.now();

    const newLoc = {
      latitude,
      longitude,
      accuracy: Math.round(accuracy || 10),
      heading: heading !== null && !isNaN(heading) ? heading : null,
      speed: speed !== null && !isNaN(speed) ? Math.max(0, speed * 3.6) : 0, // Convert m/s to km/h
      altitude: altitude !== null ? Math.round(altitude) : null,
      timestamp
    };

    const prev = prevLocationRef.current;

    // Filter out unrealistic GPS teleport jumps
    if (prev && !isValidGpsUpdate(newLoc, prev)) {
      console.warn("Filtered out anomalous GPS jump:", newLoc);
      return;
    }

    // If device doesn't provide heading, compute bearing from previous point
    if (newLoc.heading === null && prev) {
      const movedDist = calculateDistanceMeters(prev.latitude, prev.longitude, latitude, longitude);
      if (movedDist >= minDistanceThresholdMeters) {
        newLoc.heading = Math.round(calculateBearing(prev.latitude, prev.longitude, latitude, longitude));
      } else {
        newLoc.heading = prev.heading || 0;
      }
    }

    // Ignore tiny jitter movements (< minDistanceThresholdMeters) if accuracy is moderate
    if (prev) {
      const movedDist = calculateDistanceMeters(prev.latitude, prev.longitude, latitude, longitude);
      if (movedDist < minDistanceThresholdMeters && Math.abs((newLoc.accuracy || 10) - (prev.accuracy || 10)) < 5) {
        return; // Don't trigger unnecessary re-render on negligible stationary jitter
      }
    }

    prevLocationRef.current = newLoc;
    setUserLocation(newLoc);
  }, [minDistanceThresholdMeters]);

  const handlePositionError = useCallback((err) => {
    setLoading(false);
    const parsed = parseGeolocationError(err);
    setError(parsed.message);
    setErrorCode(parsed.code);
  }, [parseGeolocationError]);

  // Request a single fresh GPS position
  const getCurrentLocation = useCallback(() => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      setErrorCode('NOT_SUPPORTED');
      return Promise.reject(new Error('Geolocation not supported'));
    }

    setLoading(true);
    setError(null);

    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          handlePositionSuccess(pos);
          resolve(pos);
        },
        (err) => {
          handlePositionError(err);
          reject(err);
        },
        {
          enableHighAccuracy,
          timeout,
          maximumAge
        }
      );
    });
  }, [enableHighAccuracy, timeout, maximumAge, handlePositionSuccess, handlePositionError]);

  // Continuous watchPosition tracking
  const startTracking = useCallback(() => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      setErrorCode('NOT_SUPPORTED');
      return;
    }

    if (watchIdRef.current !== null) {
      return; // Already tracking
    }

    setLoading(true);
    setIsTracking(true);
    setError(null);

    // Initial instant fix
    navigator.geolocation.getCurrentPosition(
      (pos) => handlePositionSuccess(pos),
      (err) => handlePositionError(err),
      { enableHighAccuracy, timeout: 6000, maximumAge: 1000 }
    );

    // Start continuous watcher
    watchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => handlePositionSuccess(pos),
      (err) => handlePositionError(err),
      {
        enableHighAccuracy,
        timeout,
        maximumAge
      }
    );
  }, [enableHighAccuracy, timeout, maximumAge, handlePositionSuccess, handlePositionError]);

  // Stop tracking and clean up watcher
  const stopTracking = useCallback(() => {
    if (watchIdRef.current !== null && typeof navigator !== 'undefined' && navigator.geolocation) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setIsTracking(false);
    setLoading(false);
  }, []);

  // Auto-start if requested
  useEffect(() => {
    if (autoStart) {
      startTracking();
    }
    return () => {
      stopTracking();
    };
  }, [autoStart, startTracking, stopTracking]);

  return {
    userLocation,
    loading,
    error,
    errorCode,
    isTracking,
    permissionStatus,
    getCurrentLocation,
    startTracking,
    stopTracking
  };
}
