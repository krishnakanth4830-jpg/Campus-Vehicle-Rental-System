import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { BookingProvider, useBooking } from './context/BookingContext';
import { NotificationProvider } from './context/NotificationContext';

import { Navbar } from './components/common/Navbar';
import { Home } from './pages/public/Home';
import { Dashboard } from './pages/student/Dashboard';
import { Login } from './pages/public/Login';
import { Register } from './pages/public/Register';
import { ForgotPasswordPage } from './pages/public/ForgotPasswordPage';
import { VehicleCatalog } from './pages/student/VehicleCatalog';
import { RecommendationWizard } from './pages/student/RecommendationWizard';
import { ActiveRental } from './pages/student/ActiveRental';
import { MyBookings } from './pages/student/MyBookings';
import { EcoScore } from './pages/student/EcoScore';
import { EmergencyBoard } from './pages/student/EmergencyBoard';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { OwnerDashboard } from './pages/owner/OwnerDashboard';
import { StaffDashboard } from './pages/staff/StaffDashboard';
import { LiveGPSPage } from './pages/student/LiveGPSPage';
import { AICopilotPage } from './pages/student/AICopilotPage';
import BikeLookupPage from './pages/student/BikeLookupPage';
import SecurityDashboardPage from './pages/admin/SecurityDashboardPage';
import { FloatingAICopilot } from './components/ai/FloatingAICopilot';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { SplashScreen } from './components/common/SplashScreen';

function AppContent() {
  const { user, isAuthenticated, isAdmin, isOwner, isStaff, isStudent } = useAuth();
  const { activeBooking } = useBooking();
  const [showSplash, setShowSplash] = useState(true);

  // Initial tab based on authenticated role
  const getDefaultTabForRole = () => {
    if (isAdmin) return 'admin-dashboard';
    if (isStaff) return 'staff-dashboard';
    if (isOwner) return 'owner-dashboard';
    return 'dashboard';
  };

  const [currentTab, setTab] = useState(getDefaultTabForRole);

  // Sync default dashboard when authentication changes
  useEffect(() => {
    if (isAuthenticated) {
      if (isAdmin && (currentTab === 'dashboard' || currentTab === 'login')) {
        setTab('admin-dashboard');
      } else if (isStaff && (currentTab === 'dashboard' || currentTab === 'login')) {
        setTab('staff-dashboard');
      } else if (isOwner && (currentTab === 'dashboard' || currentTab === 'login')) {
        setTab('owner-dashboard');
      } else if (isStudent && (currentTab === 'admin-dashboard' || currentTab === 'staff-dashboard' || currentTab === 'owner-dashboard' || currentTab === 'login')) {
        setTab('dashboard');
      }
    }
  }, [isAuthenticated, user?.role]);

  // Main role home rendering helper
  const renderHomeDashboard = () => {
    if (isAdmin) return <AdminDashboard setTab={setTab} />;
    if (isStaff) return <StaffDashboard setTab={setTab} />;
    if (isOwner) return <OwnerDashboard setTab={setTab} />;
    return <Dashboard setTab={setTab} />;
  };

  return (
    <div className="min-h-screen bg-campus-cream flex flex-col font-sans relative">
      {/* High-Tech Futuristic Splash Screen */}
      {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} />}

      <Navbar currentTab={currentTab} setTab={setTab} />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {(currentTab === 'dashboard' || currentTab === 'home') && renderHomeDashboard()}
        
        {/* Student Specific Views */}
        {currentTab === 'vehicles' && <VehicleCatalog setTab={setTab} />}
        {currentTab === 'recommendation' && <RecommendationWizard setTab={setTab} />}
        {currentTab === 'active-rental' && <ActiveRental setTab={setTab} />}
        {currentTab === 'my-bookings' && <MyBookings setTab={setTab} />}
        {currentTab === 'eco-score' && <EcoScore />}
        {currentTab === 'emergency-rides' && <EmergencyBoard />}

        {/* Dedicated Role Dashboards */}
        {currentTab === 'owner-dashboard' && <OwnerDashboard setTab={setTab} />}
        {currentTab === 'staff-dashboard' && <StaffDashboard setTab={setTab} />}
        {currentTab === 'admin-dashboard' && <AdminDashboard setTab={setTab} />}
        {currentTab === 'security-dashboard' && <SecurityDashboardPage setTab={setTab} />}

        {/* Global Shared Views */}
        {currentTab === 'live-gps' && <LiveGPSPage setTab={setTab} />}
        {currentTab === 'ai-copilot' && <AICopilotPage setTab={setTab} />}
        {currentTab === 'bike-lookup' && <BikeLookupPage setTab={setTab} />}
        {currentTab === 'login' && <Login setTab={setTab} />}
        {currentTab === 'register' && <Register setTab={setTab} />}
        {currentTab === 'forgot-password' && <ForgotPasswordPage setTab={setTab} />}
      </main>

      {/* Floating Global AI Assistant Orb */}
      <FloatingAICopilot setTab={setTab} />

      {/* Campus Mobility Footer */}
      <footer className="bg-campus-forest text-white py-8 border-t border-campus-emerald/40 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-left">
            <div className="font-extrabold text-sm font-display tracking-wide flex items-center justify-center sm:justify-start gap-2">
              <img src="/campus-mobility-logo.jpg" alt="Campus Mobility" className="w-5 h-5 rounded-full object-contain border border-emerald-400/40" />
              <span>CAMPUS MOBILITY • SMART VEHICLE RENTAL & TRACKING</span>
            </div>
            <p className="text-gray-300 text-[11px]">
              Clean Micro-Transit, Real-Time GPS Telemetry, Return-to-Pool & Campus Ride Pass
            </p>
          </div>

          <div className="text-center sm:text-right text-[11px] text-gray-300">
            <div>Emergency Campus Mobility Security: <strong>+91 98765 43210</strong></div>
            <div className="text-campus-mint font-semibold mt-0.5">Zero-Emission Campus • Green Mobility Initiative</div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <BookingProvider>
          <NotificationProvider>
            <AppContent />
          </NotificationProvider>
        </BookingProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}

export default App;
