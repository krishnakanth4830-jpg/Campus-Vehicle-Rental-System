// Central API Client with JWT authorization and robust error handling
const API_BASE = import.meta.env.VITE_API_URL ? import.meta.env.VITE_API_URL.replace(/\/$/, '') : '/api';

export async function apiRequest(endpoint, options = {}) {
  const token = localStorage.getItem('campus_mobility_token');
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
    ...options.headers
  };

  if (options.body instanceof FormData) {
    delete headers['Content-Type'];
  }

  try {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers
    });

    const text = await res.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      if (res.status >= 500 || res.status === 404 || res.status === 502 || res.status === 504) {
        return {
          success: false,
          status: res.status,
          message: 'Backend server is not running on port 5000. Please start the backend (python backend/app.py or double-click run-all.bat).'
        };
      }
      return { success: false, status: res.status, message: text || 'Server returned an invalid response' };
    }

    if (!res.ok) {
      if (res.status === 401 && !endpoint.includes('/auth/login')) {
        localStorage.removeItem('campus_mobility_token');
        localStorage.removeItem('campus_mobility_user');
      }
      return { success: false, status: res.status, message: data.message || 'Request failed', ...data };
    }

    return { success: true, ...data };
  } catch (err) {
    console.error(`API Error on ${endpoint}:`, err);
    return {
      success: false,
      message: 'Network connection error. Please ensure the Python Flask backend is running on http://localhost:5000.'
    };
  }
}

export const api = {
  get: (url, config = {}) => {
    let endpoint = url;
    if (config.params) {
      const searchParams = new URLSearchParams();
      Object.entries(config.params).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') searchParams.append(k, v);
      });
      const qs = searchParams.toString();
      if (qs) endpoint += (endpoint.includes('?') ? '&' : '?') + qs;
    }
    return apiRequest(endpoint, { method: 'GET', ...config }).then(res => ({ data: res, ...res }));
  },
  post: (url, data, config = {}) => {
    const isFormData = data instanceof FormData;
    return apiRequest(url, {
      method: 'POST',
      body: isFormData ? data : (data ? JSON.stringify(data) : undefined),
      ...config
    }).then(res => ({ data: res, ...res }));
  },
  put: (url, data, config = {}) => {
    const isFormData = data instanceof FormData;
    return apiRequest(url, {
      method: 'PUT',
      body: isFormData ? data : (data ? JSON.stringify(data) : undefined),
      ...config
    }).then(res => ({ data: res, ...res }));
  },
  patch: (url, data, config = {}) => {
    const isFormData = data instanceof FormData;
    return apiRequest(url, {
      method: 'PATCH',
      body: isFormData ? data : (data ? JSON.stringify(data) : undefined),
      ...config
    }).then(res => ({ data: res, ...res }));
  },
  delete: (url, config = {}) => {
    return apiRequest(url, { method: 'DELETE', ...config }).then(res => ({ data: res, ...res }));
  }
};

export default api;

