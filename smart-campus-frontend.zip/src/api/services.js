import api from './client';

// 1. Auth Services
export const authApi = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  forgotPassword: (data) => api.post('/auth/forgot-password', data),
  getMe: () => api.get('/auth/me'),
  updateProfile: (data) => api.put('/auth/profile', data),
  changePassword: (data) => api.put('/auth/change-password', data),
};

// 2. Zone Services
export const zoneApi = {
  getAllZones: () => api.get('/zones'),
  getZoneDetail: (id) => api.get(`/zones/${id}`),
};

// 3. Vehicle Services
export const vehicleApi = {
  getVehicles: (params) => api.get('/vehicles', { params }),
  getVehicleDetail: (id) => api.get(`/vehicles/${id}`),
  getVehicleTypes: () => api.get('/vehicles/types'),
  getRecommendations: (data) => api.post('/vehicles/recommend', data),
};

// 4. Booking Services
export const bookingApi = {
  getQuote: (data) => api.post('/bookings/quote', data),
  createBooking: (data) => api.post('/bookings', data),
  getMyBookings: () => api.get('/bookings/my'),
  getBookingDetail: (id) => api.get(`/bookings/${id}`),
  cancelBooking: (id) => api.post(`/bookings/${id}/cancel`),
};

// 5. Rental & QR Services
export const rentalApi = {
  scanToStart: (data) => api.post('/rentals/scan-start', data),
  uploadConditionReport: (formData) => {
    // If formData is FormData instance, send as multipart/form-data
    const isFormData = formData instanceof FormData;
    return api.post('/rentals/condition-report', formData, {
      headers: isFormData ? { 'Content-Type': 'multipart/form-data' } : {},
    });
  },
  scanToReturn: (data) => api.post('/rentals/scan-return', data),
};

// 6. Eco & Sustainability Services
export const ecoApi = {
  getStats: () => api.get('/eco/stats'),
};

// 7. Ride Request Services
export const rideApi = {
  getRequests: () => api.get('/ride-requests'),
  createRequest: (data) => api.post('/ride-requests', data),
  acceptRequest: (id) => api.post(`/ride-requests/${id}/accept`),
  resolveRequest: (id) => api.post(`/ride-requests/${id}/resolve`),
};

// 8. Notification Services
export const notificationApi = {
  getNotifications: () => api.get('/notifications'),
  markAsRead: (id) => api.put(`/notifications/${id}/read`),
  markAllAsRead: () => api.put('/notifications/read-all'),
};

// 9. Review Services
export const reviewApi = {
  createReview: (data) => api.post('/reviews', data),
  getVehicleReviews: (vehicleId) => api.get(`/reviews/vehicle/${vehicleId}`),
};

// 10. Admin Services
export const adminApi = {
  getDashboard: () => api.get('/admin/dashboard'),
  getHeatmap: () => api.get('/admin/analytics/heatmap'),
  getPeakHours: () => api.get('/admin/analytics/peak-hours'),
  getUsers: () => api.get('/admin/users'),
  updateUserStatus: (id, status) => api.put(`/admin/users/${id}/status`, { status }),
  createVehicle: (data) => api.post('/admin/vehicles', data),
  updateVehicle: (id, data) => api.put(`/admin/vehicles/${id}`, data),
  updateBattery: (id, data) => api.put(`/admin/vehicles/${id}/battery`, data),
  deleteVehicle: (id) => api.delete(`/admin/vehicles/${id}`),
  createZone: (data) => api.post('/admin/zones', data),
  updateZone: (id, data) => api.put(`/admin/zones/${id}`, data),
  deleteZone: (id) => api.delete(`/admin/zones/${id}`),
  getDamageReports: () => api.get('/admin/damage-reports'),
  reviewDamageReport: (id, data) => api.put(`/admin/damage-reports/${id}/review`, data),
  getMaintenanceRecords: () => api.get('/admin/maintenance'),
  createMaintenance: (data) => api.post('/admin/maintenance', data),
  updateMaintenance: (id, data) => api.put(`/admin/maintenance/${id}`, data),
  getPricingRules: () => api.get('/admin/pricing'),
  updatePricingRule: (id, data) => api.put(`/admin/pricing/${id}`, data),
  getAllBookings: () => api.get('/admin/bookings'),
  getAuditLogs: () => api.get('/admin/audit-logs'),
};

// 11. Security & Verification Services
export const securityApi = {
  getRenterStatus: () => api.get('/security/renter/status'),
  submitRenterVerification: (data) => api.post('/security/renter/submit', data),
  listRenterVerifications: (params) => api.get('/security/renter/list', { params }),
  reviewRenterVerification: (id, data) => api.post(`/security/renter/review/${id}`, data),
  getOwnerProfile: (params) => api.get('/security/owner/profile', { params }),
  submitOwnerProfile: (data) => api.post('/security/owner/submit', data),
  listOwnerProfiles: () => api.get('/security/owner/list'),
  lookupBike: (identifier) => api.get(`/security/bike-lookup/${identifier}`),
  listLookupBikes: () => api.get('/security/bike-lookup'),
  checkin: (data) => api.post('/security/checkin', data),
  checkout: (data) => api.post('/security/checkout', data),
  createIncident: (data) => api.post('/security/incidents', data),
  listIncidents: (params) => api.get('/security/incidents', { params }),
  resolveIncident: (id, data) => api.post(`/security/incidents/${id}/resolve`, data),
  getDashboardStats: () => api.get('/security/dashboard-stats'),
  getAuditLogs: (params) => api.get('/security/audit-logs', { params }),
  toggleUserSuspension: (id, data) => api.post(`/security/user/${id}/suspend`, data),
  toggleBikeSuspension: (id, data) => api.post(`/security/bike/${id}/suspend`, data),
};

