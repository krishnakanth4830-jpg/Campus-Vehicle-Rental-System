import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { useBooking } from '../../context/BookingContext';
import { VehicleQRDisplayModal } from '../../components/qr/VehicleQRDisplayModal';
import { 
  Building2, Bike, Zap, Plus, Trash2, QrCode, 
  DollarSign, Activity, Wrench, RefreshCw, CheckCircle2, 
  AlertTriangle, MapPin, ShieldCheck, ArrowRight, Fuel,
  CreditCard, Calendar, User, FileText, CheckSquare, Sparkles, Navigation
} from 'lucide-react';
import { VehicleVisual } from '../../components/common/VehicleVisual';

export function OwnerDashboard({ setTab }) {
  const { user } = useAuth();
  const { zones } = useBooking();
  const [metrics, setMetrics] = useState(null);
  const [fleet, setFleet] = useState([]);
  const [vehicleTypes, setVehicleTypes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('fleet'); // fleet, earnings, maintenance, profile

  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedQRVehicle, setSelectedQRVehicle] = useState(null);
  const [deletingId, setDeletingId] = useState(null);

  const [newVehicle, setNewVehicle] = useState({
    vehicle_number: '',
    type_id: 1,
    brand: 'TVS (Hosur TN Plant)',
    model: 'Jupiter 125 Disc Petrol',
    hourly_rate: 25.0,
    current_zone_id: 1,
    fuel_type: 'PETROL',
    engine_cc: 125,
    mileage_kmpl: 50.0,
    fuel_capacity_litres: 5.1,
    fuel_level_percentage: 90,
    image_url: ''
  });

  const loadOwnerData = async () => {
    setLoading(true);
    try {
      const [mRes, fRes, vtRes] = await Promise.all([
        apiRequest('/owner/metrics'),
        apiRequest('/owner/fleet'),
        apiRequest('/vehicles/types')
      ]);

      if (mRes.success) setMetrics(mRes.metrics);
      if (fRes.success) setFleet(fRes.vehicles);
      if (vtRes.success) setVehicleTypes(vtRes.types);
    } catch (err) {
      console.error('Failed to load owner data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOwnerData();
  }, []);

  const handleAddVehicle = async (e) => {
    e.preventDefault();
    const res = await apiRequest('/owner/vehicles', {
      method: 'POST',
      body: JSON.stringify(newVehicle)
    });

    if (res.success) {
      setShowAddModal(false);
      setNewVehicle({
        vehicle_number: '',
        type_id: 1,
        brand: 'TVS (Hosur TN Plant)',
        model: 'Jupiter 125 Disc Petrol',
        hourly_rate: 25.0,
        current_zone_id: 1,
        fuel_type: 'PETROL',
        engine_cc: 125,
        mileage_kmpl: 50.0,
        fuel_capacity_litres: 5.1,
        fuel_level_percentage: 90,
        image_url: ''
      });
      loadOwnerData();
    } else {
      alert(res.message || 'Failed to deploy vehicle');
    }
  };

  const handleAutoGenerateReg = async () => {
    try {
      const res = await apiRequest('/vehicles/generate-reg-number');
      if (res.success && res.registration_number) {
        setNewVehicle(prev => ({ ...prev, vehicle_number: res.registration_number }));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateStatus = async (vehId, newStatus) => {
    await apiRequest(`/owner/vehicles/${vehId}`, {
      method: 'PATCH',
      body: JSON.stringify({ status: newStatus })
    });
    loadOwnerData();
  };

  const handleRemoveVehicle = async (vehId, vehNumber) => {
    if (!window.confirm(`Are you sure you want to remove vehicle ${vehNumber} from your campus fleet?`)) {
      return;
    }

    setDeletingId(vehId);
    const res = await apiRequest(`/owner/vehicles/${vehId}`, {
      method: 'DELETE'
    });
    setDeletingId(null);

    if (res.success) {
      loadOwnerData();
    } else {
      alert(res.message || 'Could not remove vehicle.');
    }
  };

  // Mock sample customer rental usage history on owner's vehicles
  const rentalLogs = [
    {
      id: 'L-101',
      vehicle_model: 'TVS Jupiter 125 Disc',
      vehicle_number: 'TN-38-SC-101',
      student_name: 'Karthik Subramanian',
      student_id: 'CS2023-8819',
      duration_hours: 2.5,
      earned_amount: 62.50,
      date: 'Today, 11:30 AM',
      status: 'COMPLETED',
      pickup_hub: 'PSG Tech Main Gate'
    },
    {
      id: 'L-102',
      vehicle_model: 'Royal Enfield Hunter 350',
      vehicle_number: 'TN-01-CR-401',
      student_name: 'Ananya Ramachandran',
      student_id: 'IITM-2023-4412',
      duration_hours: 4.0,
      earned_amount: 200.00,
      date: 'Yesterday, 3:15 PM',
      status: 'COMPLETED',
      pickup_hub: 'IIT Madras Gajendra Circle'
    },
    {
      id: 'L-103',
      vehicle_model: 'Yamaha FZ-S Fi V4',
      vehicle_number: 'TN-07-BK-203',
      student_name: 'Sanjay Maran',
      student_id: 'NITT-2024-1092',
      duration_hours: 1.5,
      earned_amount: 52.50,
      date: '02 Sep 2026, 9:00 AM',
      status: 'COMPLETED',
      pickup_hub: 'NIT Trichy Octagon'
    },
    {
      id: 'L-104',
      vehicle_model: 'TVS Raider 125 Sport',
      vehicle_number: 'TN-70-BK-201',
      student_name: 'Deepa Sundaram',
      student_id: 'STU-2026-909',
      duration_hours: 3.0,
      earned_amount: 90.00,
      date: '01 Sep 2026, 4:45 PM',
      status: 'COMPLETED',
      pickup_hub: 'PSG Tech Hostel Gate'
    }
  ];

  const totalRevenue = metrics?.total_revenue || 405.00;
  const platformFee = totalRevenue * 0.05;
  const netEarnings = totalRevenue - platformFee;

  return (
    <div className="space-y-6 pb-20">
      
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-campus-forest to-slate-950 text-white p-6 sm:p-8 rounded-3xl shadow-xl border border-campus-mint/30 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-campus-mint to-campus-emerald text-campus-forest font-extrabold text-2xl flex items-center justify-center shadow-lg border border-white/20 shrink-0">
            <Building2 className="w-7 h-7 text-campus-forest" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-campus-mint/20 text-campus-mint border border-campus-mint/40">
                VERIFIED VEHICLE HOST & FLEET OPERATOR
              </span>
              <span className="text-[11px] text-gray-300 font-mono">CODE: OWN-2026-0001</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold font-display tracking-tight text-white">
              Vehicle Owner & Fleet Management Portal
            </h1>
            <p className="text-xs text-gray-300">
              Host: <strong>{user?.name || 'Kovai & Tamil Nadu Mobility Fleet Operator'}</strong> • Direct Campus Payouts Active
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 self-start md:self-auto">
          <button
            onClick={loadOwnerData}
            className="p-2.5 bg-white/10 hover:bg-white/20 rounded-2xl transition font-bold"
            title="Refresh"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 bg-campus-gold hover:bg-amber-400 text-campus-forest rounded-2xl text-xs font-extrabold shadow-lg transition flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>+ List New Vehicle</span>
          </button>
        </div>
      </div>

      {/* 2. Owner KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">My Listed Vehicles</span>
            <Bike className="w-4 h-4 text-campus-forest" />
          </div>
          <div className="text-2xl font-extrabold text-campus-forest font-display">{metrics?.total_vehicles || fleet.length || 20}</div>
          <div className="text-[11px] text-campus-emerald font-semibold">
            {metrics?.available_vehicles || 18} Ready for Student Booking
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Active Customer Rentals</span>
            <Activity className="w-4 h-4 text-blue-600 animate-pulse" />
          </div>
          <div className="text-2xl font-extrabold text-blue-600 font-display">{metrics?.in_use_vehicles || 2}</div>
          <div className="text-[11px] text-gray-500 font-semibold">
            {metrics?.utilization_pct || 15}% Fleet Utilization
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Gross Tariff Collected</span>
            <DollarSign className="w-4 h-4 text-campus-gold" />
          </div>
          <div className="text-2xl font-extrabold text-campus-forest font-display">
            ₹{totalRevenue.toFixed(2)}
          </div>
          <div className="text-[11px] text-campus-emerald font-semibold">
            ₹{netEarnings.toFixed(2)} Net Payout (95%)
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Maintenance & Service</span>
            <Wrench className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-extrabold text-amber-600 font-display">{metrics?.maintenance_vehicles || 1}</div>
          <div className="text-[11px] text-gray-500 font-semibold">Routine Service Hub</div>
        </div>

      </div>

      {/* 3. Navigation Sub-Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 text-xs font-bold">
        {[
          { id: 'fleet', label: `🚲 My Listed Fleet (${fleet.length || 20})` },
          { id: 'earnings', label: `💰 Customer Bookings & Payouts (${rentalLogs.length})` },
          { id: 'maintenance', label: '🔧 Vehicle Health & Service Queue' },
          { id: 'profile', label: '📋 Owner KYC & Bank Payout Details' }
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`px-4 py-2.5 rounded-2xl transition whitespace-nowrap ${
              activeTab === t.id
                ? 'bg-campus-forest text-white shadow'
                : 'bg-white text-gray-600 border border-campus-border/70 hover:bg-campus-sand/40'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* TAB 1: MY LISTED FLEET TABLE */}
      {activeTab === 'fleet' && (
        <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md overflow-hidden space-y-4">
          <div className="p-5 border-b flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div>
              <h3 className="font-extrabold text-base text-campus-forest font-display">
                My Listed Vehicles & Tariff Controls
              </h3>
              <p className="text-gray-500 text-[11px]">
                Manage availability, view vehicle QR code stickers, adjust rates, or retire vehicles.
              </p>
            </div>

            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2 bg-campus-forest hover:bg-campus-emerald text-white rounded-xl font-bold transition flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Vehicle Listing</span>
            </button>
          </div>

          {loading ? (
            <div className="p-12 text-center text-xs text-gray-400">Loading Fleet Data...</div>
          ) : fleet.length === 0 ? (
            <div className="p-12 text-center space-y-3">
              <Bike className="w-12 h-12 text-gray-300 mx-auto" />
              <h4 className="font-bold text-sm text-campus-forest">No Vehicles Deployed Yet</h4>
              <p className="text-xs text-gray-500 max-w-sm mx-auto">
                Click "+ List New Vehicle" to add your first scooter, bike, or EV to the campus rental pool.
              </p>
              <button
                onClick={() => setShowAddModal(true)}
                className="px-4 py-2 bg-campus-forest text-white rounded-xl text-xs font-bold"
              >
                Deploy First Vehicle
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-campus-sand/40 border-b text-[10px] uppercase font-bold text-gray-500">
                  <tr>
                    <th className="p-3.5">Vehicle Details</th>
                    <th className="p-3.5">Specs & Fuel</th>
                    <th className="p-3.5">Current Campus Hub</th>
                    <th className="p-3.5">Diagnostic Score</th>
                    <th className="p-3.5">Hourly Rate</th>
                    <th className="p-3.5">Live Status</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {fleet.map((v) => (
                    <tr key={v.id} className="hover:bg-campus-sand/20 transition">
                      <td className="p-3.5">
                        <div className="flex items-center gap-3">
                          <VehicleVisual
                            vehicle={v}
                            size="thumbnail"
                            showBadge={false}
                            className="shrink-0"
                          />
                          <div>
                            <div className="font-extrabold text-campus-forest">{v.brand} {v.model}</div>
                            <div className="text-[11px] font-mono text-gray-400 font-bold">{v.vehicle_number}</div>
                          </div>
                        </div>
                      </td>

                      <td className="p-3.5">
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-campus-sand text-campus-forest flex items-center gap-1 w-max">
                          <Fuel className="w-3 h-3 text-campus-emerald" />
                          <span>{v.engine_cc || 125}cc ({v.fuel_level_percentage || 90}%)</span>
                        </span>
                      </td>

                      <td className="p-3.5 font-medium text-gray-600">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-campus-emerald shrink-0" />
                          <span>{v.current_zone?.name || 'PSG Tech Hub'}</span>
                        </div>
                      </td>

                      <td className="p-3.5 font-mono font-bold text-campus-emerald">
                        {v.health_score || 95}/100
                      </td>

                      <td className="p-3.5 font-extrabold text-campus-forest">
                        ₹{v.hourly_rate}/hr
                      </td>

                      <td className="p-3.5">
                        <select
                          value={v.status}
                          onChange={(e) => handleUpdateStatus(v.id, e.target.value)}
                          className={`p-1.5 rounded-xl text-xs font-bold border ${
                            v.status === 'AVAILABLE' ? 'bg-emerald-50 text-emerald-800 border-emerald-300' :
                            v.status === 'IN_USE' ? 'bg-blue-50 text-blue-800 border-blue-300' :
                            v.status === 'MAINTENANCE' ? 'bg-amber-50 text-amber-800 border-amber-300' :
                            'bg-gray-100 text-gray-700 border-gray-300'
                          }`}
                        >
                          <option value="AVAILABLE">AVAILABLE</option>
                          <option value="RESERVED">RESERVED</option>
                          <option value="IN_USE">IN_USE</option>
                          <option value="MAINTENANCE">MAINTENANCE</option>
                          <option value="UNAVAILABLE">UNAVAILABLE</option>
                        </select>
                      </td>

                      <td className="p-3.5 text-right space-x-1.5">
                        <button
                          onClick={() => setSelectedQRVehicle(v)}
                          className="px-2.5 py-1 bg-campus-sand hover:bg-campus-forest hover:text-white rounded-lg font-bold text-[11px] transition inline-flex items-center gap-1"
                          title="View QR Code"
                        >
                          <QrCode className="w-3.5 h-3.5" />
                          <span>QR</span>
                        </button>

                        <button
                          onClick={() => handleRemoveVehicle(v.id, v.vehicle_number)}
                          disabled={deletingId === v.id || v.status === 'IN_USE'}
                          className="px-2.5 py-1 bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200 rounded-lg font-bold text-[11px] transition inline-flex items-center gap-1 disabled:opacity-40"
                          title="Remove Listing"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Remove</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: CUSTOMER BOOKINGS & PAYOUT LOGS */}
      {activeTab === 'earnings' && (
        <div className="space-y-6">
          
          {/* Payout Summary Card */}
          <div className="bg-white rounded-3xl border border-campus-border/80 p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
                <CreditCard className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-campus-forest font-display">
                  Weekly Automated Payout Breakdown
                </h4>
                <p className="text-xs text-gray-500">
                  Direct Bank Transfer • Account ending in <strong>••• 4892 (State Bank of India)</strong>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <div className="text-[10px] uppercase font-bold text-gray-400">Next Payout</div>
                <div className="text-lg font-black text-campus-forest font-display">₹{netEarnings.toFixed(2)}</div>
              </div>
              <span className="px-3 py-1.5 bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold">
                ✓ Payout Ready
              </span>
            </div>
          </div>

          {/* Customer Usage Table */}
          <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md overflow-hidden">
            <div className="p-5 border-b flex justify-between items-center text-xs">
              <h3 className="font-extrabold text-base text-campus-forest font-display">
                Customer Rental Usage & Revenue Logs
              </h3>
              <span className="text-gray-500">Updated Real-Time</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-campus-sand/40 border-b text-[10px] uppercase font-bold text-gray-500">
                  <tr>
                    <th className="p-3.5">Booking / Vehicle</th>
                    <th className="p-3.5">Student Rider</th>
                    <th className="p-3.5">Duration</th>
                    <th className="p-3.5">Pickup Station</th>
                    <th className="p-3.5">Tariff Earned</th>
                    <th className="p-3.5 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {rentalLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-campus-sand/20 transition">
                      <td className="p-3.5">
                        <div className="font-extrabold text-campus-forest">{log.vehicle_model}</div>
                        <div className="text-[11px] font-mono text-gray-400 font-bold">{log.vehicle_number} • {log.id}</div>
                      </td>

                      <td className="p-3.5">
                        <div className="font-bold text-campus-charcoal">{log.student_name}</div>
                        <div className="text-[10px] text-gray-400">{log.student_id}</div>
                      </td>

                      <td className="p-3.5 font-medium text-gray-600">
                        {log.duration_hours} hrs ({log.date})
                      </td>

                      <td className="p-3.5 text-gray-600">
                        {log.pickup_hub}
                      </td>

                      <td className="p-3.5 font-black text-campus-forest font-display text-sm">
                        ₹{log.earned_amount.toFixed(2)}
                      </td>

                      <td className="p-3.5 text-right">
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-100 text-emerald-800">
                          {log.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* TAB 3: VEHICLE HEALTH & SERVICE QUEUE */}
      {activeTab === 'maintenance' && (
        <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md p-6 space-y-4">
          <div className="flex items-center justify-between border-b pb-3">
            <div>
              <h3 className="font-extrabold text-base text-campus-forest font-display">
                Fleet Diagnostics & Routine Maintenance Alerts
              </h3>
              <p className="text-xs text-gray-500">Track vehicle health scores and schedule routine servicing</p>
            </div>
            <button
              onClick={() => alert('Routine service request sent to campus mechanical team.')}
              className="px-3.5 py-2 bg-campus-forest text-white rounded-xl text-xs font-bold hover:bg-campus-emerald transition"
            >
              + Request Service
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            {fleet.slice(0, 6).map((v) => (
              <div key={v.id} className="p-4 rounded-2xl border border-campus-border/80 bg-campus-sand/20 space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-extrabold text-sm text-campus-forest">{v.brand} {v.model}</h4>
                    <div className="text-[11px] font-mono text-gray-400">{v.vehicle_number}</div>
                  </div>
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                    (v.health_score || 95) >= 90 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {v.health_score || 95}% Health
                  </span>
                </div>

                <div className="space-y-1 text-gray-600 text-[11px] pt-1">
                  <div className="flex justify-between">
                    <span>Odometer Reading:</span>
                    <span className="font-bold">{v.current_kilometers || 120} km</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Insurance Status:</span>
                    <span className="font-bold text-emerald-600">✓ VALID (2027)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>RC Compliance:</span>
                    <span className="font-bold text-campus-forest">✓ VERIFIED</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: OWNER KYC & PAYOUT PROFILE */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md p-6 max-w-2xl space-y-4 text-xs">
          <div className="flex items-center gap-3 border-b pb-3">
            <ShieldCheck className="w-6 h-6 text-campus-emerald" />
            <div>
              <h3 className="font-extrabold text-base text-campus-forest font-display">
                Owner Verification & Campus Host Agreement
              </h3>
              <p className="text-gray-500 text-[11px]">Verified partner under Tamil Nadu Higher Education Mobility Consortium</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 p-4 bg-campus-sand/30 rounded-2xl border">
            <div>
              <div className="text-[10px] font-bold text-gray-400 uppercase">Host Name</div>
              <div className="font-extrabold text-sm text-campus-forest">{user?.name}</div>
            </div>
            <div>
              <div className="text-[10px] font-bold text-gray-400 uppercase">Operator ID</div>
              <div className="font-mono font-bold text-sm text-campus-forest">OWN-2026-0001</div>
            </div>
            <div>
              <div className="text-[10px] font-bold text-gray-400 uppercase">National ID Proof</div>
              <div className="font-mono text-gray-700">XXXX-XXXX-8921 (Aadhaar Verified ✓)</div>
            </div>
            <div>
              <div className="text-[10px] font-bold text-gray-400 uppercase">Campus Host Agreement</div>
              <div className="font-bold text-emerald-600">✓ Signed & Active</div>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <h4 className="font-bold text-sm text-campus-forest">Bank Account for Automated Tariff Payouts</h4>
            <div className="p-3 bg-white border border-gray-200 rounded-xl space-y-1">
              <div className="flex justify-between">
                <span className="text-gray-500">Bank Name:</span>
                <span className="font-bold">State Bank of India (SBI Coimbatore Branch)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Account Number:</span>
                <span className="font-mono font-bold">•••• •••• 4892</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">IFSC Code:</span>
                <span className="font-mono font-bold">SBIN0001234</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add Vehicle */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <form onSubmit={handleAddVehicle} className="bg-white rounded-3xl max-w-lg w-full border border-campus-border/80 shadow-2xl p-6 space-y-4 text-xs animate-in fade-in zoom-in duration-200">
            
            <div className="flex justify-between items-center border-b pb-2">
              <div>
                <span className="text-[10px] font-extrabold uppercase text-campus-emerald">OWNER FLEET LISTING</span>
                <h3 className="font-extrabold text-base text-campus-forest font-display">List Vehicle on Campus Mobility</h3>
              </div>
              <button type="button" onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600 font-bold">✕</button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold text-gray-700">TN Registration (TN 66/38/37/39)</label>
                  <button
                    type="button"
                    onClick={handleAutoGenerateReg}
                    className="text-[10px] font-bold text-campus-emerald hover:underline"
                  >
                    ⚡ Auto-Generate
                  </button>
                </div>
                <input
                  type="text"
                  required
                  placeholder="e.g. TN 66 AB 1234"
                  value={newVehicle.vehicle_number}
                  onChange={(e) => setNewVehicle({ ...newVehicle, vehicle_number: e.target.value })}
                  className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl uppercase font-mono font-bold text-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Category</label>
                <select
                  value={newVehicle.type_id}
                  onChange={(e) => {
                    const tid = Number(e.target.value);
                    const t = vehicleTypes.find(x => x.id === tid);
                    setNewVehicle({
                      ...newVehicle,
                      type_id: tid,
                      hourly_rate: t ? t.base_rate_per_hour : newVehicle.hourly_rate
                    });
                  }}
                  className="w-full p-2.5 bg-white border border-campus-border/80 rounded-xl font-medium"
                >
                  {vehicleTypes.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-gray-700 mb-1">Brand</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. TVS / Yamaha / Honda"
                  value={newVehicle.brand}
                  onChange={(e) => setNewVehicle({ ...newVehicle, brand: e.target.value })}
                  className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Model</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Jupiter 125 Disc / Hunter 350"
                  value={newVehicle.model}
                  onChange={(e) => setNewVehicle({ ...newVehicle, model: e.target.value })}
                  className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-gray-700 mb-1">Hourly Tariff (₹)</label>
                <input
                  type="number"
                  required
                  min="5"
                  max="200"
                  value={newVehicle.hourly_rate}
                  onChange={(e) => setNewVehicle({ ...newVehicle, hourly_rate: Number(e.target.value) })}
                  className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Starting Hub</label>
                <select
                  value={newVehicle.current_zone_id}
                  onChange={(e) => setNewVehicle({ ...newVehicle, current_zone_id: Number(e.target.value) })}
                  className="w-full p-2.5 bg-white border border-campus-border/80 rounded-xl"
                >
                  {zones.map((z) => (
                    <option key={z.id} value={z.id}>{z.name} ({z.city})</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="p-3 bg-campus-sand/20 border border-campus-border/60 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-gray-700 block">Vehicle Vector Icon</span>
                <span className="text-[11px] text-gray-500">Automatically styled based on vehicle specifications and category</span>
              </div>
              <VehicleVisual vehicle={newVehicle} size="thumbnail" showBadge={false} />
            </div>

            <div className="flex gap-2 pt-2 border-t">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="flex-1 py-2.5 border border-gray-300 rounded-xl font-semibold hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 bg-campus-forest hover:bg-campus-emerald text-white rounded-xl font-bold transition shadow"
              >
                Deploy & Start Earning
              </button>
            </div>

          </form>
        </div>
      )}

      {/* Modal: View QR Sticker */}
      {selectedQRVehicle && (
        <VehicleQRDisplayModal
          vehicle={selectedQRVehicle}
          onClose={() => setSelectedQRVehicle(null)}
        />
      )}

    </div>
  );
}

export default OwnerDashboard;
