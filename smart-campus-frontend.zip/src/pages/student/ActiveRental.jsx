import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useBooking } from '../../context/BookingContext';
import { QRScannerModal } from '../../components/qr/QRScannerModal';
import { ReturnToPoolModal } from '../../components/booking/ReturnToPoolModal';
import SecurityCheckInOutModal from '../../components/security/SecurityCheckInOutModal';
import IncidentReportModal from '../../components/security/IncidentReportModal';
import { 
  Bike, Zap, Clock, ShieldCheck, MapPin, QrCode, 
  CheckCircle2, AlertTriangle, ArrowRight, Play, CheckCircle, 
  Leaf, Radio, Gauge, Compass, Shield, Navigation, ShieldAlert,
  Crosshair, CornerUpRight, RotateCcw, X, Flag
} from 'lucide-react';
import { apiRequest } from '../../api/client';
import { MapContainer, TileLayer, Marker, Popup, Circle, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import { useGeolocation } from '../../hooks/useGeolocation';
import { 
  fetchNavigationRoute, 
  calculateDistanceMeters, 
  calculateDistanceToPolyline 
} from '../../utils/navigationService';

// Controller to smoothly fit bounds or fly to user/vehicle
function ActiveMapController({ center, routeCoordinates, userLocation }) {
  const map = useMap();
  useEffect(() => {
    if (!map) return;
    if (routeCoordinates && routeCoordinates.length >= 2) {
      try {
        const bounds = L.latLngBounds(routeCoordinates);
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 17, animate: true });
      } catch (e) {
        // silent
      }
    } else if (center) {
      map.flyTo(center, 16, { duration: 1.0 });
    }
  }, [center, routeCoordinates, map]);

  return null;
}

export function ActiveRental({ setTab }) {
  const { activeBooking, zones, fetchZones, startRental, returnRental, cancelBooking } = useBooking();
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [showScanner, setShowScanner] = useState(false);
  const [showReturnModal, setShowReturnModal] = useState(false);
  const [showCheckInModal, setShowCheckInModal] = useState(false);
  const [showCheckOutModal, setShowCheckOutModal] = useState(false);
  const [showIncidentModal, setShowIncidentModal] = useState(false);
  const [telemetry, setTelemetry] = useState(null);

  // Dynamic real-time GPS telemetry state
  const [liveGpsMetrics, setLiveGpsMetrics] = useState({
    speedKmh: 0,
    headingDegrees: 0,
    cardinalDirection: 'N',
    distanceKm: 0.0
  });

  const prevGpsCoordRef = useRef(null);
  const accumulatedDistanceMetersRef = useRef(0);

  // Geolocation for user live tracking and turn-by-turn navigation to return station
  const {
    userLocation,
    loading: loadingGps,
    error: gpsError,
    isTracking,
    getCurrentLocation,
    startTracking,
    stopTracking
  } = useGeolocation({ enableHighAccuracy: true, timeout: 10000, maximumAge: 3000 });

  const [routeData, setRouteData] = useState(null);
  const [isNavigatingReturn, setIsNavigatingReturn] = useState(false);
  const [isCalculatingRoute, setIsCalculatingRoute] = useState(false);
  const [isOffRoute, setIsOffRoute] = useState(false);
  const [hasArrivedStation, setHasArrivedStation] = useState(false);
  const lastRerouteTimeRef = useRef(0);

  // Load campus zones if not already loaded
  useEffect(() => {
    if ((!zones || zones.length === 0) && fetchZones) {
      fetchZones();
    }
  }, [zones, fetchZones]);

  // Determine return hub destination coordinates with reliable fallback
  const returnZone = useMemo(() => {
    if (!activeBooking) return zones?.[0] || null;
    const targetId = activeBooking.return_zone_id || activeBooking.pickup_zone_id;
    const targetName = activeBooking.return_zone_name || activeBooking.pickup_zone_name;
    const matched = zones?.find(z => (targetId && z.id === targetId) || (targetName && z.name === targetName));
    return matched || zones?.[0] || null;
  }, [activeBooking, zones]);

  // Helper for 8 cardinal/intercardinal compass points
  const getCardinalDirection = (deg) => {
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const index = Math.round(((deg % 360) + 360) % 360 / 45) % 8;
    return directions[index];
  };

  // 1. TRIP DURATION: Calculated from fixed start_time timestamp on every tick without interval drift
  useEffect(() => {
    let timerInterval = null;
    if (activeBooking && (activeBooking.status === 'ACTIVE' || activeBooking.status === 'CONFIRMED')) {
      const rawStart = activeBooking.actual_start_time || activeBooking.start_time || activeBooking.created_at;
      const startMs = rawStart ? new Date(rawStart).getTime() : Date.now();

      const computeDuration = () => {
        const nowMs = Date.now();
        const diffSecs = Math.max(0, Math.floor((nowMs - startMs) / 1000));
        setElapsedSeconds(diffSecs);
      };

      computeDuration();
      timerInterval = setInterval(computeDuration, 1000);
    } else {
      setElapsedSeconds(0);
    }
    return () => {
      if (timerInterval) clearInterval(timerInterval);
    };
  }, [activeBooking?.status, activeBooking?.actual_start_time, activeBooking?.start_time, activeBooking?.created_at]);

  // Live GPS telemetry poller for the rented vehicle
  useEffect(() => {
    if (!activeBooking || !activeBooking.vehicle_id) return;

    const fetchTelemetry = async () => {
      try {
        const res = await apiRequest(`/gps/vehicle/${activeBooking.vehicle_id}`);
        if (res.success && res.telemetry) {
          setTelemetry(res.telemetry);
        }
      } catch (e) {
        // silent fail
      }
    };

    fetchTelemetry();
    const gpsInterval = setInterval(fetchTelemetry, 3500);
    return () => clearInterval(gpsInterval);
  }, [activeBooking]);

  // 2, 3, 4. REAL-TIME SPEED, DISTANCE ACCUMULATION & BEARING CALCULATION
  useEffect(() => {
    const currentLat = userLocation?.latitude || telemetry?.latitude || 11.0244;
    const currentLng = userLocation?.longitude || telemetry?.longitude || 76.9942;
    const nowTime = Date.now();

    if (prevGpsCoordRef.current) {
      const { lat: prevLat, lng: prevLng, time: prevTime } = prevGpsCoordRef.current;
      const distDeltaMeters = calculateDistanceMeters(prevLat, prevLng, currentLat, currentLng);
      const timeDeltaSec = Math.max(0.5, (nowTime - prevTime) / 1000);

      // Filter GPS jitter (< 2.5m) and discard teleport jump noise (> 120m in ~3s = > 140 km/h)
      if (distDeltaMeters >= 2.5 && distDeltaMeters <= 120) {
        // Accumulate true distance
        accumulatedDistanceMetersRef.current += distDeltaMeters;

        // Calculate dynamic speed (km/h) with clamp
        const derivedSpeed = Math.min(45, Math.round((distDeltaMeters / timeDeltaSec) * 3.6));
        const effectiveSpeed = (telemetry?.speed_kmh && telemetry.speed_kmh > 0)
          ? Math.round(telemetry.speed_kmh)
          : (userLocation?.speed ? Math.round(userLocation.speed) : derivedSpeed);

        // Calculate dynamic heading bearing (0 - 360 deg)
        const derivedBearing = Math.round(calculateBearing(prevLat, prevLng, currentLat, currentLng));
        const effectiveHeading = (telemetry?.heading_degrees && telemetry.heading_degrees > 0)
          ? Math.round(telemetry.heading_degrees)
          : derivedBearing;

        setLiveGpsMetrics({
          speedKmh: effectiveSpeed,
          headingDegrees: effectiveHeading,
          cardinalDirection: getCardinalDirection(effectiveHeading),
          distanceKm: Number((accumulatedDistanceMetersRef.current / 1000).toFixed(2))
        });

        prevGpsCoordRef.current = { lat: currentLat, lng: currentLng, time: nowTime };
      } else if (distDeltaMeters < 2.5) {
        // Stationary: vehicle is idle
        setLiveGpsMetrics(prev => ({
          ...prev,
          speedKmh: 0
        }));
      }
    } else {
      // First coordinate anchor
      prevGpsCoordRef.current = { lat: currentLat, lng: currentLng, time: nowTime };
      const initialHeading = telemetry?.heading_degrees || 0;
      setLiveGpsMetrics({
        speedKmh: telemetry?.speed_kmh || 0,
        headingDegrees: initialHeading,
        cardinalDirection: getCardinalDirection(initialHeading),
        distanceKm: 0.0
      });
    }
  }, [userLocation?.latitude, userLocation?.longitude, telemetry?.latitude, telemetry?.longitude, telemetry?.speed_kmh, telemetry?.heading_degrees]);

  // 5. Calculate route to return station
  const calculateRouteToStation = async (startPos, destPos) => {
    if (!startPos || !destPos) return;
    setIsCalculatingRoute(true);
    setHasArrivedStation(false);
    setIsOffRoute(false);
    try {
      const route = await fetchNavigationRoute(
        startPos.latitude,
        startPos.longitude,
        destPos.latitude,
        destPos.longitude
      );
      setRouteData(route);
    } catch (err) {
      console.error("Return hub route calculation error:", err);
    } finally {
      setIsCalculatingRoute(false);
    }
  };

  // Re-check route when navigating and position changes
  useEffect(() => {
    if (!isNavigatingReturn || !returnZone) return;
    const currentPos = {
      latitude: userLocation?.latitude || telemetry?.latitude || 11.0244,
      longitude: userLocation?.longitude || telemetry?.longitude || 76.9942
    };
    
    // Arrival check (<= 25m from destination)
    const dist = calculateDistanceMeters(currentPos.latitude, currentPos.longitude, returnZone.latitude, returnZone.longitude);
    if (dist <= 25) {
      setHasArrivedStation(true);
      return;
    }

    // Off-route check (> 45m from polyline)
    if (routeData?.coordinates && routeData.coordinates.length >= 2) {
      const offRouteDist = calculateDistanceToPolyline(currentPos.latitude, currentPos.longitude, routeData.coordinates);
      const now = Date.now();
      if (offRouteDist > 45) {
        setIsOffRoute(true);
        if (now - lastRerouteTimeRef.current > 6000) {
          lastRerouteTimeRef.current = now;
          calculateRouteToStation(currentPos, { latitude: returnZone.latitude, longitude: returnZone.longitude });
        }
      } else {
        setIsOffRoute(false);
      }
    }
  }, [isNavigatingReturn, userLocation, telemetry, returnZone, routeData]);

  // 5. Navigate to Return Hub Button Handler
  const handleStartReturnNav = async () => {
    try {
      startTracking();
      await getCurrentLocation();
    } catch (e) {
      // handled
    }

    const currentPos = {
      latitude: userLocation?.latitude || telemetry?.latitude || 11.0244,
      longitude: userLocation?.longitude || telemetry?.longitude || 76.9942
    };

    const targetDest = returnZone || (zones && zones.length > 0 ? zones[0] : { latitude: 11.0244, longitude: 76.9942, name: 'Main Campus Hub' });
    
    setIsNavigatingReturn(true);
    await calculateRouteToStation(currentPos, { latitude: targetDest.latitude, longitude: targetDest.longitude });
  };

  const handleStopReturnNav = () => {
    setIsNavigatingReturn(false);
    setRouteData(null);
    setIsOffRoute(false);
    setHasArrivedStation(false);
    stopTracking();
  };

  const formatTimer = (totalSec) => {
    const hrs = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleQRVerified = async (scanRes) => {
    setShowScanner(false);
    if (activeBooking) {
      await startRental(activeBooking.id, scanRes.vehicle?.qr_code_token || '');
    }
  };

  const handleReturnSuccess = (res) => {
    setShowReturnModal(false);
    setTab('eco-score');
  };

  if (!activeBooking) {
    return (
      <div className="bg-white rounded-3xl border border-campus-border/80 p-12 text-center max-w-md mx-auto my-12 space-y-4 shadow-sm">
        <div className="w-16 h-16 rounded-3xl bg-campus-sand/60 text-campus-forest flex items-center justify-center mx-auto">
          <Bike className="w-8 h-8 text-campus-emerald" />
        </div>
        <h2 className="text-xl font-extrabold text-campus-forest font-display">No Active Campus Ride</h2>
        <p className="text-xs text-gray-500">
          You currently do not have an active vehicle reservation or ongoing ride.
        </p>
        <div className="flex flex-col sm:flex-row gap-2 justify-center pt-2">
          <button
            onClick={() => setTab('vehicles')}
            className="px-5 py-2.5 bg-gradient-to-r from-campus-forest to-campus-emerald text-white rounded-2xl font-bold text-xs shadow-md hover:shadow-lg transition flex items-center justify-center gap-1.5"
          >
            <span>Browse Vehicles</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => setTab('live-gps')}
            className="px-5 py-2.5 bg-campus-gold/20 text-campus-forest border border-campus-gold/50 rounded-2xl font-bold text-xs hover:bg-campus-gold/30 transition flex items-center justify-center gap-1.5"
          >
            <Radio className="w-4 h-4 text-emerald-600 animate-pulse" />
            <span>View Live GPS Radar</span>
          </button>
        </div>
      </div>
    );
  }

  const isConfirmedOnly = activeBooking.status === 'CONFIRMED';
  const isActiveRide = activeBooking.status === 'ACTIVE';

  // Effective vehicle & user positions
  const vehLat = telemetry?.latitude || 11.0244;
  const vehLng = telemetry?.longitude || 76.9942;
  const currentLat = userLocation?.latitude || vehLat;
  const currentLng = userLocation?.longitude || vehLng;
  const currentSpeed = liveGpsMetrics.speedKmh;
  const currentHeading = liveGpsMetrics.headingDegrees;
  const currentCardinal = liveGpsMetrics.cardinalDirection;
  const currentDistanceKm = liveGpsMetrics.distanceKm;

  const vehiclePinIcon = L.divIcon({
    className: 'active-gps-pin',
    html: `
      <div style="position: relative; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;">
        <div class="gps-pulse-ring"></div>
        <div style="
          background: #2563eb;
          color: white;
          width: 36px;
          height: 36px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 3px solid #ffffff;
          box-shadow: 0 4px 14px rgba(0,0,0,0.4);
          font-size: 16px;
          z-index: 2;
        ">
          🛵
        </div>
      </div>
    `,
    iconSize: [44, 44],
    iconAnchor: [22, 22]
  });

  const returnHubPinIcon = L.divIcon({
    className: 'hub-destination-pin',
    html: `
      <div style="position: relative; display: flex; flex-direction: column; align-items: center;">
        <div style="
          background: #059669;
          color: white;
          padding: 3px 7px;
          border-radius: 10px;
          font-size: 10px;
          font-weight: 800;
          font-family: sans-serif;
          box-shadow: 0 3px 10px rgba(0,0,0,0.3);
          border: 2px solid white;
          white-space: nowrap;
        ">
          🏁 Return Hub
        </div>
        <div style="
          width: 0;
          height: 0;
          border-left: 5px solid transparent;
          border-right: 5px solid transparent;
          border-top: 6px solid #059669;
        "></div>
      </div>
    `,
    iconSize: [70, 32],
    iconAnchor: [35, 32]
  });

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-16">
      
      {/* Live Active Rental Card */}
      <div className="bg-white rounded-3xl border-2 border-campus-emerald shadow-2xl overflow-hidden animate-in fade-in">
        
        {/* Top Status Header */}
        <div className="bg-gradient-to-r from-campus-forest via-emerald-950 to-slate-900 text-white p-5 sm:p-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className={`w-3 h-3 rounded-full ${isActiveRide ? 'bg-campus-mint animate-ping' : 'bg-campus-gold'}`}></span>
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-campus-mint flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5" />
                <span>{isActiveRide ? 'LIVE GPS RENTAL IN PROGRESS' : 'CONFIRMED — AWAITING QR UNLOCK'}</span>
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold font-display mt-1">{activeBooking.vehicle_model}</h1>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-gray-200 mt-1">
              <span><span className="text-gray-400 font-medium">Vehicle Number:</span> <strong className="font-mono text-campus-mint">{activeBooking.vehicle_number}</strong></span>
              <span><span className="text-gray-400 font-medium">Owner Name:</span> <strong className="text-white">{activeBooking.owner_name || activeBooking.vehicle_owner_name || 'Campus Host'}</strong></span>
              <span>• ⛽ {activeBooking.vehicle_type}</span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-gray-400">Booking Code</span>
            <div className="text-sm font-mono font-bold text-campus-gold">{activeBooking.booking_code}</div>
          </div>
        </div>

        {/* Live Digital Speedometer & Rent Meter (if Active) */}
        {isActiveRide && (
          <div className="p-6 bg-gradient-to-r from-campus-forest via-emerald-950 to-campus-forest text-white border-y border-campus-mint/30 space-y-4">
            
            <div className="flex flex-col sm:flex-row items-center justify-around gap-4 text-center">
              {/* Duration Timer */}
              <div>
                <span className="text-[10px] uppercase tracking-widest text-campus-mint font-bold flex items-center justify-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>TRIP DURATION</span>
                </span>
                <div className="text-3xl sm:text-4xl font-extrabold font-mono tracking-widest text-white mt-1">
                  {formatTimer(elapsedSeconds)}
                </div>
              </div>

              {/* Speedometer Gauge */}
              <div className="px-6 py-2 bg-white/10 rounded-2xl border border-white/20 backdrop-blur-md">
                <span className="text-[10px] uppercase tracking-widest text-campus-gold font-bold flex items-center justify-center gap-1">
                  <Gauge className="w-3 h-3" />
                  <span>LIVE SPEED</span>
                </span>
                <div className="text-3xl sm:text-4xl font-black font-mono text-campus-gold mt-1">
                  {currentSpeed} <span className="text-sm text-white font-sans font-normal">km/h</span>
                </div>
              </div>

              {/* Heading & GNSS */}
              <div>
                <span className="text-[10px] uppercase tracking-widest text-campus-mint font-bold flex items-center justify-center gap-1">
                  <Compass className="w-3 h-3" />
                  <span>HEADING</span>
                </span>
                <div className="text-xl sm:text-2xl font-black font-mono text-white mt-1">
                  {currentHeading}° {currentCardinal}
                </div>
                <div className="text-[10px] text-emerald-400 font-semibold mt-0.5">12 Satellites Locked</div>
              </div>
            </div>

            <div className="flex items-center justify-center gap-4 text-xs text-gray-300 font-semibold pt-2 border-t border-white/10">
              <span>Distance Covered: ~{currentDistanceKm.toFixed(2)} km</span>
              <span>•</span>
              <span>Total Tariff: ₹{activeBooking.total_price.toFixed(2)}</span>
              <span>•</span>
              <span className="text-campus-mint font-bold">Inside Campus Geofence</span>
            </div>

          </div>
        )}

        {/* Embedded Live GPS Map View with Return Hub Navigation */}
        <div className="p-4 bg-campus-sand/20 border-b border-campus-border/60 relative">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
            <div className="flex items-center gap-1.5">
              <Navigation className="w-3.5 h-3.5 text-campus-emerald" />
              <span className="text-xs font-extrabold text-campus-forest">
                {isNavigatingReturn ? 'Live Return Hub Navigation' : 'Real-Time GPS Route Tracking'}
              </span>
              {userLocation && (
                <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-blue-100 text-blue-800 border border-blue-200">
                  GPS ±{userLocation.accuracy}m
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              {isNavigatingReturn ? (
                <button
                  onClick={handleStopReturnNav}
                  className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-[10px] font-bold transition flex items-center gap-1 shadow-sm"
                >
                  <X className="w-3 h-3" />
                  <span>Stop Nav</span>
                </button>
              ) : (
                <button
                  onClick={handleStartReturnNav}
                  className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[10px] font-bold transition flex items-center gap-1 shadow-sm"
                >
                  <Navigation className="w-3 h-3" />
                  <span>Navigate to Return Hub</span>
                </button>
              )}
              
              <button
                onClick={() => setTab('live-gps')}
                className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-[10px] font-bold transition flex items-center gap-1 shadow-sm"
              >
                <Radio className="w-3 h-3 text-sky-300 animate-pulse" />
                <span>Full Radar</span>
              </button>
            </div>
          </div>

          {/* Navigation HUD Banner (When navigating to Return Hub) */}
          {isNavigatingReturn && routeData && (
            <div className="mb-2 p-3 bg-slate-900 text-white rounded-xl border border-sky-400/40 shadow text-xs space-y-1.5 animate-in fade-in">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CornerUpRight className="w-4 h-4 text-sky-400 shrink-0" />
                  <span className="font-bold text-sky-200">
                    {routeData.steps?.[0]?.instruction || `Navigate to ${returnZone?.name || 'Return Station'}`}
                  </span>
                </div>
                {isOffRoute ? (
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-500/30 text-amber-300 border border-amber-400/40 flex items-center gap-1 animate-pulse">
                    <RotateCcw className="w-3 h-3 animate-spin" />
                    <span>Rerouting</span>
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/30 text-emerald-300 border border-emerald-400/40">
                    On Track
                  </span>
                )}
              </div>
              <div className="flex items-center justify-between text-[11px] text-gray-300 border-t border-white/10 pt-1">
                <span>Distance: <strong>{routeData.distanceFormatted}</strong> • ETA: {routeData.durationFormatted}</span>
                <span className="font-mono text-campus-gold font-bold">Speed: {currentSpeed} km/h</span>
              </div>
              {hasArrivedStation && (
                <div className="p-1.5 bg-emerald-600 text-white rounded-lg text-center font-bold flex items-center justify-center gap-1">
                  <Flag className="w-3.5 h-3.5" />
                  <span>Arrived at Return Hub! Ready for Check-Out</span>
                </div>
              )}
            </div>
          )}

          {/* GPS Error Alert */}
          {gpsError && (
            <div className="mb-2 p-2 bg-amber-50 border border-amber-300 text-amber-900 rounded-xl text-xs flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>{gpsError}</span>
              </div>
              <button
                onClick={handleStartReturnNav}
                className="px-2 py-0.5 bg-amber-700 text-white rounded text-[10px] font-bold"
              >
                Retry
              </button>
            </div>
          )}

          <div className="h-64 rounded-2xl overflow-hidden border border-campus-border/80 shadow-inner relative z-0">
            <MapContainer
              center={[currentLat, currentLng]}
              zoom={16}
              scrollWheelZoom={false}
              className="h-full w-full"
            >
              <ActiveMapController
                center={[currentLat, currentLng]}
                routeCoordinates={routeData?.coordinates}
                userLocation={userLocation}
              />

              <TileLayer
                attribution='&copy; OpenStreetMap contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />

              {/* Route Polyline */}
              {routeData?.coordinates && routeData.coordinates.length > 0 && (
                <>
                  <Polyline
                    positions={routeData.coordinates}
                    pathOptions={{ color: '#1d4ed8', weight: 7, opacity: 0.4, lineCap: 'round', lineJoin: 'round' }}
                  />
                  <Polyline
                    positions={routeData.coordinates}
                    pathOptions={{ color: '#2563eb', weight: 4, opacity: 0.95, lineCap: 'round', lineJoin: 'round' }}
                  />
                </>
              )}

              {/* Accuracy Circle */}
              {userLocation && (
                <Circle
                  center={[userLocation.latitude, userLocation.longitude]}
                  radius={Math.max(10, userLocation.accuracy || 15)}
                  pathOptions={{ fillColor: '#3b82f6', fillOpacity: 0.15, color: '#2563eb', weight: 1 }}
                />
              )}

              {/* Vehicle / User Marker */}
              <Marker position={[currentLat, currentLng]} icon={vehiclePinIcon}>
                <Popup>
                  <div className="p-1 text-xs">
                    <strong>{activeBooking.vehicle_number}</strong>
                    <div>Speed: {currentSpeed} km/h • Heading: {currentHeading}° {currentCardinal}</div>
                    {userLocation && <div className="text-[10px] text-blue-600">Real GPS Tracked</div>}
                  </div>
                </Popup>
              </Marker>

              {/* Return Hub Marker */}
              {returnZone && returnZone.latitude && returnZone.longitude && (
                <Marker position={[returnZone.latitude, returnZone.longitude]} icon={returnHubPinIcon}>
                  <Popup>
                    <div className="p-1 text-xs">
                      <strong>{returnZone.name}</strong>
                      <div className="text-[10px] text-gray-500">Scheduled Return Hub</div>
                    </div>
                  </Popup>
                </Marker>
              )}
            </MapContainer>
          </div>
        </div>

        {/* Ride Details Summary */}
        <div className="p-5 sm:p-6 space-y-4 text-xs">
          
          <div className="grid grid-cols-2 gap-3 p-4 bg-campus-sand/40 border border-campus-border/70 rounded-2xl">
            <div>
              <span className="text-[10px] uppercase font-bold text-gray-500">Pickup Zone</span>
              <div className="font-bold text-campus-forest mt-0.5 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-campus-emerald flex-shrink-0" />
                <span>{activeBooking.pickup_zone_name}</span>
              </div>
            </div>

            <div>
              <span className="text-[10px] uppercase font-bold text-gray-500">Scheduled Return Hub</span>
              <div className="font-bold text-campus-forest mt-0.5 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-campus-gold flex-shrink-0" />
                <span>{activeBooking.return_zone_name || 'Any Campus Hub'}</span>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          {isConfirmedOnly ? (
            <div className="space-y-3 pt-2">
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-amber-900 text-xs flex items-center gap-2.5">
                <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0" />
                <div>
                  <strong>Next Step:</strong> Complete pre-ride inspection or scan the vehicle QR sticker to unlock and start your ride.
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-2.5">
                <button
                  onClick={() => setShowCheckInModal(true)}
                  className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold text-xs shadow-lg transition flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Pre-Ride Security Check-In</span>
                </button>
                <button
                  onClick={() => setShowScanner(true)}
                  className="flex-1 py-3 bg-campus-forest hover:bg-campus-emerald text-white rounded-2xl font-bold text-xs shadow-lg transition flex items-center justify-center gap-2"
                >
                  <QrCode className="w-4 h-4 text-campus-gold" />
                  <span>Scan QR Sticker to Unlock</span>
                </button>
                <button
                  onClick={() => cancelBooking(activeBooking.id)}
                  className="px-4 py-3 border border-rose-200 text-rose-600 hover:bg-rose-50 rounded-2xl font-bold text-xs transition"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-3 pt-2">
              <div className="flex flex-col sm:flex-row gap-2.5">
                <button
                  onClick={() => setShowCheckOutModal(true)}
                  className="flex-1 py-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold text-xs sm:text-sm shadow-xl transition flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Post-Ride Security Return Inspection</span>
                </button>
                <button
                  onClick={() => setShowIncidentModal(true)}
                  className="py-3.5 px-4 bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 border border-rose-500/30 rounded-2xl font-bold text-xs transition flex items-center justify-center gap-1.5"
                >
                  <ShieldAlert className="w-4 h-4" />
                  <span>Report Incident</span>
                </button>
              </div>

              <button
                onClick={() => setShowReturnModal(true)}
                className="w-full py-3.5 bg-gradient-to-r from-campus-forest to-campus-emerald hover:from-campus-emerald hover:to-campus-forest text-white rounded-2xl font-extrabold text-xs sm:text-sm shadow-lg transition flex items-center justify-center gap-2"
              >
                <Leaf className="w-4 h-4 text-campus-mint" />
                <span>Quick Return to Campus Pool</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

        </div>

      </div>

      {/* Modals */}
      {showScanner && (
        <QRScannerModal
          targetVehicle={activeBooking}
          onVerifySuccess={handleQRVerified}
          onClose={() => setShowScanner(false)}
        />
      )}

      {showReturnModal && (
        <ReturnToPoolModal
          booking={activeBooking}
          zones={zones}
          onClose={() => setShowReturnModal(false)}
          onSuccess={handleReturnSuccess}
        />
      )}

      {showCheckInModal && (
        <SecurityCheckInOutModal
          isOpen={showCheckInModal}
          mode="checkin"
          booking={activeBooking}
          onClose={() => setShowCheckInModal(false)}
          onSuccess={() => {
            setShowCheckInModal(false);
            window.location.reload();
          }}
        />
      )}

      {showCheckOutModal && (
        <SecurityCheckInOutModal
          isOpen={showCheckOutModal}
          mode="checkout"
          booking={activeBooking}
          onClose={() => setShowCheckOutModal(false)}
          onSuccess={() => {
            setShowCheckOutModal(false);
            setTab('eco-score');
          }}
        />
      )}

      {showIncidentModal && (
        <IncidentReportModal
          isOpen={showIncidentModal}
          vehicleId={activeBooking.vehicle_id}
          bookingId={activeBooking.id}
          onClose={() => setShowIncidentModal(false)}
        />
      )}

    </div>
  );
}
