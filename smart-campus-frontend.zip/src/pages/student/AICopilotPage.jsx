import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useBooking } from '../../context/BookingContext';
import { BookingModal } from '../../components/booking/BookingModal';
import { 
  Sparkles, Bot, Send, Zap, Fuel, Shield, Compass, 
  Clock, TrendingUp, RefreshCw, ChevronRight, Activity, 
  MapPin, CheckCircle2, ArrowRight, Gauge, Leaf, AlertTriangle 
} from 'lucide-react';
import { apiRequest } from '../../api/client';
import { VehicleVisual } from '../../components/common/VehicleVisual';

function renderFormattedSpan(text) {
  if (!text) return text;
  const parts = [];
  const regex = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
  let lastIndex = 0;
  let match;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(text.substring(lastIndex, match.index));
    }
    const token = match[0];
    if (token.startsWith('**') && token.endsWith('**')) {
      parts.push(<strong key={match.index} className="font-bold text-campus-forest">{token.slice(2, -2)}</strong>);
    } else if (token.startsWith('*') && token.endsWith('*')) {
      parts.push(<em key={match.index} className="italic text-gray-700">{token.slice(1, -1)}</em>);
    } else if (token.startsWith('`') && token.endsWith('`')) {
      parts.push(<code key={match.index} className="px-1 py-0.5 bg-campus-sand font-mono text-[10px] rounded text-campus-emerald font-semibold">{token.slice(1, -1)}</code>);
    }
    lastIndex = match.index + token.length;
  }
  if (lastIndex < text.length) {
    parts.push(text.substring(lastIndex));
  }
  return parts.length > 0 ? parts : text;
}

function FormattedMessage({ text }) {
  if (!text) return null;
  const lines = text.split('\n');

  return (
    <div className="space-y-1.5 leading-relaxed text-xs">
      {lines.map((line, idx) => {
        const trimmed = line.trim();
        if (!trimmed) {
          return <div key={idx} className="h-1" />;
        }
        if (trimmed.startsWith('### ')) {
          return (
            <div key={idx} className="font-extrabold text-xs text-campus-forest pt-1 pb-0.5 border-b border-campus-border/60">
              {renderFormattedSpan(trimmed.slice(4))}
            </div>
          );
        }
        if (trimmed.startsWith('## ')) {
          return (
            <div key={idx} className="font-extrabold text-sm text-campus-forest pt-1 pb-0.5">
              {renderFormattedSpan(trimmed.slice(3))}
            </div>
          );
        }
        if (trimmed.startsWith('* ') || trimmed.startsWith('- ')) {
          return (
            <div key={idx} className="flex items-start gap-1.5 pl-1 text-[11px]">
              <span className="text-campus-emerald font-bold">•</span>
              <span className="flex-1">{renderFormattedSpan(trimmed.slice(2))}</span>
            </div>
          );
        }
        const numMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
        if (numMatch) {
          return (
            <div key={idx} className="flex items-start gap-1.5 pl-1 text-[11px]">
              <span className="text-campus-emerald font-bold">{numMatch[1]}.</span>
              <span className="flex-1">{renderFormattedSpan(numMatch[2])}</span>
            </div>
          );
        }
        return (
          <div key={idx} className="text-[11px]">
            {renderFormattedSpan(line)}
          </div>
        );
      })}
    </div>
  );
}

export function AICopilotPage({ setTab }) {
  const { user } = useAuth();
  const { zones } = useBooking();
  const [activeSubTab, setActiveSubTab] = useState('chat'); // 'chat' | 'route-calc' | 'demand-forecast'
  
  // Chat state
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedVehicleForBooking, setSelectedVehicleForBooking] = useState(null);
  const initialChatMessage = {
    id: 1,
    sender: 'ai',
    text: "👋 Welcome to **AURA AI Mobility Hub**! I can assist you with intelligent vehicle matching, live telemetry insights, multi-modal route carbon analysis, and campus fleet demand predictions.",
    suggestions: [
      "Find available scooters near me",
      "Fastest ride for exam in 10 mins",
      "Predict peak demand surge hours",
      "What are the campus speed limits?"
    ],
    cards: []
  };
  const [messages, setMessages] = useState([initialChatMessage]);
  const chatBottomRef = useRef(null);

  useEffect(() => {
    if (activeSubTab === 'chat') {
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, activeSubTab]);

  const handleClearChat = () => {
    setMessages([initialChatMessage]);
    setInputQuery('');
  };

  // Route optimizer state
  const [distanceKm, setDistanceKm] = useState(2.5);
  const [passengerCount, setPassengerCount] = useState(1);
  const [routeAnalysis, setRouteAnalysis] = useState(null);
  const [routeLoading, setRouteLoading] = useState(false);

  // Demand forecast state
  const [demandData, setDemandData] = useState(null);

  // Calculate Route Modes
  const handleCalculateRoute = async (dist = distanceKm, pass = passengerCount) => {
    setRouteLoading(true);
    try {
      const res = await apiRequest('/ai/optimize-route', {
        method: 'POST',
        body: JSON.stringify({ distance_km: dist, passengers: pass })
      });
      if (res.success) {
        setRouteAnalysis(res);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setRouteLoading(false);
    }
  };

  // Load Demand Forecast
  const handleLoadDemand = async () => {
    try {
      const res = await apiRequest('/ai/predict-demand');
      if (res.success) {
        setDemandData(res);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    handleCalculateRoute(2.5, 1);
    handleLoadDemand();
  }, []);

  const handleSend = async (queryText) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || loading) return;

    const userMsg = {
      id: Date.now(),
      sender: 'user',
      text: textToSend
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');
    setLoading(true);

    try {
      const res = await apiRequest('/ai/chat', {
        method: 'POST',
        body: JSON.stringify({
          query: textToSend,
          user_id: user?.id
        })
      });

      if (res.success && res.result) {
        setMessages(prev => [...prev, {
          id: Date.now() + 1,
          sender: 'ai',
          text: res.result.response,
          suggestions: res.result.suggestions || [],
          cards: res.result.cards || []
        }]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-16">
      
      {/* Top Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-extrabold uppercase tracking-widest text-campus-emerald flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-campus-gold animate-spin-slow" />
            <span>BUILT-IN INTELLIGENT CAMPUS MOBILITY COPILOT</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-campus-forest font-display tracking-tight mt-0.5">
            AURA AI Mobility Suite
          </h1>
          <p className="text-xs text-gray-500">
            Real-time NLP reasoning, multi-modal trip carbon estimator, and predictive fleet rebalancing.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex bg-white p-1 rounded-2xl border border-campus-border/80 shadow-sm text-xs font-bold self-start sm:self-auto">
          <button
            onClick={() => setActiveSubTab('chat')}
            className={`px-3.5 py-1.5 rounded-xl transition flex items-center gap-1.5 ${
              activeSubTab === 'chat' ? 'bg-campus-forest text-white shadow' : 'text-gray-600 hover:text-campus-forest'
            }`}
          >
            <Bot className="w-3.5 h-3.5 text-campus-mint" />
            <span>AI Copilot Chat</span>
          </button>

          <button
            onClick={() => setActiveSubTab('route-calc')}
            className={`px-3.5 py-1.5 rounded-xl transition flex items-center gap-1.5 ${
              activeSubTab === 'route-calc' ? 'bg-campus-forest text-white shadow' : 'text-gray-600 hover:text-campus-forest'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-campus-gold" />
            <span>Trip & Carbon Optimizer</span>
          </button>

          <button
            onClick={() => setActiveSubTab('demand-forecast')}
            className={`px-3.5 py-1.5 rounded-xl transition flex items-center gap-1.5 ${
              activeSubTab === 'demand-forecast' ? 'bg-campus-forest text-white shadow' : 'text-gray-600 hover:text-campus-forest'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
            <span>Demand & Rebalance Radar</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Full AI Copilot Chat */}
      {activeSubTab === 'chat' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Main Chat Frame (8 cols) */}
          <div className="lg:col-span-8 bg-white rounded-3xl border border-campus-border/80 shadow-lg flex flex-col h-[620px] overflow-hidden">
            
            {/* Top Bar */}
            <div className="p-4 bg-gradient-to-r from-slate-900 via-slate-800 to-blue-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-campus-emerald/60 flex items-center justify-center border border-sky-400/40">
                  <Sparkles className="w-4 h-4 text-sky-300" />
                </div>
                <div>
                  <div className="font-extrabold text-xs font-display flex items-center gap-1.5">
                    <span>AURA AI MOBILITY ASSISTANT</span>
                    <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse"></span>
                  </div>
                  <p className="text-[10px] text-gray-300 font-mono">Natural Language Intent Parser & Instant Reservation Engine</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleClearChat}
                  title="Reset Chat"
                  className="px-2.5 py-1 rounded-xl bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition flex items-center gap-1 text-[11px] font-medium"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reset</span>
                </button>
                <span className="text-[10px] px-2.5 py-1 rounded-full bg-white/10 text-sky-300 font-mono font-bold">
                  Online v2.4
                </span>
              </div>
            </div>

            {/* Messages Scroll Area */}
            <div className="flex-1 p-5 overflow-y-auto space-y-4 bg-campus-sand/20 text-xs">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.sender === 'ai' && (
                    <div className="w-7 h-7 rounded-full bg-campus-forest text-sky-300 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Sparkles className="w-4 h-4" />
                    </div>
                  )}

                  <div className="max-w-[85%] space-y-2">
                    <div
                      className={`p-4 rounded-2xl ${
                        msg.sender === 'user'
                          ? 'bg-campus-forest text-white rounded-tr-none'
                          : 'bg-white border border-campus-border/80 text-gray-800 shadow-sm rounded-tl-none'
                      }`}
                    >
                      {msg.sender === 'ai' ? (
                        <FormattedMessage text={msg.text} />
                      ) : (
                        <div className="whitespace-pre-line leading-relaxed text-xs">
                          {msg.text}
                        </div>
                      )}
                    </div>

                    {/* Cards */}
                    {msg.cards && msg.cards.length > 0 && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                        {msg.cards.map((c) => (
                          <div
                            key={c.id}
                            className="p-3.5 bg-white border border-campus-border/90 rounded-2xl shadow-sm space-y-2 hover:border-campus-emerald/60 transition"
                          >
                            <div className="flex items-center gap-2.5">
                              <VehicleVisual
                                vehicle={c}
                                size="thumbnail"
                                showBadge={false}
                                className="flex-shrink-0"
                              />
                              <div className="min-w-0 flex-1">
                                <div className="flex items-center justify-between">
                                  <span className="font-mono font-black text-xs text-campus-forest bg-campus-sand px-1.5 py-0.5 rounded">
                                    {c.vehicle_number}
                                  </span>
                                  <span className="text-xs font-black text-campus-emerald">
                                    ₹{c.hourly_rate}/hr
                                  </span>
                                </div>
                                <div className="font-bold text-gray-900 text-xs truncate mt-0.5">{c.title}</div>
                              </div>
                            </div>
                            
                            {c.college_name && (
                              <div className="text-[10px] text-gray-500 font-medium">
                                📍 {c.current_zone_name || c.college_name}
                              </div>
                            )}

                            <div className="flex items-center justify-between text-[10px] text-gray-600 bg-campus-sand/40 p-1.5 rounded-lg font-mono">
                              <span>⛽ {c.fuel_level_percentage}% Tank</span>
                              <span>{c.mileage_kmpl} km/l</span>
                              <span>{c.engine_cc}cc</span>
                            </div>

                            <button
                              onClick={() => setSelectedVehicleForBooking(c)}
                              className="w-full py-1.5 bg-campus-forest hover:bg-campus-emerald text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 mt-1 shadow-sm"
                            >
                              <span>1-Click Reserve</span>
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Suggestions */}
                    {msg.suggestions && msg.suggestions.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {msg.suggestions.map((s, idx) => (
                          <button
                            key={idx}
                            onClick={() => handleSend(s)}
                            className="px-3 py-1.5 bg-white hover:bg-campus-sand/80 border border-campus-border/90 rounded-full text-[11px] font-semibold text-campus-forest transition shadow-2xs text-left"
                          >
                            💡 {s}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {loading && (
                <div className="flex items-center gap-2 text-xs text-gray-500 pl-10">
                  <span className="w-2 h-2 rounded-full bg-campus-emerald animate-ping"></span>
                  <span>AURA AI is reasoning over campus telemetry...</span>
                </div>
              )}

              <div ref={chatBottomRef} />
            </div>

            {/* Input Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="p-4 bg-white border-t border-campus-border/70 flex items-center gap-2"
            >
              <input
                type="text"
                placeholder="Ask AURA AI anything (e.g. 'Find bikes under ₹30/hr near Library')..."
                value={inputQuery}
                onChange={(e) => setInputQuery(e.target.value)}
                className="flex-1 px-4 py-3 bg-campus-sand/30 border border-campus-border/80 rounded-2xl text-xs text-campus-charcoal focus:outline-none focus:ring-2 focus:ring-campus-emerald/40 placeholder:text-gray-400"
              />
              <button
                type="submit"
                disabled={loading || !inputQuery.trim()}
                className="px-5 py-3 bg-campus-forest hover:bg-campus-emerald disabled:opacity-50 text-white rounded-2xl font-bold text-xs shadow-md transition flex items-center gap-1.5"
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>

          </div>

          {/* Right Side Helper Cards (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            
            <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md p-5 space-y-3">
              <h3 className="font-extrabold text-sm text-campus-forest font-display flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-campus-gold" />
                <span>AI Prompt Quick Ideas</span>
              </h3>
              
              <div className="space-y-2">
                {[
                  "Show all petrol scooters at PSG Tech",
                  "Fastest route to Library for my exam",
                  "What are the campus speed limits?",
                  "Show Royal Enfield Hunter 350 cruisers",
                  "How to earn Eco Points for free rides?",
                  "Predict morning peak surge hours"
                ].map((prompt, i) => (
                  <button
                    key={i}
                    onClick={() => handleSend(prompt)}
                    className="w-full text-left p-2.5 bg-campus-sand/20 hover:bg-campus-sand/60 border border-campus-border/60 rounded-xl text-xs font-medium text-gray-700 transition flex items-center justify-between group"
                  >
                    <span className="truncate">{prompt}</span>
                    <ChevronRight className="w-3.5 h-3.5 text-gray-400 group-hover:text-campus-emerald flex-shrink-0" />
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Live GPS Link */}
            <div className="bg-gradient-to-br from-campus-forest to-emerald-950 text-white rounded-3xl p-5 shadow-md space-y-2.5">
              <div className="flex items-center gap-2 font-bold text-campus-mint text-xs">
                <Shield className="w-4 h-4" />
                <span>Satellite Live GPS Radar</span>
              </div>
              <p className="text-xs text-gray-200 leading-relaxed">
                Want to observe real-time moving vehicles across all 29 Tamil Nadu college campuses?
              </p>
              <button
                onClick={() => setTab('live-gps')}
                className="w-full py-2 bg-campus-mint text-campus-forest hover:bg-white rounded-xl text-xs font-extrabold transition shadow"
              >
                Launch Live GPS Radar →
              </button>
            </div>

          </div>

        </div>
      )}

      {/* Tab 2: AI Multi-Modal Route & Carbon Optimizer */}
      {activeSubTab === 'route-calc' && (
        <div className="space-y-6">
          
          {/* Controls Bar */}
          <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md p-6 space-y-4">
            <h2 className="text-lg font-extrabold text-campus-forest font-display">
              Multi-Modal Route, Transit Time & Carbon Footprint Analyzer
            </h2>
            <p className="text-xs text-gray-500">
              Adjust your planned trip distance and passenger count to let AURA AI compute real-time transit times, costs, and carbon offsets across different transit modes.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
              {/* Distance Slider */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-bold text-gray-700">
                  <span>Planned Trip Distance:</span>
                  <span className="font-mono text-campus-forest font-black text-sm">{distanceKm} km</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="12.0"
                  step="0.5"
                  value={distanceKm}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setDistanceKm(val);
                    handleCalculateRoute(val, passengerCount);
                  }}
                  className="w-full accent-campus-emerald cursor-pointer"
                />
              </div>

              {/* Passengers Slider */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-bold text-gray-700">
                  <span>Passenger Group Size:</span>
                  <span className="font-mono text-campus-forest font-black text-sm">{passengerCount} {passengerCount > 1 ? 'People' : 'Person'}</span>
                </div>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button
                      key={num}
                      onClick={() => {
                        setPassengerCount(num);
                        handleCalculateRoute(distanceKm, num);
                      }}
                      className={`flex-1 py-1.5 rounded-xl font-bold text-xs transition border ${
                        passengerCount === num 
                          ? 'bg-campus-forest text-white border-campus-forest shadow' 
                          : 'bg-campus-sand/30 border-campus-border/80 text-gray-600 hover:bg-campus-sand/60'
                      }`}
                    >
                      {num} {num === 1 ? 'Solo' : 'Group'}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Results Comparison Grid */}
          {routeAnalysis && routeAnalysis.modes && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {routeAnalysis.modes.map((mode, idx) => (
                <div
                  key={idx}
                  className="bg-white rounded-3xl border border-campus-border/80 p-6 shadow-md space-y-4 relative overflow-hidden"
                >
                  {/* Tag */}
                  <span className="inline-block px-3 py-1 rounded-full text-[10px] font-extrabold bg-campus-sand/60 text-campus-forest border border-campus-border/70">
                    {mode.recommendation_tag}
                  </span>

                  <h3 className="text-base font-extrabold text-gray-900 font-display">
                    {mode.title}
                  </h3>

                  {/* Metrics Grid */}
                  <div className="grid grid-cols-2 gap-3 pt-2 border-t border-gray-100 text-xs">
                    <div className="p-2.5 bg-campus-sand/20 rounded-xl">
                      <span className="text-[10px] text-gray-400 font-bold uppercase">Estimated Time</span>
                      <div className="text-lg font-black font-mono text-campus-forest mt-0.5">
                        {mode.travel_time_mins} <span className="text-xs font-sans font-normal">mins</span>
                      </div>
                    </div>

                    <div className="p-2.5 bg-campus-sand/20 rounded-xl">
                      <span className="text-[10px] text-gray-400 font-bold uppercase">Estimated Fare</span>
                      <div className="text-lg font-black font-mono text-campus-emerald mt-0.5">
                        ₹{mode.estimated_cost_inr}
                      </div>
                    </div>

                    <div className="p-2.5 bg-campus-sand/20 rounded-xl">
                      <span className="text-[10px] text-gray-400 font-bold uppercase">Carbon Emission</span>
                      <div className="text-sm font-black font-mono text-gray-800 mt-0.5">
                        {mode.co2_emissions_kg} kg CO₂
                      </div>
                    </div>

                    <div className="p-2.5 bg-emerald-50 rounded-xl text-emerald-800">
                      <span className="text-[10px] font-bold uppercase text-emerald-600">Eco Reward</span>
                      <div className="text-sm font-black font-mono mt-0.5">
                        +{mode.eco_points_earned} Pts
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => setTab('vehicles')}
                    className="w-full py-2.5 bg-campus-forest hover:bg-campus-emerald text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
                  >
                    <span>Find Matching Vehicles</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}

        </div>
      )}

      {/* Tab 3: AI Predictive Fleet Demand & Surge Radar */}
      {activeSubTab === 'demand-forecast' && (
        <div className="space-y-6">
          
          <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-extrabold text-campus-forest font-display">
                  AI Predictive Fleet Demand & Surge Model
                </h2>
                <p className="text-xs text-gray-500">
                  Real-time machine learning forecast of hourly commuter transit surges across Tamil Nadu campuses.
                </p>
              </div>
              <span className="text-[11px] px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 font-bold font-mono">
                Model: AURA-FleetDemand-v2.4
              </span>
            </div>

            {/* Hourly Surge Table */}
            {demandData && (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-2">
                {demandData.hourly_forecasts.map((f, i) => (
                  <div
                    key={i}
                    className={`p-3.5 rounded-2xl border text-center space-y-1.5 ${
                      f.predicted_demand_level === 'VERY HIGH'
                        ? 'bg-rose-50 border-rose-200 text-rose-900'
                        : f.predicted_demand_level === 'MODERATE'
                        ? 'bg-amber-50 border-amber-200 text-amber-900'
                        : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                    }`}
                  >
                    <div className="text-[10px] font-bold uppercase tracking-wider">{f.time_slot}</div>
                    <div className="text-lg font-black font-mono">{f.surge_multiplier}x</div>
                    <span className="inline-block px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-white/80">
                      {f.predicted_demand_level}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* AI Rebalancing Recommendations */}
          {demandData && demandData.rebalance_actions && (
            <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md p-6 space-y-4">
              <h3 className="text-base font-extrabold text-campus-forest font-display flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-campus-emerald" />
                <span>Automated AI Fleet Rebalancing Instructions</span>
              </h3>

              <div className="space-y-3">
                {demandData.rebalance_actions.map((act) => (
                  <div
                    key={act.action_id}
                    className="p-4 bg-campus-sand/20 border border-campus-border/80 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                          act.priority === 'HIGH' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {act.priority} PRIORITY
                        </span>
                        <span className="font-extrabold text-campus-forest">{act.recommendation}</span>
                      </div>
                      <p className="text-gray-500 text-[11px]">{act.reason}</p>
                    </div>

                    <div className="flex items-center gap-2 font-mono text-[11px] text-gray-700 bg-white px-3 py-1.5 rounded-xl border border-campus-border/60 self-start sm:self-auto">
                      <span>{act.origin_hub}</span>
                      <span>➔</span>
                      <strong className="text-campus-forest">{act.target_hub}</strong>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      )}

      {/* Booking Modal (if vehicle card clicked in chat) */}
      {selectedVehicleForBooking && (
        <BookingModal
          vehicle={selectedVehicleForBooking}
          zones={zones}
          onClose={() => setSelectedVehicleForBooking(null)}
          onSuccess={(booking) => {
            setSelectedVehicleForBooking(null);
            setTab('active-rental');
          }}
        />
      )}

    </div>
  );
}
