import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { useBooking } from '../../context/BookingContext';
import { BookingModal } from '../../components/booking/BookingModal';
import { 
  Zap, Bike, Compass, Sparkles, CheckCircle2, 
  ArrowRight, ShieldCheck, Battery, Users, Clock, Wallet 
} from 'lucide-react';
import { VehicleVisual } from '../../components/common/VehicleVisual';

export function RecommendationWizard({ setTab }) {
  const { zones } = useBooking();
  const [distanceKm, setDistanceKm] = useState(2.5);
  const [passengers, setPassengers] = useState(1);
  const [durationHours, setDurationHours] = useState(1.0);
  const [budget, setBudget] = useState(60);
  const [preference, setPreference] = useState('ALL'); // ALL, ELECTRIC, MANUAL
  const [zoneId, setZoneId] = useState('');

  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selectedBookingVehicle, setSelectedBookingVehicle] = useState(null);

  const handleComputeRecommendation = async () => {
    setLoading(true);
    const res = await apiRequest('/recommendation/', {
      method: 'POST',
      body: JSON.stringify({
        distance_km: Number(distanceKm),
        passengers: Number(passengers),
        duration_hours: Number(durationHours),
        budget: Number(budget),
        preference: preference,
        zone_id: zoneId ? Number(zoneId) : null
      })
    });
    setLoading(false);
    if (res.success) {
      setResults(res);
    }
  };

  useEffect(() => {
    handleComputeRecommendation();
  }, [distanceKm, passengers, durationHours, budget, preference, zoneId]);

  return (
    <div className="space-y-8 pb-16">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-campus-gold/20 border border-campus-gold/40 text-amber-900 text-xs font-bold">
          <Sparkles className="w-3.5 h-3.5 text-amber-600" />
          <span>Intelligent Multi-Criteria Matching</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-campus-forest font-display tracking-tight">
          Smart Vehicle Recommendation Wizard
        </h1>
        <p className="text-xs text-gray-600">
          Tell us your campus trip distance, budget, and passenger requirements to get the best matched vehicle instantly.
        </p>
      </div>

      {/* Interactive Controls & Live Output */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 w-full max-w-full">
        
        {/* Left: Input Criteria Card */}
        <div className="lg:col-span-5 bg-white rounded-3xl border border-campus-border/80 p-6 shadow-md space-y-5 w-full min-w-0">
          <h3 className="font-extrabold text-base text-campus-forest font-display border-b border-gray-100 pb-2">
            Trip Preferences
          </h3>

          {/* Distance Slider */}
          <div>
            <div className="flex justify-between text-xs font-bold text-gray-700 mb-1">
              <span>Trip Distance:</span>
              <span className="text-campus-emerald font-extrabold font-mono text-sm">{distanceKm} km</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="8.0"
              step="0.5"
              value={distanceKm}
              onChange={(e) => setDistanceKm(Number(e.target.value))}
              className="w-full accent-campus-emerald cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-gray-400 font-medium">
              <span>0.5 km (Hostel to Class)</span>
              <span>8.0 km (Full Perimeter)</span>
            </div>
          </div>

          {/* Passenger Count */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-2 flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-campus-forest" />
              <span>Number of Passengers</span>
            </label>
            <div className="grid grid-cols-3 gap-2 text-xs">
              {[
                { val: 1, label: 'Solo Rider (1)' },
                { val: 2, label: 'Dual Riders (2)' },
                { val: 4, label: 'Group (4)' }
              ].map((p) => (
                <button
                  key={p.val}
                  type="button"
                  onClick={() => setPassengers(p.val)}
                  className={`py-2 px-2 rounded-xl font-bold border transition ${
                    passengers === p.val
                      ? 'bg-campus-forest text-white border-campus-forest shadow-sm'
                      : 'bg-campus-sand/20 text-gray-700 border-campus-border/80 hover:bg-campus-sand/50'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Petrol Category Preference */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-2">
              Petrol Vehicle Category Preference
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              {[
                { id: 'ALL', label: '⛽ Any Petrol' },
                { id: 'SCOOTER', label: '🛵 Scooters' },
                { id: 'MOTORCYCLE', label: '🏍️ Motorcycles' },
                { id: 'CRUISER', label: '🦅 Cruisers (350cc)' },
                { id: 'MOPED', label: '🛵 Mopeds' },
                { id: 'CAR', label: '🚗 Cars (4-5S)' }
              ].map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setPreference(opt.id)}
                  className={`py-2 px-2 rounded-xl font-bold border transition text-[11px] ${
                    preference === opt.id
                      ? 'bg-campus-emerald text-white border-campus-emerald shadow-sm'
                      : 'bg-campus-sand/20 text-gray-700 border-campus-border/80 hover:bg-campus-sand/50'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Budget Limit Slider */}
          <div>
            <div className="flex justify-between text-xs font-bold text-gray-700 mb-1">
              <span className="flex items-center gap-1">
                <Wallet className="w-3.5 h-3.5 text-campus-gold" />
                <span>Max Budget:</span>
              </span>
              <span className="text-campus-forest font-extrabold font-mono text-sm">₹{budget}</span>
            </div>
            <input
              type="range"
              min="15"
              max="150"
              step="5"
              value={budget}
              onChange={(e) => setBudget(Number(e.target.value))}
              className="w-full accent-campus-gold cursor-pointer"
            />
          </div>

          {/* Zone Selector */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">
              Filter by Current Zone (Optional)
            </label>
            <select
              value={zoneId}
              onChange={(e) => setZoneId(e.target.value)}
              className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl text-xs"
            >
              <option value="">Any Campus Zone</option>
              {zones.map((z) => (
                <option key={z.id} value={z.id}>{z.name}</option>
              ))}
            </select>
          </div>

        </div>

        {/* Right: Recommendation Results */}
        <div className="lg:col-span-7 space-y-5 w-full min-w-0 max-w-full">
          
          {loading ? (
            <div className="p-16 bg-white rounded-3xl border border-campus-border/80 text-center text-xs text-gray-400">
              <div className="w-8 h-8 border-2 border-campus-emerald border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
              <span>Evaluating suitability score...</span>
            </div>
          ) : results?.top_recommendation ? (
            <div className="space-y-4 w-full min-w-0 max-w-full">
              
              {/* Top Pick Hero Box */}
              <div className="bg-gradient-to-br from-navy-primary via-navy-secondary to-navy-primary text-white rounded-3xl p-5 sm:p-6 shadow-xl border border-blue-500/30 relative overflow-hidden w-full max-w-full break-words">
                {/* Header ribbon badge */}
                <div className="flex justify-between items-start mb-2 sm:mb-0">
                  <span className="text-[10px] uppercase font-bold text-campus-mint tracking-wider sm:hidden">
                    {results.top_recommendation.vehicle.type_name}
                  </span>
                  <div className="sm:absolute top-0 right-0 bg-campus-mint text-navy-primary text-[11px] font-extrabold uppercase px-3.5 py-1.5 sm:rounded-bl-2xl rounded-xl shadow-md flex items-center gap-1.5 z-10">
                    <Sparkles className="w-3.5 h-3.5 flex-shrink-0 text-navy-primary" />
                    <span className="whitespace-nowrap">TOP RECOMMENDATION ({results.top_recommendation.match_score}% Match)</span>
                  </div>
                </div>

                <div className="flex flex-col md:flex-row gap-5 items-start md:items-center pt-2 sm:pt-4 w-full min-w-0">
                  <div className="flex-shrink-0">
                    <VehicleVisual
                      vehicle={results.top_recommendation.vehicle}
                      size="modal"
                      showBadge={false}
                      className="border-2 border-white/20 shadow-lg"
                    />
                  </div>

                  <div className="space-y-2.5 flex-1 text-xs min-w-0 w-full max-w-full">
                    <span className="hidden sm:inline-block text-[10px] uppercase font-bold text-campus-mint tracking-wider">
                      {results.top_recommendation.vehicle.type_name}
                    </span>
                    <h2 className="text-lg sm:text-xl font-extrabold font-display leading-tight break-words text-white">
                      {results.top_recommendation.vehicle.brand} {results.top_recommendation.vehicle.model}
                    </h2>
                    <p className="text-[11px] text-gray-300 font-mono break-words">
                      {results.top_recommendation.vehicle.vehicle_number} • {results.top_recommendation.vehicle.current_zone?.name} • ⛽ {results.top_recommendation.vehicle.engine_cc}cc
                    </p>

                    {/* Human-Readable Explanation Pill */}
                    <div 
                      className="p-3 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/15 text-xs text-white leading-relaxed break-words whitespace-normal w-full max-w-full overflow-hidden"
                      style={{ overflowWrap: 'anywhere', wordBreak: 'break-word' }}
                    >
                      💡 <strong className="text-campus-mint font-bold">Why this fits:</strong> <span className="text-gray-100">{results.top_recommendation.explanation}</span>
                    </div>

                    {/* Pricing & Booking Button Row */}
                    <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 w-full min-w-0">
                      <div>
                        <span className="text-[10px] text-gray-300 uppercase tracking-wider block">Estimated Trip Fare:</span>
                        <div className="text-xl font-extrabold text-campus-mint font-display">
                          ₹{results.top_recommendation.estimated_cost.toFixed(2)}
                        </div>
                      </div>

                      <button
                        onClick={() => setSelectedBookingVehicle(results.top_recommendation.vehicle)}
                        className="w-full sm:w-auto px-5 py-2.5 bg-campus-emerald hover:bg-blue-600 active:bg-blue-700 text-white font-extrabold rounded-2xl shadow-lg transition flex items-center justify-center gap-2 flex-shrink-0"
                      >
                        <span>Book Top Match</span>
                        <ArrowRight className="w-4 h-4 flex-shrink-0" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Secondary Alternatives */}
              <div className="space-y-2 w-full min-w-0 max-w-full">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500">
                  Alternative Campus Options
                </h4>
                <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1 w-full min-w-0">
                  {results.all_recommendations?.slice(1, 6).map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 bg-white rounded-2xl border border-campus-border/80 shadow-sm hover:border-campus-emerald flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs transition w-full min-w-0"
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <VehicleVisual
                          vehicle={item.vehicle}
                          size="thumbnail"
                          showBadge={false}
                          className="flex-shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="font-bold text-campus-forest truncate">{item.vehicle.brand} {item.vehicle.model}</div>
                          <div className="text-[11px] text-gray-500 font-mono truncate">{item.vehicle.vehicle_number} • ₹{item.vehicle.hourly_rate}/hr • ⛽ {item.vehicle.engine_cc}cc</div>
                          <div className="text-[10px] text-campus-emerald truncate">{item.explanation}</div>
                        </div>
                      </div>

                      <div className="flex sm:flex-col items-center sm:items-end justify-between gap-1 flex-shrink-0">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-campus-sand text-campus-forest whitespace-nowrap">
                          {item.match_score}% Match
                        </span>
                        <button
                          onClick={() => setSelectedBookingVehicle(item.vehicle)}
                          className="px-3 py-1 bg-campus-forest hover:bg-campus-secondary text-white rounded-xl text-[11px] font-bold transition whitespace-nowrap"
                        >
                          Book
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          ) : (
            <div className="p-12 bg-white rounded-3xl border text-center text-xs text-gray-500">
              No vehicles available matching these criteria. Try adjusting your preferences.
            </div>
          )}

        </div>

      </div>

      {selectedBookingVehicle && (
        <BookingModal
          vehicle={selectedBookingVehicle}
          zones={zones}
          onClose={() => setSelectedBookingVehicle(null)}
          onSuccess={(b) => {
            setSelectedBookingVehicle(null);
            setTab('active-rental');
          }}
        />
      )}

    </div>
  );
}
