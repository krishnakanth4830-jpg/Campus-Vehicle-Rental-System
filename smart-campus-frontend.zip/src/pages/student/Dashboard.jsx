import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useBooking } from '../../context/BookingContext';
import { apiRequest } from '../../api/client';
import { BookingModal } from '../../components/booking/BookingModal';
import { ReturnToPoolModal } from '../../components/booking/ReturnToPoolModal';
import RenterVerificationModal from '../../components/security/RenterVerificationModal';
import { OfficialCampusQRSection } from '../../components/qr/OfficialCampusQRSection';
import { VehicleVisual } from '../../components/common/VehicleVisual';
import { 
  Bike, Zap, MapPin, Clock, ShieldCheck, Activity, Award, 
  Calendar, ArrowRight, CheckCircle2, AlertCircle, Compass, 
  Fuel, Battery, DollarSign, Leaf, Sparkles, Navigation, 
  QrCode, AlertTriangle, ChevronRight, User, RefreshCw, Layers 
} from 'lucide-react';

export function Dashboard({ setTab }) {
  const { user, isAuthenticated, refreshUser } = useAuth();
  const { activeBooking, vehicles = [], zones = [], fetchVehicles, fetchActiveBooking } = useBooking();

  const [recentBookings, setRecentBookings] = useState([]);
  const [ecoData, setEcoData] = useState(null);
  const [selectedVehicleForBooking, setSelectedVehicleForBooking] = useState(null);
  const [showKYCModal, setShowKYCModal] = useState(false);
  const [showReturnModal, setShowReturnModal] = useState(false);
  const [loadingRecent, setLoadingRecent] = useState(true);

  // Fetch recent rides and eco data
  useEffect(() => {
    async function loadDashboardData() {
      setLoadingRecent(true);
      try {
        const [bookingsRes, ecoRes] = await Promise.all([
          apiRequest('/bookings/my-bookings'),
          apiRequest('/eco/my-score')
        ]);

        if (bookingsRes.success && bookingsRes.bookings) {
          setRecentBookings(bookingsRes.bookings);
        }
        if (ecoRes.success && ecoRes.eco_profile) {
          setEcoData(ecoRes.eco_profile);
        }
      } catch (err) {
        console.error('Failed to load dashboard data:', err);
      } finally {
        setLoadingRecent(false);
      }
    }

    if (isAuthenticated) {
      loadDashboardData();
    }
  }, [isAuthenticated]);

  // Safe data arrays
  const safeVehicles = Array.isArray(vehicles) ? vehicles : [];
  const safeZones = Array.isArray(zones) ? zones : [];

  // Available vehicles list (up to 4 for preview)
  const availableVehicles = useMemo(() => {
    return safeVehicles.filter(v => v && v.status === 'AVAILABLE');
  }, [safeVehicles]);

  const previewVehicles = useMemo(() => {
    if (availableVehicles.length > 0) {
      return availableVehicles.slice(0, 4);
    }
    // Fallback sample vehicles if none yet fetched
    return [
      {
        id: 'f1',
        brand: 'TVS',
        model: 'Jupiter 125 Disc Petrol',
        vehicle_number: 'TN 66 AB 1234',
        owner_name: 'Arun Kumar',
        hourly_rate: 25.0,
        fuel_level_percentage: 85,
        status: 'AVAILABLE',
        current_zone_id: 1,
        type: { category: 'SCOOTER', name: 'Gearless Petrol Scooter' }
      },
      {
        id: 'f2',
        brand: 'Yamaha',
        model: 'FZ-S FI V4 150cc',
        vehicle_number: 'TN 38 CD 4521',
        owner_name: 'Karthik S',
        hourly_rate: 35.0,
        fuel_level_percentage: 90,
        status: 'AVAILABLE',
        current_zone_id: 2,
        type: { category: 'MOTORCYCLE', name: 'Commuter Motorcycle' }
      },
      {
        id: 'f3',
        brand: 'Royal Enfield',
        model: 'Hunter 350 Dapper',
        vehicle_number: 'TN 37 EF 7812',
        owner_name: 'Praveen Kumar',
        hourly_rate: 50.0,
        fuel_level_percentage: 78,
        status: 'AVAILABLE',
        current_zone_id: 1,
        type: { category: 'CRUISER', name: 'Cruiser 350cc' }
      },
      {
        id: 'f4',
        brand: 'TVS',
        model: 'XL100 Heavy Duty',
        vehicle_number: 'TN 39 GH 2365',
        owner_name: 'Rahul M',
        hourly_rate: 15.0,
        fuel_level_percentage: 95,
        status: 'AVAILABLE',
        current_zone_id: 3,
        type: { category: 'MOPED', name: 'Campus Utility Moped' }
      }
    ];
  }, [availableVehicles]);

  // Statistics calculations
  const totalRidesCount = recentBookings.length > 0 ? recentBookings.length : (ecoData?.total_trips || 4);
  const ecoPointsCount = user?.eco_points || ecoData?.total_eco_points || 75;
  const carbonSavedKg = ecoData?.total_co2_saved_kg || (totalRidesCount * 1.2).toFixed(1);
  const moneySavedEstimate = Math.round(totalRidesCount * 25 * 0.15); // 15% student discount savings

  // Format Elapsed Time if active booking exists
  const getElapsedDuration = (startTime) => {
    if (!startTime) return 'Active Now';
    const start = new Date(startTime);
    const now = new Date();
    const diffMins = Math.max(1, Math.floor((now - start) / 60000));
    if (diffMins < 60) return `${diffMins} min`;
    const hours = Math.floor(diffMins / 60);
    const mins = diffMins % 60;
    return `${hours}h ${mins}m`;
  };

  return (
    <div className="space-y-8 pb-16">
      
      {/* ========================================================================= */}
      {/* A. WELCOME SECTION & STUDENT PROFILE BANNER */}
      {/* ========================================================================= */}
      <section className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-campus-forest via-campus-emerald to-emerald-950 text-white shadow-xl p-6 sm:p-8 border border-campus-mint/30">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          
          <div className="flex items-center gap-4">
            {/* Student Avatar */}
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-campus-gold to-amber-500 text-campus-forest font-extrabold text-2xl flex items-center justify-center shadow-lg border-2 border-white/30 shrink-0">
              {user?.name?.charAt(0) || 'S'}
            </div>

            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold font-display tracking-tight text-white">
                  Welcome back, {user?.name || 'Student'}!
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-campus-gold/20 text-campus-gold border border-campus-gold/40">
                  {user?.role || 'STUDENT'}
                </span>
              </div>

              <p className="text-xs sm:text-sm text-campus-mint/90 font-medium">
                Manage your campus rides, rentals, and mobility activity in one place.
              </p>

              <div className="flex flex-wrap items-center gap-3 text-[11px] text-gray-300 pt-1 font-medium">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-campus-gold" />
                  <span>{user?.college_name || 'PSG College of Technology'}</span>
                </span>
                {user?.department && (
                  <span className="hidden sm:inline-block text-campus-mint/60">•</span>
                )}
                {user?.department && (
                  <span className="hidden sm:inline-block text-gray-300">{user.department}</span>
                )}
              </div>
            </div>
          </div>

          {/* Quick Points & Status Pill */}
          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto justify-between md:justify-end shrink-0 border-t md:border-t-0 border-white/10 pt-4 md:pt-0">
            {/* 1. Eco Score */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl px-3.5 py-2.5 text-center min-w-[85px]">
              <div className="text-[10px] uppercase font-bold text-campus-mint tracking-wider flex items-center justify-center gap-1">
                <Leaf className="w-3 h-3 text-campus-mint" />
                <span>Eco Score</span>
              </div>
              <div className="text-base sm:text-lg font-black text-campus-gold font-display">
                {ecoPointsCount} <span className="text-xs font-semibold text-white">pts</span>
              </div>
            </div>

            {/* 2. Wallet Credits */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl px-3.5 py-2.5 text-center min-w-[85px]">
              <div className="text-[10px] uppercase font-bold text-campus-mint tracking-wider flex items-center justify-center gap-1">
                <DollarSign className="w-3 h-3 text-campus-mint" />
                <span>Credits</span>
              </div>
              <div className="text-base sm:text-lg font-black text-white font-display">
                ₹{150 + (ecoPointsCount * 2)}
              </div>
            </div>

            {/* 3. KYC Status Pill Action */}
            <button
              onClick={() => setShowKYCModal(true)}
              className="bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 rounded-2xl px-3.5 py-2.5 text-center transition cursor-pointer min-w-[95px]"
              title="Click to view or verify Student KYC"
            >
              <div className="text-[10px] uppercase font-bold text-blue-200 tracking-wider flex items-center justify-center gap-1">
                <ShieldCheck className="w-3 h-3 text-blue-300" />
                <span>KYC Status</span>
              </div>
              <div className="text-xs sm:text-sm font-black text-white flex items-center justify-center gap-1 mt-0.5">
                {user?.is_verified ? (
                  <span className="text-emerald-400 font-bold flex items-center gap-0.5">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                  </span>
                ) : (
                  <span className="text-amber-300 font-bold flex items-center gap-0.5 animate-pulse">
                    <AlertCircle className="w-3.5 h-3.5" /> Verify
                  </span>
                )}
              </div>
            </button>
          </div>

        </div>
      </section>

      {/* ========================================================================= */}
      {/* B. QUICK STATS CARDS (6 METRIC TILES) */}
      {/* ========================================================================= */}
      <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        
        {/* 1. Active Ride */}
        <div className={`p-4 rounded-2xl border transition shadow-sm ${
          activeBooking 
            ? 'bg-emerald-50/80 border-campus-emerald text-campus-forest ring-1 ring-campus-emerald' 
            : 'bg-white border-campus-border/80'
        }`}>
          <div className="flex items-center justify-between text-gray-500 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Active Ride</span>
            <Activity className={`w-4 h-4 ${activeBooking ? 'text-campus-emerald animate-pulse' : 'text-gray-400'}`} />
          </div>
          <div className="text-base sm:text-lg font-extrabold text-campus-forest font-display truncate">
            {activeBooking ? (activeBooking.vehicle?.vehicle_number || 'In Transit') : '0 Active'}
          </div>
          <p className="text-[10px] text-gray-500 mt-0.5">
            {activeBooking ? 'Ride in progress' : 'Ready to rent'}
          </p>
        </div>

        {/* 2. Total Rides */}
        <div className="p-4 bg-white rounded-2xl border border-campus-border/80 shadow-sm">
          <div className="flex items-center justify-between text-gray-500 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Total Rides</span>
            <Calendar className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-base sm:text-lg font-extrabold text-campus-forest font-display">
            {totalRidesCount}
          </div>
          <p className="text-[10px] text-gray-500 mt-0.5">Campus trips completed</p>
        </div>

        {/* 3. Available Vehicles */}
        <div className="p-4 bg-white rounded-2xl border border-campus-border/80 shadow-sm">
          <div className="flex items-center justify-between text-gray-500 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Available Fleet</span>
            <Bike className="w-4 h-4 text-campus-emerald" />
          </div>
          <div className="text-base sm:text-lg font-extrabold text-campus-emerald font-display">
            {availableVehicles.length || previewVehicles.length}
          </div>
          <p className="text-[10px] text-gray-500 mt-0.5">Vehicles ready at hubs</p>
        </div>

        {/* 4. Eco Score */}
        <div className="p-4 bg-white rounded-2xl border border-campus-border/80 shadow-sm">
          <div className="flex items-center justify-between text-gray-500 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Eco Score</span>
            <Leaf className="w-4 h-4 text-campus-mint" />
          </div>
          <div className="text-base sm:text-lg font-extrabold text-campus-forest font-display">
            {ecoPointsCount} <span className="text-xs font-semibold text-gray-500">pts</span>
          </div>
          <p className="text-[10px] text-gray-500 mt-0.5">Rank: Top 15% Rider</p>
        </div>

        {/* 5. Reward Points */}
        <div className="p-4 bg-white rounded-2xl border border-campus-border/80 shadow-sm">
          <div className="flex items-center justify-between text-gray-500 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Rewards</span>
            <Award className="w-4 h-4 text-campus-gold" />
          </div>
          <div className="text-base sm:text-lg font-extrabold text-amber-700 font-display">
            {ecoPointsCount * 10} <span className="text-xs font-semibold text-gray-500">xp</span>
          </div>
          <p className="text-[10px] text-gray-500 mt-0.5">Silver Tier Badge</p>
        </div>

        {/* 6. Money Saved */}
        <div className="p-4 bg-white rounded-2xl border border-campus-border/80 shadow-sm">
          <div className="flex items-center justify-between text-gray-500 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Savings</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-base sm:text-lg font-extrabold text-emerald-700 font-display">
            ₹{moneySavedEstimate || 75}
          </div>
          <p className="text-[10px] text-gray-500 mt-0.5">15% Student Discount</p>
        </div>

      </section>

      {/* ========================================================================= */}
      {/* C. CURRENT ACTIVE RIDE OR NO ACTIVE RIDE BANNER */}
      {/* ========================================================================= */}
      <section>
        {activeBooking ? (() => {
          const vBrand = activeBooking.vehicle?.brand || activeBooking.brand || activeBooking.vehicle_brand || '';
          const vModel = activeBooking.vehicle?.model || activeBooking.model || activeBooking.vehicle_model || 'Campus Ride';
          const vPlate = activeBooking.vehicle?.vehicle_number || activeBooking.vehicle_number || activeBooking.bike_id || 'TN-38-SC-101';
          const pZone = activeBooking.pickup_zone?.name || activeBooking.pickup_zone_name || 'Main Campus Hub';
          const estFareVal = typeof activeBooking.total_price === 'number' ? activeBooking.total_price.toFixed(1) : (activeBooking.total_price || '25.0');
          const elapsedText = getElapsedDuration(activeBooking.actual_start_time || activeBooking.start_time);

          return (
            <div className="bg-gradient-to-r from-emerald-950 via-campus-forest to-slate-900 text-white rounded-3xl p-6 shadow-xl border-2 border-campus-mint relative overflow-hidden">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
                
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-campus-emerald/60 text-campus-mint text-[11px] font-bold border border-campus-mint/30">
                    <span className="w-2 h-2 rounded-full bg-campus-mint animate-ping"></span>
                    <span>LIVE RENTAL IN PROGRESS</span>
                  </div>

                  <h2 className="text-xl sm:text-2xl font-extrabold font-display text-white">
                    {vBrand} {vModel}
                  </h2>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-gray-200">
                    <span className="font-mono bg-white/15 px-2.5 py-1 rounded-lg border border-white/20 font-bold text-campus-gold">
                      {vPlate}
                    </span>
                    <span className="flex items-center gap-1 text-gray-300">
                      <Clock className="w-3.5 h-3.5 text-campus-gold" />
                      <span>Duration: <strong>{elapsedText}</strong></span>
                    </span>
                    <span className="flex items-center gap-1 text-gray-300">
                      <MapPin className="w-3.5 h-3.5 text-campus-mint" />
                      <span>Hub: <strong>{pZone}</strong></span>
                    </span>
                    <span className="font-bold text-campus-gold bg-white/10 px-2.5 py-0.5 rounded-lg border border-white/15 font-mono">
                      Est. Fare: ₹{estFareVal}
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
                  <button
                    onClick={() => setTab('active-rental')}
                    className="flex-1 md:flex-initial px-5 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-black rounded-xl text-xs shadow-lg transition flex items-center justify-center gap-1.5"
                    title="Open live radar and turn-by-turn navigation HUD"
                  >
                    <Navigation className="w-4 h-4 text-slate-950 fill-slate-950" />
                    <span>Track Ride (HUD)</span>
                  </button>
                  <button
                    onClick={() => setShowReturnModal(true)}
                    className="flex-1 md:flex-initial px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs border border-emerald-400/40 shadow-lg transition flex items-center justify-center gap-1.5"
                    title="Complete trip and return vehicle to pool"
                  >
                    <CheckCircle2 className="w-4 h-4 text-white" />
                    <span>End Ride & Return</span>
                  </button>
                </div>

              </div>
            </div>
          );
        })() : (
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-campus-border/80 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-campus-sand/40 border border-campus-border/80 flex items-center justify-center text-campus-forest shrink-0">
                <Bike className="w-6 h-6 text-campus-emerald" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-extrabold text-base text-campus-forest font-display">No Active Ride</h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-gray-100 text-gray-600">IDLE</span>
                </div>
                <p className="text-xs text-gray-500 mt-0.5">
                  You are not currently riding. 20+ campus vehicles are available for instant pickup.
                </p>
              </div>
            </div>

            <button
              onClick={() => setTab('vehicles')}
              className="w-full sm:w-auto px-5 py-2.5 bg-campus-forest hover:bg-campus-emerald text-white rounded-xl font-bold text-xs shadow-md transition flex items-center justify-center gap-2"
            >
              <span>Rent a Vehicle</span>
              <ArrowRight className="w-4 h-4 text-campus-gold" />
            </button>
          </div>
        )}
      </section>

      {/* ========================================================================= */}
      {/* D. QUICK ACTIONS (6 ACTION BUTTONS/CARDS) */}
      {/* ========================================================================= */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-extrabold uppercase tracking-wider text-campus-forest flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-campus-gold" />
            <span>Quick Mobility Actions</span>
          </h2>
          <span className="text-[11px] text-gray-400">1-Click Fast Access</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 sm:gap-3.5">
          
          {/* Action 1: Rent Vehicle */}
          <button
            onClick={() => setTab('vehicles')}
            className="p-4 bg-white hover:bg-campus-sand/30 border border-campus-border/80 hover:border-campus-emerald rounded-2xl shadow-sm text-left transition space-y-2 group"
          >
            <div className="w-9 h-9 rounded-xl bg-campus-emerald/10 group-hover:bg-campus-forest text-campus-emerald group-hover:text-white flex items-center justify-center transition">
              <Bike className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-xs text-campus-charcoal group-hover:text-campus-forest">Rent Vehicle</div>
              <div className="text-[10px] text-gray-500">Browse TN Fleet</div>
            </div>
          </button>

          {/* Action 2: Student KYC Verification */}
          <button
            onClick={() => setShowKYCModal(true)}
            className="p-4 bg-white hover:bg-blue-50/50 border border-campus-border/80 hover:border-blue-400 rounded-2xl shadow-sm text-left transition space-y-2 group"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-50 group-hover:bg-blue-600 text-blue-600 group-hover:text-white flex items-center justify-center transition">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-xs text-campus-charcoal group-hover:text-blue-900 flex items-center gap-1">
                <span>KYC Verify</span>
                {user?.is_verified && <span className="text-emerald-600 font-bold text-[10px]">✓</span>}
              </div>
              <div className="text-[10px] text-gray-500">{user?.is_verified ? 'Account Verified' : 'Student ID & DL'}</div>
            </div>
          </button>

          {/* Action 3: View My Rides */}
          <button
            onClick={() => setTab('my-bookings')}
            className="p-4 bg-white hover:bg-campus-sand/30 border border-campus-border/80 hover:border-campus-emerald rounded-2xl shadow-sm text-left transition space-y-2 group"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-50 group-hover:bg-blue-600 text-blue-600 group-hover:text-white flex items-center justify-center transition">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-xs text-campus-charcoal group-hover:text-campus-forest">My Rides</div>
              <div className="text-[10px] text-gray-500">History & Invoices</div>
            </div>
          </button>

          {/* Action 4: Live GPS Radar */}
          <button
            onClick={() => setTab('live-gps')}
            className="p-4 bg-white hover:bg-campus-sand/30 border border-campus-border/80 hover:border-campus-emerald rounded-2xl shadow-sm text-left transition space-y-2 group"
          >
            <div className="w-9 h-9 rounded-xl bg-purple-50 group-hover:bg-purple-600 text-purple-600 group-hover:text-white flex items-center justify-center transition">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-xs text-campus-charcoal group-hover:text-campus-forest">Live GPS</div>
              <div className="text-[10px] text-gray-500">Satellite Radar Map</div>
            </div>
          </button>

          {/* Action 5: Smart Match */}
          <button
            onClick={() => setTab('recommendation')}
            className="p-4 bg-white hover:bg-campus-sand/30 border border-campus-border/80 hover:border-campus-emerald rounded-2xl shadow-sm text-left transition space-y-2 group"
          >
            <div className="w-9 h-9 rounded-xl bg-amber-50 group-hover:bg-amber-500 text-amber-600 group-hover:text-white flex items-center justify-center transition">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-xs text-campus-charcoal group-hover:text-campus-forest">Smart Match</div>
              <div className="text-[10px] text-gray-500">AI Ride Wizard</div>
            </div>
          </button>

          {/* Action 6: Scan QR */}
          <button
            onClick={() => setTab('active-rental')}
            className="p-4 bg-white hover:bg-campus-sand/30 border border-campus-border/80 hover:border-campus-emerald rounded-2xl shadow-sm text-left transition space-y-2 group"
          >
            <div className="w-9 h-9 rounded-xl bg-emerald-50 group-hover:bg-campus-emerald text-campus-emerald group-hover:text-white flex items-center justify-center transition">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-xs text-campus-charcoal group-hover:text-campus-forest">Scan QR Code</div>
              <div className="text-[10px] text-gray-500">Instant Unlock</div>
            </div>
          </button>

          {/* Action 7: Report / Carpool */}
          <button
            onClick={() => setTab('emergency-rides')}
            className="p-4 bg-white hover:bg-campus-sand/30 border border-campus-border/80 hover:border-campus-emerald rounded-2xl shadow-sm text-left transition space-y-2 group"
          >
            <div className="w-9 h-9 rounded-xl bg-rose-50 group-hover:bg-rose-600 text-rose-600 group-hover:text-white flex items-center justify-center transition">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-xs text-campus-charcoal group-hover:text-campus-forest">Carpool Help</div>
              <div className="text-[10px] text-gray-500">Exam Commute</div>
            </div>
          </button>

        </div>
      </section>

      {/* Dedicated Section: OFFICIAL CAMPUS QR STICKER */}
      <OfficialCampusQRSection />

      {/* ========================================================================= */}
      {/* E. AVAILABLE CAMPUS VEHICLES PREVIEW */}
      {/* ========================================================================= */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-extrabold text-campus-forest font-display flex items-center gap-2">
              <Bike className="w-5 h-5 text-campus-emerald" />
              <span>Available Campus Vehicles</span>
            </h2>
            <p className="text-xs text-gray-500">Ready for immediate booking across Tamil Nadu college hubs</p>
          </div>

          <button
            onClick={() => setTab('vehicles')}
            className="text-xs font-bold text-campus-forest hover:text-campus-emerald transition flex items-center gap-1"
          >
            <span>View All ({safeVehicles.length || 20})</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {previewVehicles.map((v) => {
            const isPetrol = !v.is_electric;
            const categoryLabel = v.type?.category || 'SCOOTER';
            
            return (
              <div
                key={v.id}
                className="bg-white rounded-3xl border border-campus-border/80 overflow-hidden shadow-sm hover:shadow-md hover:border-campus-emerald transition flex flex-col justify-between group"
              >
                {/* Clean Vector Vehicle Visual (No Photographs) */}
                <div className="relative overflow-hidden">
                  <VehicleVisual vehicle={v} size="preview" showBadge={false} />
                  <div className="absolute top-2.5 left-2.5 z-10">
                    <span className="px-2 py-0.5 rounded-full font-bold bg-campus-forest/90 backdrop-blur text-campus-mint text-[10px] border border-campus-mint/30 shadow-sm">
                      {categoryLabel === 'SCOOTER' && '🛵 Scooter'}
                      {categoryLabel === 'MOTORCYCLE' && '🏍️ Motorcycle'}
                      {categoryLabel === 'CRUISER' && '🏍️ 350cc Cruiser'}
                      {categoryLabel === 'MOPED' && '🛵 Moped'}
                      {categoryLabel === 'CAR' && '🚗 Shuttle Car'}
                      {categoryLabel === 'SUV' && '🚙 SUV'}
                      {categoryLabel === 'VAN' && '🚐 Campus Van'}
                      {categoryLabel === 'BICYCLE' && '🚲 Bicycle'}
                      {categoryLabel === 'EV' && '⚡ Electric EV'}
                    </span>
                  </div>
                  <div className="absolute top-2.5 right-2.5 z-10">
                    <span className="px-2 py-0.5 rounded-full font-bold bg-emerald-600/90 backdrop-blur text-white text-[10px] flex items-center gap-1 shadow-sm">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Ready</span>
                    </span>
                  </div>
                </div>

                <div className="p-4 space-y-2.5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-extrabold text-sm text-campus-charcoal group-hover:text-campus-forest transition font-display">
                      {v.brand} {v.model}
                    </h3>
                    <div className="mt-1 flex flex-col gap-0.5 text-[11px]">
                      <div><span className="text-gray-400 font-medium">Reg:</span> <strong className="font-mono text-campus-forest font-bold">{v.vehicle_number}</strong></div>
                      <div><span className="text-gray-400 font-medium">Owner:</span> <strong className="text-gray-700">{v.owner_name || v.owner?.name || 'Campus Host'}</strong></div>
                    </div>
                  </div>

                  {/* Fuel / Battery Gauge & Hub */}
                  <div className="space-y-1.5 pt-1 border-t border-gray-100 text-xs text-gray-600">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="flex items-center gap-1 text-gray-500">
                        {isPetrol ? <Fuel className="w-3 h-3 text-amber-600" /> : <Battery className="w-3 h-3 text-emerald-600" />}
                        <span>{isPetrol ? 'Fuel Tank' : 'Battery'}</span>
                      </span>
                      <span className="font-bold text-campus-charcoal">{v.fuel_level_percentage || 85}%</span>
                    </div>

                    <div className="flex items-center justify-between text-[11px]">
                      <span className="flex items-center gap-1 text-gray-500">
                        <MapPin className="w-3 h-3 text-campus-emerald" />
                        <span>Pickup Hub</span>
                      </span>
                      <span className="font-semibold text-campus-forest truncate max-w-[130px]">
                        {safeZones.find(z => z.id === v.current_zone_id)?.name?.split(' ')[0] || 'PSG Main Gate'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Price & Rent Button */}
                <div className="pt-3 border-t border-gray-100 flex items-center justify-between">
                  <div>
                    <div className="text-xs text-gray-400">Tariff</div>
                    <div className="text-base font-extrabold text-campus-forest font-display">
                      ₹{v.hourly_rate}<span className="text-[10px] font-normal text-gray-500">/hr</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedVehicleForBooking(v)}
                    className="px-4 py-2 bg-campus-forest hover:bg-campus-emerald text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1"
                  >
                    <span>Rent Now</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* F & G. TWO-COLUMN SPLIT: RECENT RIDES & ECO MOBILITY SECTION */}
      {/* ========================================================================= */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* F. RECENT RIDES HISTORY (7 COLS) */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-campus-border/80 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-extrabold text-campus-forest font-display flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-600" />
                <span>Recent Rides & Trips</span>
              </h2>
              <p className="text-xs text-gray-500">Your recent campus mobility history</p>
            </div>

            <button
              onClick={() => setTab('my-bookings')}
              className="text-xs font-bold text-campus-forest hover:text-campus-emerald transition flex items-center gap-1"
            >
              <span>Full History</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {loadingRecent ? (
            <div className="p-8 text-center text-xs text-gray-400">Loading recent history...</div>
          ) : recentBookings.length === 0 ? (
            <div className="p-8 text-center text-xs text-gray-500 space-y-2">
              <Bike className="w-8 h-8 text-gray-300 mx-auto" />
              <p>No recent trips found. Take your first ride today!</p>
              <button
                onClick={() => setTab('vehicles')}
                className="px-3.5 py-1.5 bg-campus-forest text-white rounded-xl text-xs font-bold"
              >
                Rent a Ride
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {recentBookings.slice(0, 3).map((b) => (
                <div
                  key={b.id}
                  className="p-3.5 rounded-2xl bg-campus-sand/20 border border-campus-border/60 flex items-center justify-between text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="font-extrabold text-campus-charcoal">
                      {b.vehicle?.brand} {b.vehicle?.model}
                    </div>
                    <div className="text-[11px] text-gray-500 flex items-center gap-2 font-mono">
                      <span>{b.booking_code}</span>
                      <span>•</span>
                      <span>{new Date(b.created_at || b.start_time).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <div className="text-right space-y-0.5">
                    <div className="font-extrabold text-campus-forest">
                      ₹{b.total_price || b.base_price}
                    </div>
                    <span className={`inline-block px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                      b.status === 'COMPLETED' ? 'bg-emerald-100 text-emerald-800' :
                      b.status === 'ACTIVE' ? 'bg-amber-100 text-amber-800 animate-pulse' :
                      'bg-gray-100 text-gray-600'
                    }`}>
                      {b.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* G. ECO MOBILITY & CARBON SECTION (5 COLS) */}
        <div className="lg:col-span-5 bg-gradient-to-br from-campus-forest via-emerald-900 to-slate-950 text-white rounded-3xl p-6 shadow-sm space-y-4 border border-campus-mint/30 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-campus-mint text-[10px] font-bold border border-white/20">
                <Leaf className="w-3.5 h-3.5 text-campus-mint" />
                <span>ECO MOBILITY IMPACT</span>
              </span>
              <span className="text-[11px] text-campus-gold font-bold">{ecoPointsCount} Karma Pts</span>
            </div>

            <div>
              <h3 className="text-xl font-extrabold font-display text-white">Campus Clean Commute</h3>
              <p className="text-xs text-gray-300">Reducing campus congestion and footprint</p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="p-3 bg-white/10 rounded-2xl border border-white/10">
                <div className="text-[10px] text-gray-300 font-bold uppercase">CO₂ Offsets</div>
                <div className="text-lg font-black text-campus-mint font-display">{carbonSavedKg} kg</div>
                <div className="text-[9px] text-gray-400">Equivalent to 0.2 trees</div>
              </div>

              <div className="p-3 bg-white/10 rounded-2xl border border-white/10">
                <div className="text-[10px] text-gray-300 font-bold uppercase">Clean Distance</div>
                <div className="text-lg font-black text-campus-gold font-display">
                  {ecoData?.total_distance_km || (totalRidesCount * 3.8).toFixed(1)} km
                </div>
                <div className="text-[9px] text-gray-400">Intra-campus travel</div>
              </div>
            </div>

            {/* Progress to next Tier */}
            <div className="space-y-1.5 pt-2">
              <div className="flex justify-between text-[11px] font-medium text-gray-300">
                <span>Tier Progress (Silver Rider)</span>
                <span className="text-campus-gold font-bold">{ecoPointsCount} / 150 pts</span>
              </div>
              <div className="w-full bg-white/20 rounded-full h-2.5 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-campus-mint to-campus-gold h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, (ecoPointsCount / 150) * 100)}%` }}
                ></div>
              </div>
              <div className="text-[10px] text-campus-mint/80">Earn 75 more points to unlock free 1-hour weekend rides!</div>
            </div>
          </div>

          <button
            onClick={() => setTab('eco-score')}
            className="w-full py-2.5 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-xs font-bold text-center transition flex items-center justify-center gap-1.5"
          >
            <span>View Full Leaderboard & Carbon Details</span>
            <ChevronRight className="w-3.5 h-3.5 text-campus-gold" />
          </button>
        </div>

      </section>

      {/* ========================================================================= */}
      {/* H. CAMPUS MOBILITY HUBS PREVIEW */}
      {/* ========================================================================= */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-extrabold text-campus-forest font-display flex items-center gap-2">
              <MapPin className="w-5 h-5 text-campus-gold" />
              <span>Campus Return & Pickup Hubs</span>
            </h2>
            <p className="text-xs text-gray-500">Designated geofenced mobility stations across Tamil Nadu</p>
          </div>

          <button
            onClick={() => setTab('live-gps')}
            className="text-xs font-bold text-campus-forest hover:text-campus-emerald transition flex items-center gap-1"
          >
            <span>Explore on Radar Map</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {(safeZones.length > 0 ? safeZones.slice(0, 4) : [
            { id: 1, name: 'PSG Tech Main Entrance', city: 'Coimbatore', capacity: 35, college_name: 'PSG College of Technology' },
            { id: 2, name: 'IIT Madras Gajendra Circle', city: 'Chennai', capacity: 40, college_name: 'IIT Madras' },
            { id: 3, name: 'NIT Trichy Octagon Center', city: 'Tiruchirappalli', capacity: 30, college_name: 'NIT Trichy' },
            { id: 4, name: 'VIT Vellore Technology Tower', city: 'Vellore', capacity: 45, college_name: 'VIT University' }
          ]).map((z) => {
            const hubVehiclesCount = safeVehicles.filter(v => v.current_zone_id === z.id && v.status === 'AVAILABLE').length || 4;
            
            return (
              <div
                key={z.id}
                className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm hover:border-campus-emerald transition space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-campus-emerald">
                      {z.city || 'Tamil Nadu'}
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-campus-mint/20 text-campus-forest border border-campus-mint/40">
                      {hubVehiclesCount} Available
                    </span>
                  </div>

                  <h3 className="font-extrabold text-sm text-campus-charcoal font-display">
                    {z.name}
                  </h3>

                  <p className="text-[11px] text-gray-500 line-clamp-1">
                    {z.college_name || 'Tamil Nadu Campus'}
                  </p>

                  <div className="text-[10px] font-mono text-gray-400 pt-1">
                    Capacity: {z.capacity || 30} parking slots
                  </div>
                </div>

                <button
                  onClick={() => setTab('live-gps')}
                  className="w-full py-2 bg-campus-sand/40 hover:bg-campus-forest hover:text-white text-campus-forest rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 border border-campus-border/60"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>View Location</span>
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Booking Modal Popup if user clicks "Rent Now" on a preview card */}
      {selectedVehicleForBooking && (
        <BookingModal
          vehicle={selectedVehicleForBooking}
          zones={safeZones}
          onClose={() => setSelectedVehicleForBooking(null)}
          onSuccess={() => {
            setSelectedVehicleForBooking(null);
            setTab('active-rental');
          }}
        />
      )}

      {/* Mandatory KYC Renter Verification Modal */}
      {showKYCModal && (
        <RenterVerificationModal
          isOpen={showKYCModal}
          onClose={() => setShowKYCModal(false)}
          onSuccess={() => {
            setShowKYCModal(false);
            if (refreshUser) refreshUser();
          }}
        />
      )}

      {/* Return To Pool Modal from Dashboard */}
      {showReturnModal && activeBooking && (
        <ReturnToPoolModal
          booking={activeBooking}
          zones={safeZones}
          onClose={() => setShowReturnModal(false)}
          onSuccess={async (res) => {
            setShowReturnModal(false);
            if (fetchActiveBooking) await fetchActiveBooking();
            if (fetchVehicles) await fetchVehicles();
            if (refreshUser) await refreshUser();
            setTab('eco-score');
          }}
        />
      )}

    </div>
  );
}
