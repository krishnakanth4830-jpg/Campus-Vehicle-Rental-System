import React, { useState, useEffect } from 'react';
import { useBooking } from '../../context/BookingContext';
import { CampusLiveGPSMap } from '../../components/map/CampusLiveGPSMap';
import { BookingModal } from '../../components/booking/BookingModal';
import { 
  Radio, Navigation, Shield, Fuel, Gauge, Compass, 
  MapPin, Activity, AlertTriangle, ChevronRight, RefreshCw, GraduationCap 
} from 'lucide-react';
import { apiRequest } from '../../api/client';

export function LiveGPSPage({ setTab, onBookingSuccess }) {
  const { zones } = useBooking();
  const [fleetGPS, setFleetGPS] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedVehicleForBooking, setSelectedVehicleForBooking] = useState(null);
  const [selectedVehicleId, setSelectedVehicleId] = useState(null);
  const [selectedCollege, setSelectedCollege] = useState('');

  const loadFleetGPS = async () => {
    try {
      const url = `/gps/live-fleet?college=${encodeURIComponent(selectedCollege || '')}`;
      const res = await apiRequest(url);
      if (res.success && res.fleet) {
        setFleetGPS(res.fleet);
      }
      setLoading(false);
    } catch (e) {
      console.error(e);
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFleetGPS();
    const interval = setInterval(loadFleetGPS, 3500);
    return () => clearInterval(interval);
  }, [selectedCollege]);

  const handleBookingSuccess = (booking) => {
    setSelectedVehicleForBooking(null);
    if (onBookingSuccess) onBookingSuccess(booking);
    setTab('active-rental');
  };

  // Metrics
  const movingVehicles = fleetGPS.filter(v => v.is_moving || (v.speed_kmh && v.speed_kmh > 0));
  const inUseVehicles = fleetGPS.filter(v => v.status === 'IN_USE');

  return (
    <div className="space-y-6 pb-16">
      
      {/* Top Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-extrabold uppercase tracking-widest text-campus-emerald flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 animate-pulse text-emerald-500" />
            <span>REAL-TIME SATELLITE TELEMETRY & GEOFENCE MONITOR</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-campus-forest font-display tracking-tight mt-0.5">
            Live Campus GPS Radar
          </h1>
          <p className="text-xs text-gray-500">
            Real-time GPS coordinates, vehicle speeds, and campus geofencing across all Tamil Nadu institutions.
          </p>
        </div>

        {/* Status Indicators */}
        <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
          <div className="px-3 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-2xl text-xs font-bold flex items-center gap-1.5 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            <span>{movingVehicles.length} Moving Live</span>
          </div>
          <div className="px-3 py-1.5 bg-blue-50 text-blue-800 border border-blue-300 rounded-2xl text-xs font-bold flex items-center gap-1.5 shadow-sm">
            <Activity className="w-3.5 h-3.5 text-blue-600" />
            <span>{inUseVehicles.length} Active Trips</span>
          </div>
        </div>
      </div>

      {/* Main GPS Map Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left / Center Map (8 cols) */}
        <div className="lg:col-span-8">
          <CampusLiveGPSMap 
            zones={zones}
            selectedVehicleId={selectedVehicleId}
            onSelectVehicle={(veh) => setSelectedVehicleId(veh.id)}
            onSelectBooking={(veh) => setSelectedVehicleForBooking(veh)}
            onFleetUpdate={(fleet) => setFleetGPS(fleet)}
            selectedCollegeProp={selectedCollege}
            onCollegeChangeProp={setSelectedCollege}
            height="580px"
          />
        </div>

        {/* Right Side: Live Fleet Telemetry Stream (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          
          <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md p-5">
            <div className="flex items-center justify-between border-b pb-3 mb-3">
              <h3 className="font-extrabold text-sm text-campus-forest font-display flex items-center gap-1.5">
                <Navigation className="w-4 h-4 text-campus-emerald" />
                <span>Live Telemetry Stream</span>
              </h3>
              <span className="text-[10px] font-mono text-gray-400">Total {fleetGPS.length} Units</span>
            </div>

            {fleetGPS.length === 0 ? (
              <div className="text-center py-8 text-xs text-gray-400">
                <Radio className="w-8 h-8 mx-auto text-gray-300 mb-2" />
                <p className="font-bold text-gray-600">No Vehicles Active in Pool</p>
                <p className="text-[11px] mt-1">Deploy vehicles via the Owner Portal to observe live GPS signals.</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
                {fleetGPS.map((veh) => (
                  <div 
                    key={veh.id}
                    onClick={() => setSelectedVehicleId(veh.id)}
                    className={`p-3 border rounded-2xl transition space-y-2 text-xs cursor-pointer ${
                      selectedVehicleId === veh.id 
                        ? 'bg-blue-50/70 border-campus-emerald shadow-sm ring-1 ring-campus-emerald/40' 
                        : 'bg-campus-sand/20 hover:bg-campus-sand/50 border-campus-border/60'
                    }`}
                  >
                    {/* Top line: Plate + Status */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono font-black text-xs text-campus-forest">{veh.vehicle_number}</span>
                        <span className="text-[10px] text-gray-500">({veh.category})</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                        veh.status === 'AVAILABLE' ? 'bg-emerald-100 text-emerald-800' :
                        veh.status === 'IN_USE' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {veh.status}
                      </span>
                    </div>

                    {/* Model & College */}
                    <div>
                      <div className="font-bold text-gray-800">{veh.brand} {veh.model}</div>
                      <div className="text-[10px] text-gray-500 font-medium truncate">{veh.college_name} • {veh.city}</div>
                    </div>

                    {/* Speed & Fuel Bar */}
                    <div className="flex items-center justify-between pt-1 border-t border-gray-100 text-[11px]">
                      <span className="font-mono font-bold text-campus-forest flex items-center gap-1">
                        <Gauge className="w-3 h-3 text-campus-emerald" />
                        <span>{Math.round(veh.speed_kmh)} km/h</span>
                      </span>

                      <span className="font-bold text-campus-emerald flex items-center gap-1">
                        <Fuel className="w-3 h-3 text-campus-gold" />
                        <span>⛽ {veh.fuel_level_percentage}% Tank</span>
                      </span>
                    </div>

                    {/* Quick Action Button */}
                    {veh.status === 'AVAILABLE' && (
                      <button
                        onClick={() => setSelectedVehicleForBooking(veh)}
                        className="w-full mt-1 py-1.5 bg-campus-forest hover:bg-campus-emerald text-white rounded-xl text-[11px] font-bold transition flex items-center justify-center gap-1"
                      >
                        <span>Book Instant Ride</span>
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Campus Speed & Safety Card */}
          <div className="bg-gradient-to-br from-campus-forest to-emerald-950 text-white rounded-3xl p-4 shadow-md text-xs space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-campus-mint">
              <Shield className="w-4 h-4" />
              <span>Campus Geofence & Speed Policy</span>
            </div>
            <p className="text-[11px] text-gray-200 leading-relaxed">
              Automatic speed governing enforces a <strong>35 km/h limit</strong> inside campus corridors. Leaving the 1.5 km perimeter activates safety alerts.
            </p>
          </div>

        </div>

      </div>

      {/* Booking Modal */}
      {selectedVehicleForBooking && (
        <BookingModal
          vehicle={selectedVehicleForBooking}
          zones={zones}
          onClose={() => setSelectedVehicleForBooking(null)}
          onSuccess={handleBookingSuccess}
        />
      )}

    </div>
  );
}
