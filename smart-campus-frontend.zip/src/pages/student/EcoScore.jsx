import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { Leaf, Award, Zap, Bike, Flame, TreeDeciduous, Trophy, ArrowRight } from 'lucide-react';

export function EcoScore() {
  const [ecoData, setEcoData] = useState(null);
  const [leaderboard, setLeaderboard] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      const [scoreRes, leaderRes] = await Promise.all([
        apiRequest('/eco/my-score'),
        apiRequest('/eco/leaderboard')
      ]);

      if (scoreRes.success) setEcoData(scoreRes.eco_profile);
      if (leaderRes.success) setLeaderboard(leaderRes.leaderboard);
      setLoading(false);
    }
    loadData();
  }, []);

  return (
    <div className="space-y-8 pb-16">
      
      {/* Title */}
      <div>
        <span className="text-[10px] font-extrabold uppercase tracking-widest text-campus-emerald">
          GREEN CAMPUS REWARDS
        </span>
        <h1 className="text-2xl font-extrabold text-campus-forest font-display tracking-tight">
          Eco Score & Carbon Impact Tracker
        </h1>
        <p className="text-xs text-gray-500">
          Track your clean energy mobility, estimated CO₂ offsets, fitness calories, and campus sustainability rank.
        </p>
      </div>

      {/* Highlights Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-gradient-to-br from-campus-forest to-campus-emerald text-white rounded-3xl p-5 shadow-lg space-y-2">
          <div className="flex justify-between items-center text-xs text-campus-mint font-bold">
            <span>Eco Karma Points</span>
            <Award className="w-4 h-4 text-campus-gold" />
          </div>
          <div className="text-3xl font-extrabold font-display text-campus-mint">
            {ecoData?.total_eco_points || 50} pts
          </div>
          <p className="text-[10px] text-gray-300">Earn +20 pts for every Return-to-Pool drop-off</p>
        </div>

        <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-2">
          <div className="flex justify-between items-center text-xs text-gray-500 font-bold">
            <span>CO₂ Emissions Saved</span>
            <Leaf className="w-4 h-4 text-campus-emerald" />
          </div>
          <div className="text-3xl font-extrabold text-campus-forest font-display">
            {ecoData?.total_co2_saved_kg || '0.00'} kg
          </div>
          <p className="text-[10px] text-gray-500">Equivalent to ~{ecoData?.tree_equivalent_planted || 0} mature campus trees</p>
        </div>

        <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-2">
          <div className="flex justify-between items-center text-xs text-gray-500 font-bold">
            <span>Pedal Calories Burned</span>
            <Flame className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-3xl font-extrabold text-campus-forest font-display">
            {ecoData?.total_calories_burned || 0} kcal
          </div>
          <p className="text-[10px] text-gray-500">From manual pedal bicycles & push scooters</p>
        </div>

        <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-2">
          <div className="flex justify-between items-center text-xs text-gray-500 font-bold">
            <span>Clean Distance</span>
            <Bike className="w-4 h-4 text-campus-forest" />
          </div>
          <div className="text-3xl font-extrabold text-campus-forest font-display">
            {ecoData?.total_distance_km || '0.0'} km
          </div>
          <p className="text-[10px] text-gray-500">Total micro-mobility distance across campus</p>
        </div>

      </div>

      {/* Leaderboard Table */}
      <div className="bg-white rounded-3xl border border-campus-border/80 p-6 shadow-md space-y-4">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-campus-gold" />
            <h3 className="font-extrabold text-base text-campus-forest font-display">
              Campus Green Mobility Leaderboard
            </h3>
          </div>
          <span className="text-[10px] text-gray-400 font-semibold">Updated Real-Time</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-gray-100 text-[10px] uppercase tracking-wider text-gray-400">
                <th className="py-2.5 px-3">Rank</th>
                <th className="py-2.5 px-3">Campus Member</th>
                <th className="py-2.5 px-3">Department</th>
                <th className="py-2.5 px-3">Role</th>
                <th className="py-2.5 px-3 text-right">Eco Points</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {leaderboard.map((item) => (
                <tr key={item.rank} className="hover:bg-campus-sand/20 transition">
                  <td className="py-3 px-3 font-bold">
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] ${
                      item.rank === 1 ? 'bg-amber-100 text-amber-900 font-extrabold' :
                      item.rank === 2 ? 'bg-gray-100 text-gray-800' :
                      item.rank === 3 ? 'bg-amber-50 text-amber-800' : 'text-gray-500'
                    }`}>
                      {item.rank}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-bold text-campus-forest">{item.name}</td>
                  <td className="py-3 px-3 text-gray-600">{item.department}</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-campus-sand text-campus-forest">
                      {item.role}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right font-extrabold text-campus-emerald font-mono">
                    {item.eco_points} pts
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
