import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { 
  Calendar, Bike, Clock, MapPin, CheckCircle2, 
  Receipt, Star, ArrowRight, ShieldCheck 
} from 'lucide-react';

export function MyBookings({ setTab }) {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedReceipt, setSelectedReceipt] = useState(null);

  useEffect(() => {
    async function loadBookings() {
      const res = await apiRequest('/bookings/my-bookings');
      if (res.success && res.bookings) {
        setBookings(res.bookings);
      }
      setLoading(false);
    }
    loadBookings();
  }, []);

  return (
    <div className="space-y-6 pb-16">
      
      {/* Title */}
      <div>
        <span className="text-[10px] font-extrabold uppercase tracking-widest text-campus-emerald">
          RIDER HISTORY & INVOICES
        </span>
        <h1 className="text-2xl font-extrabold text-campus-forest font-display tracking-tight">
          My Campus Rides
        </h1>
        <p className="text-xs text-gray-500">
          Review your previous vehicle rentals, duration receipts, and student discounts.
        </p>
      </div>

      {/* Bookings List */}
      {loading ? (
        <div className="p-16 text-center text-xs text-gray-400">Loading Ride History...</div>
      ) : bookings.length === 0 ? (
        <div className="bg-white rounded-3xl border border-campus-border/80 p-12 text-center max-w-md mx-auto space-y-3">
          <Calendar className="w-10 h-10 text-gray-300 mx-auto" />
          <h3 className="font-extrabold text-sm text-campus-forest">No Rides Yet</h3>
          <p className="text-xs text-gray-500">You haven't booked any campus vehicles yet.</p>
          <button
            onClick={() => setTab('vehicles')}
            className="px-4 py-2 bg-campus-forest text-white rounded-xl text-xs font-bold"
          >
            Book Your First Ride
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {bookings.map((b) => (
            <div
              key={b.id}
              className="bg-white rounded-2xl border border-campus-border/80 p-4 sm:p-5 shadow-sm hover:border-campus-emerald transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs"
            >
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-campus-forest">{b.booking_code}</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                    b.status === 'COMPLETED' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                    b.status === 'ACTIVE' ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                    b.status === 'CONFIRMED' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                    'bg-gray-100 text-gray-600'
                  }`}>
                    {b.status}
                  </span>
                </div>

                <div className="font-extrabold text-sm text-campus-forest font-display">
                  {b.vehicle_model}
                </div>
                <div className="text-[11px] text-gray-600 flex items-center gap-2">
                  <span>Vehicle: <strong className="font-mono text-campus-forest">{b.vehicle_number}</strong></span>
                  <span>•</span>
                  <span>Owner: <strong className="text-gray-800">{b.owner_name || 'Campus Host'}</strong></span>
                </div>

                <div className="flex flex-wrap gap-x-4 gap-y-1 text-gray-500 text-[11px]">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-campus-emerald" />
                    <span>From: {b.pickup_zone_name}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-campus-gold" />
                    <span>To: {b.return_zone_name || b.pickup_zone_name}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-gray-400" />
                    <span>{b.duration_hours} hr</span>
                  </span>
                </div>
              </div>

              {/* Price & Receipt CTA */}
              <div className="flex items-center gap-3 self-end sm:self-center">
                <div className="text-right">
                  <div className="text-[10px] uppercase font-bold text-gray-400">Total Paid</div>
                  <div className="text-base font-extrabold text-campus-forest">₹{b.total_price.toFixed(2)}</div>
                </div>

                <button
                  onClick={() => setSelectedReceipt(b)}
                  className="px-3 py-1.5 bg-campus-sand/40 hover:bg-campus-sand text-campus-forest border border-campus-border/80 rounded-xl font-bold text-xs transition flex items-center gap-1.5"
                >
                  <Receipt className="w-3.5 h-3.5" />
                  <span>Receipt</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Receipt Modal */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full border border-campus-border/80 shadow-2xl p-6 space-y-4 text-xs">
            <div className="text-center border-b pb-3 space-y-1">
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-campus-emerald">
                CAMPUS MOBILITY E-RECEIPT
              </span>
              <h3 className="font-extrabold text-base text-campus-forest">{selectedReceipt.booking_code}</h3>
              <p className="text-[11px] text-gray-400">{selectedReceipt.created_at}</p>
            </div>

            <div className="space-y-2 text-gray-600">
              <div className="flex justify-between">
                <span>Vehicle:</span>
                <span className="font-bold text-campus-forest">{selectedReceipt.vehicle_model}</span>
              </div>
              <div className="flex justify-between">
                <span>Rider Name:</span>
                <span className="font-bold">{selectedReceipt.user_name}</span>
              </div>
              <div className="flex justify-between">
                <span>Student ID:</span>
                <span className="font-mono font-bold">{selectedReceipt.user_student_id}</span>
              </div>
              <div className="flex justify-between">
                <span>Duration:</span>
                <span>{selectedReceipt.duration_hours} hr</span>
              </div>
              <div className="flex justify-between">
                <span>Base Rate:</span>
                <span>₹{selectedReceipt.duration_charge.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-campus-emerald font-semibold">
                <span>Student / Off-Peak Discount:</span>
                <span>-₹{selectedReceipt.discount_amount.toFixed(2)}</span>
              </div>
              {selectedReceipt.late_fee > 0 && (
                <div className="flex justify-between text-rose-600 font-semibold">
                  <span>Late Fee:</span>
                  <span>+₹{selectedReceipt.late_fee.toFixed(2)}</span>
                </div>
              )}
              <div className="pt-2 border-t flex justify-between font-extrabold text-sm text-campus-forest">
                <span>Total Amount:</span>
                <span>₹{selectedReceipt.total_price.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={() => setSelectedReceipt(null)}
              className="w-full py-2 bg-campus-forest text-white rounded-xl font-bold"
            >
              Close Receipt
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
