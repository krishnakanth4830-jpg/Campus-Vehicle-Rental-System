import React, { useState, useEffect } from 'react';
import { 
  Search, 
  ShieldCheck, 
  ShieldAlert, 
  Bike, 
  UserCheck, 
  FileCheck2, 
  PhoneCall, 
  Calendar, 
  AlertTriangle, 
  Eye, 
  Lock, 
  Unlock, 
  Clock, 
  CheckCircle2, 
  FileText,
  MapPin
} from 'lucide-react';
import { securityApi } from '../../api/services';
import { useAuth } from '../../context/AuthContext';
import IncidentReportModal from '../../components/security/IncidentReportModal';
import { VehicleVisual } from '../../components/common/VehicleVisual';

export default function BikeLookupPage() {
  const { user } = useAuth();
  const [query, setQuery] = useState('CAMP-BIKE-001');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);
  const [isStaffView, setIsStaffView] = useState(false);
  const [showIncidentModal, setShowIncidentModal] = useState(false);

  // Quick lookup suggestions
  const sampleCodes = ['CAMP-BIKE-001', 'CAMP-BIKE-002', 'CAMP-BIKE-007', 'TN-38-SC-101'];

  useEffect(() => {
    handleSearch('CAMP-BIKE-001');
  }, []);

  const handleSearch = async (targetQuery = query) => {
    const q = (targetQuery || query).trim();
    if (!q) return;

    try {
      setLoading(true);
      setError(null);
      const res = await securityApi.lookupBike(q);
      if (res.data?.success) {
        setResult(res.data.vehicle);
        setIsStaffView(res.data.is_staff_view);
      } else {
        setError(res.data?.message || 'Vehicle not found in campus registry.');
        setResult(null);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Vehicle not found or security record unavailable.');
      setResult(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pt-20 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header Title */}
        <div className="bg-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl border border-slate-800 relative overflow-hidden">
          <div className="absolute right-0 top-0 translate-x-10 -translate-y-10 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30 mb-3">
                <ShieldCheck className="w-3.5 h-3.5" /> CAMPUS VEHICLE REGISTRY & SECURITY LOOKUP
              </div>
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                "Who Owns This Bike?"
              </h1>
              <p className="text-sm text-slate-300 mt-1 max-w-xl">
                Official Campus Safety Registry. Verify vehicle credentials, safety compliance, owner verification badges, and live rental status.
              </p>
            </div>

            {user?.role === 'ADMIN' || user?.role === 'STAFF' ? (
              <div className="px-3 py-2 rounded-xl bg-blue-950/60 border border-blue-800 text-blue-300 text-xs flex items-center gap-2">
                <Unlock className="w-4 h-4 text-blue-400" />
                <span>Security Officer Decrypted View Active</span>
              </div>
            ) : (
              <div className="px-3 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-300 text-xs flex items-center gap-2">
                <Lock className="w-4 h-4 text-slate-400" />
                <span>Public Masked Safe View</span>
              </div>
            )}
          </div>

          {/* Search Box */}
          <form 
            onSubmit={(e) => { e.preventDefault(); handleSearch(); }}
            className="mt-6 flex flex-col sm:flex-row gap-2 relative z-10"
          >
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-3 w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Enter Bike ID (e.g. CAMP-BIKE-001) or Registration Plate"
                className="w-full pl-11 pr-4 py-2.5 text-sm bg-slate-800/90 border border-slate-700 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-semibold text-sm rounded-xl shadow-lg shadow-blue-500/20 disabled:opacity-50 flex items-center justify-center gap-2 transition"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  <span>Verify Bike</span>
                </>
              )}
            </button>
          </form>

          {/* Quick links */}
          <div className="mt-3 flex items-center gap-2 flex-wrap text-xs text-slate-400 relative z-10">
            <span>Quick search:</span>
            {sampleCodes.map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => { setQuery(code); handleSearch(code); }}
                className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-mono transition"
              >
                {code}
              </button>
            ))}
          </div>
        </div>

        {/* Error Notification */}
        {error && (
          <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-500 text-sm flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Vehicle Not Found</p>
              <p className="text-xs mt-0.5">{error}</p>
            </div>
          </div>
        )}

        {/* Search Result Card */}
        {result && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            {/* Top Badge Header */}
            <div className="px-6 py-4 bg-slate-100 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center space-x-3">
                <VehicleVisual
                  vehicle={result}
                  size="small"
                  showBadge={false}
                  className="border-2 border-white dark:border-slate-700 shadow-md flex-shrink-0"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                      {result.brand} {result.model}
                    </h2>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> {result.verification_badge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Campus ID: <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{result.bike_id}</span> • Type: {result.vehicle_type}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowIncidentModal(true)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/30 flex items-center gap-1.5 transition"
                >
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>Report Incident</span>
                </button>
              </div>
            </div>

            {/* Main Content Details */}
            <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Left Column: Vehicle & Compliance */}
              <div className="space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <FileCheck2 className="w-4 h-4 text-blue-600" /> Vehicle Security Credentials
                </h3>

                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-200 dark:border-slate-700/60 space-y-3">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-xs text-slate-500 dark:text-slate-400">Registration Plate:</span>
                    <span className="font-mono font-bold text-slate-900 dark:text-white bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded text-xs">
                      {result.registration_number}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-sm">
                    <span className="text-xs text-slate-500 dark:text-slate-400">Campus Status:</span>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                      result.status === 'AVAILABLE' ? 'bg-emerald-500/10 text-emerald-500' :
                      result.status === 'IN_USE' ? 'bg-amber-500/10 text-amber-500' : 'bg-rose-500/10 text-rose-500'
                    }`}>
                      {result.status}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-sm">
                    <span className="text-xs text-slate-500 dark:text-slate-400">Current Campus Hub:</span>
                    <span className="font-medium text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-blue-500" /> {result.current_zone}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-sm">
                    <span className="text-xs text-slate-500 dark:text-slate-400">Insurance Validity:</span>
                    <span className="font-medium text-emerald-600 dark:text-emerald-400 text-xs flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> {result.insurance_status}
                      {result.insurance_expiry_date && ` (Exp: ${result.insurance_expiry_date})`}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-sm">
                    <span className="text-xs text-slate-500 dark:text-slate-400">RC & Pollution Compliance:</span>
                    <span className="font-medium text-blue-600 dark:text-blue-400 text-xs">
                      ✓ RC VERIFIED • POLLUTION VALID
                    </span>
                  </div>
                </div>
              </div>

              {/* Right Column: Owner & Current Rental Security */}
              <div className="space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-blue-600" /> Verified Owner & Operator Record
                </h3>

                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-200 dark:border-slate-700/60 space-y-3">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-xs text-slate-500 dark:text-slate-400">Registered Owner:</span>
                    <span className="font-semibold text-slate-900 dark:text-white text-xs flex items-center gap-1">
                      {result.owner?.name}
                      {result.owner?.is_verified && (
                        <span className="text-blue-500 text-xs font-bold">✓</span>
                      )}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-sm">
                    <span className="text-xs text-slate-500 dark:text-slate-400">Department / Operator:</span>
                    <span className="font-medium text-slate-800 dark:text-slate-200 text-xs">
                      {result.owner?.department || 'Campus Transport'}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-sm">
                    <span className="text-xs text-slate-500 dark:text-slate-400">Security Contact / Phone:</span>
                    <span className="font-mono text-slate-800 dark:text-slate-200 text-xs">
                      {result.owner?.phone}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-sm">
                    <span className="text-xs text-slate-500 dark:text-slate-400">Security Desk Helpline:</span>
                    <span className="font-semibold text-blue-600 dark:text-blue-400 text-xs flex items-center gap-1">
                      <PhoneCall className="w-3 h-3" /> {result.security_helpline}
                    </span>
                  </div>
                </div>

                {/* Staff Decrypted Active Rental Details */}
                {isStaffView && result.current_rental && (
                  <div className="p-3.5 bg-blue-950/40 rounded-xl border border-blue-800/70 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-blue-300 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5" /> Active Live Rental Details
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                        {result.current_rental.booking_code}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs text-slate-300 pt-1">
                      <div>
                        <span className="text-slate-400 block text-[10px]">Renter Name:</span>
                        <span className="font-semibold text-white">{result.current_rental.renter_name}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Student ID:</span>
                        <span className="font-mono text-white">{result.current_rental.renter_id || 'N/A'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Renter Phone:</span>
                        <span className="font-mono text-white">{result.current_rental.renter_phone || 'N/A'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Ride Start Time:</span>
                        <span className="text-white">{result.current_rental.start_time || 'In Progress'}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Incident Modal */}
      {showIncidentModal && result && (
        <IncidentReportModal
          isOpen={showIncidentModal}
          onClose={() => setShowIncidentModal(false)}
          vehicleId={result.id}
          onSuccess={() => handleSearch()}
        />
      )}
    </div>
  );
}
