import React, { useState, useEffect } from 'react';
import { useBooking } from '../../context/BookingContext';
import { VehicleCard } from '../../components/vehicle/VehicleCard';
import { VehicleFilter } from '../../components/vehicle/VehicleFilter';
import { BookingModal } from '../../components/booking/BookingModal';
import { VehicleQRDisplayModal } from '../../components/qr/VehicleQRDisplayModal';
import { Bike, Zap, Filter, Compass } from 'lucide-react';

export function VehicleCatalog({ setTab, onBookingSuccess }) {
  const { zones, vehicles, loading, fetchVehicles } = useBooking();
  const [filters, setFilters] = useState({
    search: '',
    zone_id: '',
    is_electric: 'ALL',
    status: 'AVAILABLE',
    max_rate: 100,
    min_health: 80
  });

  const [selectedVehicleForBooking, setSelectedVehicleForBooking] = useState(null);
  const [selectedVehicleForQR, setSelectedVehicleForQR] = useState(null);

  useEffect(() => {
    fetchVehicles(filters);
  }, [filters, fetchVehicles]);

  const handleBookingCompleted = (booking) => {
    setSelectedVehicleForBooking(null);
    if (onBookingSuccess) onBookingSuccess(booking);
    setTab('active-rental');
  };

  return (
    <div className="space-y-6 pb-16">
      
      {/* Title Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-extrabold uppercase tracking-widest text-campus-emerald">
            CAMPUS MICRO-MOBILITY FLEET
          </span>
          <h1 className="text-2xl font-extrabold text-campus-forest font-display tracking-tight">
            Browse Campus Vehicles
          </h1>
          <p className="text-xs text-gray-500">
            Select from standard pedal cycles, geared mountain bikes, manual scooters, and smart e-scooters.
          </p>
        </div>

        <button
          onClick={() => setTab('recommendation')}
          className="px-4 py-2.5 bg-campus-gold/20 hover:bg-campus-gold/30 text-amber-900 border border-campus-gold/50 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Zap className="w-4 h-4 text-amber-600 fill-amber-600" />
          <span>Need Help? Use Recommendation Wizard</span>
        </button>
      </div>

      {/* Filter Component */}
      <VehicleFilter
        zones={zones}
        filters={filters}
        setFilters={setFilters}
        onReset={() => setFilters({ search: '', zone_id: '', is_electric: 'ALL', status: 'AVAILABLE', max_rate: 100, min_health: 80 })}
      />

      {/* Fleet Grid */}
      {loading ? (
        <div className="p-16 text-center text-xs text-gray-400">
          <div className="w-8 h-8 border-2 border-campus-emerald border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
          <span>Loading Campus Fleet...</span>
        </div>
      ) : vehicles.length === 0 ? (
        <div className="bg-white rounded-3xl border border-campus-border/80 p-12 text-center space-y-4 shadow-sm">
          <div className="w-16 h-16 bg-campus-sand/60 text-campus-forest rounded-2xl flex items-center justify-center mx-auto border border-campus-border/80">
            <Bike className="w-8 h-8 text-campus-emerald" />
          </div>
          <div>
            <h3 className="font-extrabold text-lg text-campus-forest font-display">Campus Vehicle Pool is Fresh</h3>
            <p className="text-xs text-gray-500 max-w-md mx-auto mt-1 leading-relaxed">
              No vehicles are currently registered in the campus pool. Fleet owners and campus operators can register new bikes and vehicles from the Owner Portal.
            </p>
          </div>
          <div className="flex items-center justify-center gap-3 pt-2">
            <button
              onClick={() => setFilters({ search: '', zone_id: '', is_electric: 'ALL', status: 'AVAILABLE', max_rate: 100, min_health: 80 })}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-bold transition"
            >
              Reset Filters
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {vehicles.map((v) => (
            <VehicleCard
              key={v.id}
              vehicle={v}
              onSelectBooking={(veh) => setSelectedVehicleForBooking(veh)}
              onViewQR={(veh) => setSelectedVehicleForQR(veh)}
            />
          ))}
        </div>
      )}

      {/* Modals */}
      {selectedVehicleForBooking && (
        <BookingModal
          vehicle={selectedVehicleForBooking}
          zones={zones}
          onClose={() => setSelectedVehicleForBooking(null)}
          onSuccess={handleBookingCompleted}
        />
      )}

      {selectedVehicleForQR && (
        <VehicleQRDisplayModal
          vehicle={selectedVehicleForQR}
          onClose={() => setSelectedVehicleForQR(null)}
        />
      )}

    </div>
  );
}
