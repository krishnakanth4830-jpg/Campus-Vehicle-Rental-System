import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { useBooking } from '../../context/BookingContext';
import { useAuth } from '../../context/AuthContext';
import { 
  AlertTriangle, HeartHandshake, MapPin, Users, 
  Plus, CheckCircle2, Clock, ArrowRight, Shield 
} from 'lucide-react';

export function EmergencyBoard() {
  const { zones } = useBooking();
  const { user } = useAuth();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  
  const [newRequest, setNewRequest] = useState({
    pickup_zone_id: zones[0]?.id || 1,
    destination_zone_id: zones[1]?.id || 2,
    passengers_count: 1,
    category: 'CLASS_COMMUTE',
    notes: ''
  });

  const loadRequests = async () => {
    const res = await apiRequest('/emergency/?status=ALL');
    if (res.success && res.requests) {
      setRequests(res.requests);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadRequests();
  }, []);

  const handleCreateRequest = async (e) => {
    e.preventDefault();
    const res = await apiRequest('/emergency/', {
      method: 'POST',
      body: JSON.stringify(newRequest)
    });

    if (res.success) {
      setShowCreateModal(false);
      setNewRequest({
        pickup_zone_id: zones[0]?.id || 1,
        destination_zone_id: zones[1]?.id || 2,
        passengers_count: 1,
        category: 'CLASS_COMMUTE',
        notes: ''
      });
      loadRequests();
    }
  };

  const handleAcceptRequest = async (requestId) => {
    const res = await apiRequest(`/emergency/${requestId}/accept`, {
      method: 'POST'
    });
    if (res.success) {
      loadRequests();
    } else {
      alert(res.message || 'Could not accept ride request.');
    }
  };

  return (
    <div className="space-y-6 pb-16">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-700">
            PEER-TO-PEER CAMPUS CARPOOL & ASSISTANCE
          </span>
          <h1 className="text-2xl font-extrabold text-campus-forest font-display tracking-tight">
            Emergency & Carpool Ride Board
          </h1>
          <p className="text-xs text-gray-500">
            Request or offer quick lifts between campus zones for exams, heavy equipment, or urgent commutes.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="px-4 py-2.5 bg-campus-forest hover:bg-campus-emerald text-white rounded-2xl text-xs font-bold transition flex items-center gap-2 shadow self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Post Ride Request</span>
        </button>
      </div>

      {/* Requests List */}
      {loading ? (
        <div className="p-16 text-center text-xs text-gray-400">Loading Campus Ride Requests...</div>
      ) : requests.length === 0 ? (
        <div className="bg-white rounded-3xl border border-campus-border/80 p-12 text-center max-w-md mx-auto space-y-3">
          <HeartHandshake className="w-12 h-12 text-gray-300 mx-auto" />
          <h3 className="font-extrabold text-sm text-campus-forest">No Active Requests</h3>
          <p className="text-xs text-gray-500">All campus members are currently settled!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {requests.map((r) => (
            <div
              key={r.id}
              className="bg-white rounded-2xl border border-campus-border/80 p-5 shadow-sm hover:border-campus-emerald transition flex flex-col justify-between space-y-3 text-xs"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                    r.category === 'EXAM_RUSH' ? 'bg-amber-100 text-amber-800' :
                    r.category === 'MEDICAL_URGENT' ? 'bg-red-100 text-red-800' :
                    'bg-campus-sand text-campus-forest'
                  }`}>
                    {r.category.replace('_', ' ')}
                  </span>
                  <span className="text-[10px] text-gray-400">{r.created_at}</span>
                </div>

                <div className="font-bold text-sm text-campus-forest">{r.requester_name} ({r.requester_dept})</div>
                
                <div className="mt-2 p-2.5 bg-campus-sand/20 rounded-xl space-y-1 text-gray-600">
                  <div className="flex items-center gap-1 font-semibold text-campus-forest">
                    <MapPin className="w-3 h-3 text-campus-emerald" />
                    <span>Pickup: {r.pickup_zone_name}</span>
                  </div>
                  <div className="flex items-center gap-1 font-semibold text-campus-forest">
                    <MapPin className="w-3 h-3 text-campus-gold" />
                    <span>Drop: {r.destination_zone_name}</span>
                  </div>
                </div>

                {r.notes && <p className="text-gray-500 italic mt-2">"{r.notes}"</p>}
              </div>

              <div className="pt-2 border-t border-gray-100 flex items-center justify-between">
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  r.status === 'OPEN' ? 'bg-emerald-50 text-emerald-700' : 'bg-gray-100 text-gray-600'
                }`}>
                  {r.status === 'ACCEPTED' ? `Accepted by ${r.accepted_by_name}` : 'Awaiting Helper'}
                </span>

                {r.status === 'OPEN' && r.user_id !== user?.id && (
                  <button
                    onClick={() => handleAcceptRequest(r.id)}
                    className="px-3 py-1.5 bg-campus-forest hover:bg-campus-emerald text-white rounded-xl text-xs font-bold transition flex items-center gap-1"
                  >
                    <HeartHandshake className="w-3.5 h-3.5" />
                    <span>Accept (+15 pts)</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Request Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <form onSubmit={handleCreateRequest} className="bg-white rounded-3xl max-w-md w-full border border-campus-border/80 shadow-2xl p-6 space-y-4 text-xs">
            <div className="flex justify-between items-center border-b pb-2">
              <h3 className="font-extrabold text-base text-campus-forest font-display">Post Ride Request</h3>
              <button type="button" onClick={() => setShowCreateModal(false)} className="text-gray-400 hover:text-gray-600 font-bold">✕</button>
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Pickup Hub</label>
              <select
                value={newRequest.pickup_zone_id}
                onChange={(e) => setNewRequest({ ...newRequest, pickup_zone_id: Number(e.target.value) })}
                className="w-full p-2 bg-white border rounded-xl"
              >
                {zones.map((z) => <option key={z.id} value={z.id}>{z.name}</option>)}
              </select>
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Destination Hub</label>
              <select
                value={newRequest.destination_zone_id}
                onChange={(e) => setNewRequest({ ...newRequest, destination_zone_id: Number(e.target.value) })}
                className="w-full p-2 bg-white border rounded-xl"
              >
                {zones.map((z) => <option key={z.id} value={z.id}>{z.name}</option>)}
              </select>
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Reason / Category</label>
              <select
                value={newRequest.category}
                onChange={(e) => setNewRequest({ ...newRequest, category: e.target.value })}
                className="w-full p-2 bg-white border rounded-xl"
              >
                <option value="CLASS_COMMUTE">Class / Lab Commute</option>
                <option value="EXAM_RUSH">Exam Rush (Urgent)</option>
                <option value="RAIN_STRANDED">Rain Stranded</option>
                <option value="HEAVY_LUGGAGE">Heavy Lab Equipment / Luggage</option>
                <option value="MEDICAL_URGENT">Medical / First Aid Visit</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Notes / Description</label>
              <textarea
                rows={2}
                value={newRequest.notes}
                onChange={(e) => setNewRequest({ ...newRequest, notes: e.target.value })}
                placeholder="e.g. Waiting at Main Gate security arch with project kit..."
                className="w-full p-2 bg-campus-sand/20 border rounded-xl"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="flex-1 py-2 border rounded-xl font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2 bg-campus-forest text-white rounded-xl font-bold hover:bg-campus-emerald"
              >
                Post to Campus Board
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
}
