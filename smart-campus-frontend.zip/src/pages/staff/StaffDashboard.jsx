import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { useBooking } from '../../context/BookingContext';
import { 
  Wrench, Activity, ShieldCheck, MapPin, CheckCircle2, 
  AlertTriangle, RefreshCw, Navigation, Phone, User, 
  Fuel, Battery, Clock, ArrowRight, Shield, Layers, FileText, 
  SlidersHorizontal, CheckSquare, Search, Sparkles, Truck
} from 'lucide-react';
import { VehicleVisual } from '../../components/common/VehicleVisual';

export function StaffDashboard({ setTab }) {
  const { user } = useAuth();
  const { zones = [] } = useBooking();

  const [activeTab, setActiveTab] = useState('dispatch'); // dispatch, checkin-out, active-rides, incidents
  const [vehicles, setVehicles] = useState([]);
  const [activeBookings, setActiveBookings] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [maintenanceList, setMaintenanceList] = useState([]);
  const [loading, setLoading] = useState(true);

  // Check-in / Check-out quick form state
  const [checkinForm, setCheckinForm] = useState({
    booking_id: '',
    odometer_start: '',
    fuel_battery_start: 95,
    condition_notes: 'Physical vehicle check passed. Brakes, tires, and lights verified.',
    helmet_issued: true
  });
  const [checkoutForm, setCheckoutForm] = useState({
    booking_id: '',
    odometer_end: '',
    fuel_battery_end: 85,
    return_condition_notes: 'Vehicle returned in safe operating condition. No visible damage.',
    return_zone_id: 1,
    helmet_returned: true,
    damage_detected: false,
    damage_surcharge: 0
  });
  const [actionSuccess, setActionSuccess] = useState('');

  const loadStaffData = async () => {
    setLoading(true);
    try {
      const [vRes, bRes, incRes, mainRes] = await Promise.all([
        apiRequest('/vehicles/?status=ALL'),
        apiRequest('/bookings/active'),
        apiRequest('/security/incidents'),
        apiRequest('/admin/maintenance')
      ]);

      if (vRes.success && vRes.vehicles) setVehicles(vRes.vehicles);
      if (bRes.success && bRes.bookings) setActiveBookings(bRes.bookings);
      if (incRes.success && incRes.incidents) setIncidents(incRes.incidents);
      if (mainRes.success && mainRes.maintenance_records) setMaintenanceList(mainRes.maintenance_records);
    } catch (err) {
      console.error('Failed to load staff operations data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStaffData();
  }, []);

  const handleUpdateVehicleStatus = async (vehicleId, newStatus) => {
    const res = await apiRequest(`/vehicles/${vehicleId}`, {
      method: 'PATCH',
      body: JSON.stringify({ status: newStatus })
    });
    if (res.success) {
      setActionSuccess(`Vehicle #${vehicleId} status updated to ${newStatus}`);
      setTimeout(() => setActionSuccess(''), 4000);
      loadStaffData();
    }
  };

  const handleReassignZone = async (vehicleId, newZoneId) => {
    const res = await apiRequest(`/vehicles/${vehicleId}`, {
      method: 'PATCH',
      body: JSON.stringify({ current_zone_id: Number(newZoneId) })
    });
    if (res.success) {
      setActionSuccess(`Vehicle #${vehicleId} dispatched to new campus hub`);
      setTimeout(() => setActionSuccess(''), 4000);
      loadStaffData();
    }
  };

  const handleResolveIncident = async (incidentId, newStatus = 'RESOLVED') => {
    const res = await apiRequest(`/security/incidents/${incidentId}/resolve`, {
      method: 'POST',
      body: JSON.stringify({
        status: newStatus,
        resolution_notes: `Inspected and cleared by Staff Member ${user?.name || 'Operations Lead'}.`
      })
    });
    if (res.success) {
      setActionSuccess(`Incident #${incidentId} marked as ${newStatus}`);
      setTimeout(() => setActionSuccess(''), 4000);
      loadStaffData();
    }
  };

  const handlePerformCheckin = async (e) => {
    e.preventDefault();
    if (!checkinForm.booking_id) {
      alert('Please select or enter a Booking ID');
      return;
    }
    const res = await apiRequest('/security/checkin', {
      method: 'POST',
      body: JSON.stringify({
        booking_id: Number(checkinForm.booking_id),
        odometer_start: Number(checkinForm.odometer_start) || 120.0,
        fuel_battery_start: Number(checkinForm.fuel_battery_start),
        condition_notes: checkinForm.condition_notes,
        helmet_issued: checkinForm.helmet_issued,
        safety_checklist_agreed: true
      })
    });
    if (res.success) {
      setActionSuccess(`Pre-Ride Check-in verified for Booking #${checkinForm.booking_id}! Ride is now ACTIVE.`);
      setTimeout(() => setActionSuccess(''), 5000);
      setCheckinForm({ booking_id: '', odometer_start: '', fuel_battery_start: 95, condition_notes: '', helmet_issued: true });
      loadStaffData();
    } else {
      alert(res.message || 'Check-in failed');
    }
  };

  const handlePerformCheckout = async (e) => {
    e.preventDefault();
    if (!checkoutForm.booking_id) {
      alert('Please select or enter a Booking ID');
      return;
    }
    const res = await apiRequest('/security/checkout', {
      method: 'POST',
      body: JSON.stringify({
        booking_id: Number(checkoutForm.booking_id),
        odometer_end: Number(checkoutForm.odometer_end) || 125.0,
        fuel_battery_end: Number(checkoutForm.fuel_battery_end),
        return_condition_notes: checkoutForm.return_condition_notes,
        return_zone_id: Number(checkoutForm.return_zone_id),
        helmet_returned: checkoutForm.helmet_returned,
        damage_detected: checkoutForm.damage_detected,
        damage_surcharge: Number(checkoutForm.damage_surcharge) || 0
      })
    });
    if (res.success) {
      setActionSuccess(`Post-Ride Return Checkout completed for Booking #${checkoutForm.booking_id}! Vehicle returned to fleet.`);
      setTimeout(() => setActionSuccess(''), 5000);
      setCheckoutForm({ booking_id: '', odometer_end: '', fuel_battery_end: 85, return_condition_notes: '', return_zone_id: 1, helmet_returned: true, damage_detected: false, damage_surcharge: 0 });
      loadStaffData();
    } else {
      alert(res.message || 'Checkout failed');
    }
  };

  // Derived metrics
  const totalVehiclesCount = vehicles.length || 20;
  const inUseCount = vehicles.filter(v => v.status === 'IN_USE').length;
  const maintenanceCount = vehicles.filter(v => v.status === 'MAINTENANCE').length;
  const availableCount = vehicles.filter(v => v.status === 'AVAILABLE').length;
  const openIncidentsCount = incidents.filter(i => i.status !== 'RESOLVED' && i.status !== 'CLOSED').length;

  return (
    <div className="space-y-6 pb-20">
      
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-campus-forest to-slate-950 text-white p-6 sm:p-8 rounded-3xl shadow-xl border border-campus-mint/30 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-campus-mint to-campus-emerald text-campus-forest font-extrabold text-2xl flex items-center justify-center shadow-lg border border-white/20 shrink-0">
            <Wrench className="w-7 h-7 text-campus-forest" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-campus-mint/20 text-campus-mint border border-campus-mint/40">
                CAMPUS FLEET OPERATIONS & LOGISTICS
              </span>
              <span className="text-[11px] text-gray-300 font-mono">STAFF-ID: {user?.student_id || 'FAC-2019'}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold font-display tracking-tight text-white">
              Operations & Dispatch Console
            </h1>
            <p className="text-xs text-gray-300">
              Logged in as <strong>{user?.name || 'Faculty / Fleet Operations Staff'}</strong> • {user?.college_name || 'PSG College of Technology'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 self-start md:self-auto">
          <button
            onClick={() => setTab('bike-lookup')}
            className="px-4 py-2.5 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-2xl text-xs font-bold transition flex items-center gap-1.5"
          >
            <Search className="w-4 h-4 text-campus-mint" />
            <span>Bike Lookup</span>
          </button>
          <button
            onClick={loadStaffData}
            className="p-2.5 bg-campus-gold hover:bg-amber-400 text-campus-forest rounded-2xl transition font-bold shadow-lg"
            title="Refresh Live Operations Telemetry"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Success Notification Banner */}
      {actionSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-2xl flex items-center gap-3 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* 2. Operations KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Supervised Fleet</span>
            <Layers className="w-4 h-4 text-campus-forest" />
          </div>
          <div className="text-2xl font-extrabold text-campus-forest font-display">{totalVehiclesCount}</div>
          <div className="text-[11px] text-emerald-600 font-semibold">{availableCount} Ready at Hubs</div>
        </div>

        <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Live On-Ride</span>
            <Activity className="w-4 h-4 text-blue-600 animate-pulse" />
          </div>
          <div className="text-2xl font-extrabold text-blue-600 font-display">{inUseCount || activeBookings.length}</div>
          <div className="text-[11px] text-gray-500 font-semibold">Active campus trips</div>
        </div>

        <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Maintenance Bay</span>
            <Wrench className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-extrabold text-amber-600 font-display">{maintenanceCount}</div>
          <div className="text-[11px] text-amber-700 font-semibold">Service queue</div>
        </div>

        <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Open Incidents</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-extrabold text-rose-600 font-display">{openIncidentsCount}</div>
          <div className="text-[11px] text-rose-600 font-semibold">Requires staff sign-off</div>
        </div>

        <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Campus Hubs</span>
            <MapPin className="w-4 h-4 text-campus-emerald" />
          </div>
          <div className="text-2xl font-extrabold text-campus-forest font-display">{zones.length || 30}</div>
          <div className="text-[11px] text-campus-mint font-semibold">Tamil Nadu Stations</div>
        </div>
      </div>

      {/* 3. Operational Navigation Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 text-xs font-bold">
        {[
          { id: 'dispatch', label: `🚚 Fleet Health & Rebalancing (${vehicles.length})` },
          { id: 'checkin-out', label: '🛡️ Pre/Post-Ride Inspection Station' },
          { id: 'active-rides', label: `🛰️ Live Active Trips Telemetry (${activeBookings.length || inUseCount})` },
          { id: 'incidents', label: `⚠️ Damage & Service Queue (${incidents.length})` }
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`px-4 py-2.5 rounded-2xl transition whitespace-nowrap ${
              activeTab === t.id
                ? 'bg-campus-forest text-white shadow'
                : 'bg-white text-gray-600 border border-campus-border/70 hover:bg-campus-sand/40'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* TAB 1: FLEET HEALTH & DISPATCH / REBALANCING */}
      {activeTab === 'dispatch' && (
        <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md overflow-hidden space-y-4">
          <div className="p-5 border-b flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div>
              <h3 className="font-extrabold text-base text-campus-forest font-display">
                Campus Fleet Health & Hub Rebalancing Console
              </h3>
              <p className="text-gray-500 text-[11px]">
                Inspect health scores, update live operational status, or dispatch vehicles to high-demand campus gates.
              </p>
            </div>
            <button
              onClick={() => setTab('live-gps')}
              className="px-3.5 py-2 bg-campus-mint/20 hover:bg-campus-mint/30 text-campus-forest border border-campus-mint/40 rounded-xl font-bold transition flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Navigation className="w-3.5 h-3.5 text-campus-emerald" />
              <span>View Radar Map</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-campus-sand/40 border-b text-[10px] uppercase font-bold text-gray-500">
                <tr>
                  <th className="p-3.5">Vehicle</th>
                  <th className="p-3.5">Power & Diagnostics</th>
                  <th className="p-3.5">Assigned Campus Hub</th>
                  <th className="p-3.5">Health Score</th>
                  <th className="p-3.5">Status Override</th>
                  <th className="p-3.5 text-right">Rapid Dispatch</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {vehicles.map((v) => (
                  <tr key={v.id} className="hover:bg-campus-sand/20 transition">
                    <td className="p-3.5">
                      <div className="flex items-center gap-3">
                        <VehicleVisual
                          vehicle={v}
                          size="thumbnail"
                          showBadge={false}
                          className="shrink-0"
                        />
                        <div>
                          <div className="font-extrabold text-campus-forest">{v.brand} {v.model}</div>
                          <div className="text-[11px] font-mono text-gray-400 font-bold">{v.vehicle_number}</div>
                        </div>
                      </div>
                    </td>

                    <td className="p-3.5">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-1 font-bold text-gray-700">
                          <Fuel className="w-3.5 h-3.5 text-amber-600" />
                          <span>{v.fuel_level_percentage || 85}% {v.is_electric ? 'Battery' : 'Petrol'}</span>
                        </div>
                        <div className="text-[10px] text-gray-400">Odo: {v.current_kilometers || 120} km</div>
                      </div>
                    </td>

                    <td className="p-3.5 font-medium text-gray-700">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-campus-emerald shrink-0" />
                        <span>{v.current_zone?.name || 'PSG Tech Main Gate'}</span>
                      </div>
                    </td>

                    <td className="p-3.5">
                      <span className={`font-mono font-extrabold text-xs px-2 py-0.5 rounded-md ${
                        (v.health_score || 95) >= 90 ? 'bg-emerald-50 text-emerald-700' :
                        (v.health_score || 95) >= 75 ? 'bg-amber-50 text-amber-700' :
                        'bg-rose-50 text-rose-700'
                      }`}>
                        {v.health_score || 95}/100
                      </span>
                    </td>

                    <td className="p-3.5">
                      <select
                        value={v.status}
                        onChange={(e) => handleUpdateVehicleStatus(v.id, e.target.value)}
                        className={`p-1.5 rounded-xl text-xs font-bold border ${
                          v.status === 'AVAILABLE' ? 'bg-emerald-50 text-emerald-800 border-emerald-300' :
                          v.status === 'IN_USE' ? 'bg-blue-50 text-blue-800 border-blue-300' :
                          v.status === 'MAINTENANCE' ? 'bg-amber-50 text-amber-800 border-amber-300' :
                          'bg-gray-100 text-gray-700 border-gray-300'
                        }`}
                      >
                        <option value="AVAILABLE">AVAILABLE</option>
                        <option value="RESERVED">RESERVED</option>
                        <option value="IN_USE">IN_USE</option>
                        <option value="MAINTENANCE">MAINTENANCE</option>
                        <option value="UNAVAILABLE">UNAVAILABLE</option>
                      </select>
                    </td>

                    <td className="p-3.5 text-right">
                      <select
                        value={v.current_zone_id || 1}
                        onChange={(e) => handleReassignZone(v.id, e.target.value)}
                        className="p-1.5 bg-campus-sand/40 border border-campus-border/80 rounded-xl text-xs font-semibold text-campus-forest"
                      >
                        {zones.slice(0, 8).map((z) => (
                          <option key={z.id} value={z.id}>
                            Dispatch $\rightarrow$ {z.name.split(' ')[0]}
                          </option>
                        ))}
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: SECURITY CHECK-IN / CHECK-OUT INSPECTION STATION */}
      {activeTab === 'checkin-out' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Pre-Ride Handover Check-In */}
          <div className="bg-white rounded-3xl border border-campus-border/80 p-6 shadow-md space-y-4">
            <div className="flex items-center gap-2 border-b pb-3">
              <ShieldCheck className="w-5 h-5 text-campus-emerald" />
              <div>
                <h3 className="font-extrabold text-base text-campus-forest font-display">Pre-Ride Security Check-In</h3>
                <p className="text-[11px] text-gray-500">Record physical condition and issue helmet before rider departure</p>
              </div>
            </div>

            <form onSubmit={handlePerformCheckin} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-gray-700 mb-1">Select Booking / Rider</label>
                <select
                  value={checkinForm.booking_id}
                  onChange={(e) => setCheckinForm({ ...checkinForm, booking_id: e.target.value })}
                  className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl font-medium"
                  required
                >
                  <option value="">-- Choose Confirmed Booking --</option>
                  {activeBookings.filter(b => b.status === 'CONFIRMED' || b.status === 'ACTIVE').map(b => (
                    <option key={b.id} value={b.id}>
                      #{b.booking_code} • {b.user?.name} ({b.vehicle?.vehicle_number})
                    </option>
                  ))}
                  {/* Fallback sample if no active bookings */}
                  <option value="1">#RENT-2026-PSG-01 • Karthik Subramanian (TN-38-SC-101)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Starting Odometer (km)</label>
                  <input
                    type="number"
                    step="0.1"
                    placeholder="e.g. 124.5"
                    value={checkinForm.odometer_start}
                    onChange={(e) => setCheckinForm({ ...checkinForm, odometer_start: e.target.value })}
                    className="w-full p-2.5 border rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Fuel / Battery Level (%)</label>
                  <input
                    type="number"
                    min="10"
                    max="100"
                    value={checkinForm.fuel_battery_start}
                    onChange={(e) => setCheckinForm({ ...checkinForm, fuel_battery_start: Number(e.target.value) })}
                    className="w-full p-2.5 border rounded-xl font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Pre-Ride Inspection Notes</label>
                <textarea
                  rows="2"
                  value={checkinForm.condition_notes}
                  onChange={(e) => setCheckinForm({ ...checkinForm, condition_notes: e.target.value })}
                  className="w-full p-2.5 bg-campus-sand/20 border rounded-xl"
                  placeholder="Brakes responsive, headlights active, side mirrors intact"
                ></textarea>
              </div>

              <div className="flex items-center gap-2 p-3 bg-campus-sand/30 rounded-xl border">
                <input
                  type="checkbox"
                  id="helmet_issued"
                  checked={checkinForm.helmet_issued}
                  onChange={(e) => setCheckinForm({ ...checkinForm, helmet_issued: e.target.checked })}
                  className="w-4 h-4 text-campus-emerald rounded"
                />
                <label htmlFor="helmet_issued" className="font-bold text-campus-forest cursor-pointer">
                  ✓ ISI Certified Safety Helmet Issued to Rider
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-campus-forest hover:bg-campus-emerald text-white rounded-2xl font-bold transition shadow-md flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4 text-campus-mint" />
                <span>Verify & Authorize Trip Start</span>
              </button>
            </form>
          </div>

          {/* Post-Ride Vehicle Return Checkout */}
          <div className="bg-white rounded-3xl border border-campus-border/80 p-6 shadow-md space-y-4">
            <div className="flex items-center gap-2 border-b pb-3">
              <CheckSquare className="w-5 h-5 text-blue-600" />
              <div>
                <h3 className="font-extrabold text-base text-campus-forest font-display">Post-Ride Return Checkout</h3>
                <p className="text-[11px] text-gray-500">Inspect vehicle upon return, check for scratches, and release deposit</p>
              </div>
            </div>

            <form onSubmit={handlePerformCheckout} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-gray-700 mb-1">Select Returning Booking</label>
                <select
                  value={checkoutForm.booking_id}
                  onChange={(e) => setCheckoutForm({ ...checkoutForm, booking_id: e.target.value })}
                  className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl font-medium"
                  required
                >
                  <option value="">-- Choose Active Trip to Return --</option>
                  {activeBookings.map(b => (
                    <option key={b.id} value={b.id}>
                      #{b.booking_code} • {b.user?.name} ({b.vehicle?.vehicle_number})
                    </option>
                  ))}
                  <option value="1">#RENT-2026-PSG-01 • Karthik Subramanian (TN-38-SC-101)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Return Odometer (km)</label>
                  <input
                    type="number"
                    step="0.1"
                    placeholder="e.g. 129.2"
                    value={checkoutForm.odometer_end}
                    onChange={(e) => setCheckoutForm({ ...checkoutForm, odometer_end: e.target.value })}
                    className="w-full p-2.5 border rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Return Fuel / Battery (%)</label>
                  <input
                    type="number"
                    min="5"
                    max="100"
                    value={checkoutForm.fuel_battery_end}
                    onChange={(e) => setCheckoutForm({ ...checkoutForm, fuel_battery_end: Number(e.target.value) })}
                    className="w-full p-2.5 border rounded-xl font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Return Station Hub</label>
                <select
                  value={checkoutForm.return_zone_id}
                  onChange={(e) => setCheckoutForm({ ...checkoutForm, return_zone_id: Number(e.target.value) })}
                  className="w-full p-2.5 bg-white border border-campus-border/80 rounded-xl font-medium"
                >
                  {zones.map((z) => (
                    <option key={z.id} value={z.id}>{z.name} ({z.city})</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2 p-3 bg-campus-sand/30 rounded-xl border">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="helmet_returned"
                    checked={checkoutForm.helmet_returned}
                    onChange={(e) => setCheckoutForm({ ...checkoutForm, helmet_returned: e.target.checked })}
                    className="w-4 h-4 text-campus-emerald rounded"
                  />
                  <label htmlFor="helmet_returned" className="font-bold text-campus-forest cursor-pointer">
                    ✓ Safety Helmet Returned Undamaged
                  </label>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="damage_detected"
                    checked={checkoutForm.damage_detected}
                    onChange={(e) => setCheckoutForm({ ...checkoutForm, damage_detected: e.target.checked })}
                    className="w-4 h-4 text-rose-600 rounded"
                  />
                  <label htmlFor="damage_detected" className="font-bold text-rose-700 cursor-pointer">
                    ⚠️ Flag Damage / Scratches Detected
                  </label>
                </div>
              </div>

              {checkoutForm.damage_detected && (
                <div>
                  <label className="block font-bold text-rose-700 mb-1">Damage Surcharge (₹)</label>
                  <input
                    type="number"
                    placeholder="e.g. 250"
                    value={checkoutForm.damage_surcharge}
                    onChange={(e) => setCheckoutForm({ ...checkoutForm, damage_surcharge: e.target.value })}
                    className="w-full p-2.5 border border-rose-300 bg-rose-50 rounded-xl font-bold text-rose-800"
                  />
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-bold transition shadow-md flex items-center justify-center gap-2"
              >
                <CheckSquare className="w-4 h-4" />
                <span>Complete Return & Release Deposit</span>
              </button>
            </form>
          </div>

        </div>
      )}

      {/* TAB 3: LIVE ACTIVE RIDES TELEMETRY */}
      {activeTab === 'active-rides' && (
        <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md p-6 space-y-4">
          <div className="flex items-center justify-between border-b pb-3">
            <div>
              <h3 className="font-extrabold text-base text-campus-forest font-display">
                Active Student Rides & GPS Radar Monitor
              </h3>
              <p className="text-xs text-gray-500">Live oversight of active vehicle rentals across campus hubs</p>
            </div>
            <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-black rounded-full uppercase">
              Live Fleet Feed
            </span>
          </div>

          {activeBookings.length === 0 ? (
            <div className="p-8 text-center text-xs text-gray-400 space-y-2">
              <Activity className="w-8 h-8 text-gray-300 mx-auto" />
              <p>No student rides are currently active in this timeslot.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              {activeBookings.map((b) => (
                <div key={b.id} className="p-4 rounded-2xl border border-campus-border/80 bg-campus-sand/20 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-mono text-[10px] font-bold text-gray-400">{b.booking_code}</span>
                      <h4 className="font-extrabold text-sm text-campus-forest">{b.vehicle?.brand} {b.vehicle?.model}</h4>
                      <div className="font-mono text-xs font-bold text-gray-600">{b.vehicle?.vehicle_number}</div>
                    </div>
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-blue-100 text-blue-800 uppercase animate-pulse">
                      ON TRIP
                    </span>
                  </div>

                  <div className="space-y-1 text-gray-600 text-[11px] pt-1 border-t">
                    <div className="flex justify-between">
                      <span className="flex items-center gap-1"><User className="w-3 h-3 text-campus-emerald" /> Rider:</span>
                      <span className="font-bold text-campus-charcoal">{b.user?.name} ({b.user?.student_id})</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="flex items-center gap-1"><Phone className="w-3 h-3 text-gray-400" /> Phone:</span>
                      <span className="font-mono">{b.user?.phone || '+91 98765 43210'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3 text-campus-gold" /> Started:</span>
                      <span>{new Date(b.actual_start_time || b.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setTab('live-gps')}
                    className="w-full py-2 bg-campus-forest hover:bg-campus-emerald text-white rounded-xl font-bold text-xs transition flex items-center justify-center gap-1"
                  >
                    <Navigation className="w-3.5 h-3.5 text-campus-gold" />
                    <span>Locate on Satellite Radar</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: DAMAGE & INCIDENTS SERVICE QUEUE */}
      {activeTab === 'incidents' && (
        <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md p-6 space-y-4">
          <div className="flex items-center justify-between border-b pb-3">
            <div>
              <h3 className="font-extrabold text-base text-campus-forest font-display">
                Reported Incidents, Damage Checks & Service Queue
              </h3>
              <p className="text-xs text-gray-500">Review student accident/scratch reports and release repaired vehicles</p>
            </div>
            <span className="px-3 py-1 bg-rose-100 text-rose-800 text-[10px] font-black rounded-full uppercase">
              Safety Review
            </span>
          </div>

          {incidents.length === 0 ? (
            <div className="p-8 text-center text-xs text-gray-400">All fleet vehicles in safe operational condition.</div>
          ) : (
            <div className="space-y-3 text-xs">
              {incidents.map((inc) => (
                <div key={inc.id} className="p-4 bg-campus-sand/20 rounded-2xl border border-campus-border/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[10px] font-bold text-gray-400">{inc.incident_code}</span>
                      <span className="font-extrabold text-sm text-campus-forest">{inc.title}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                        inc.severity === 'HIGH' || inc.severity === 'CRITICAL' ? 'bg-rose-100 text-rose-800' :
                        inc.severity === 'MEDIUM' ? 'bg-amber-100 text-amber-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {inc.severity} SEVERITY
                      </span>
                    </div>
                    <p className="text-gray-600">{inc.description}</p>
                    <div className="text-[11px] text-gray-500 flex items-center gap-3">
                      <span>Location: <strong>{inc.location || 'Campus Pathway'}</strong></span>
                      <span>•</span>
                      <span>Status: <strong className="uppercase">{inc.status}</strong></span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    {inc.status !== 'RESOLVED' && (
                      <button
                        onClick={() => handleResolveIncident(inc.id, 'RESOLVED')}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow transition flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Clear & Return to Fleet</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  );
}

export default StaffDashboard;
