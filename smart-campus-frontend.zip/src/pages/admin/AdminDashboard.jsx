import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { VehicleQRDisplayModal } from '../../components/qr/VehicleQRDisplayModal';
import { 
  Shield, Bike, Zap, Users, MapPin, Wrench, AlertTriangle, 
  DollarSign, Activity, BarChart3, Plus, CheckCircle2, Eye, 
  Sliders, RefreshCw, UserCheck, UserX, ShieldCheck, Search,
  Lock, ArrowRight, ExternalLink
} from 'lucide-react';
import { VehicleVisual } from '../../components/common/VehicleVisual';

export function AdminDashboard({ setTab }) {
  const [metrics, setMetrics] = useState(null);
  const [heatmap, setHeatmap] = useState([]);
  const [peakHours, setPeakHours] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [usersList, setUsersList] = useState([]);
  const [maintenanceList, setMaintenanceList] = useState([]);
  const [damageReports, setDamageReports] = useState([]);
  const [pricingRule, setPricingRule] = useState(null);
  const [zones, setZones] = useState([]);
  const [vehicleTypes, setVehicleTypes] = useState([]);
  
  const [activeTab, setActiveTab] = useState('overview'); // overview, fleet, users, maintenance, damage, pricing
  const [loading, setLoading] = useState(true);
  const [actionSuccess, setActionSuccess] = useState('');
  
  const [showAddVehicleModal, setShowAddVehicleModal] = useState(false);
  const [selectedQRVehicle, setSelectedQRVehicle] = useState(null);
  
  const [newVehicle, setNewVehicle] = useState({
    vehicle_number: '',
    type_id: 1,
    brand: '',
    model: '',
    hourly_rate: 25.0,
    current_zone_id: 1,
    is_electric: false,
    battery_percentage: 100,
    estimated_range_km: 220.0
  });

  const loadAllAdminData = async () => {
    setLoading(true);
    try {
      const [mRes, hRes, pRes, vRes, uRes, mainRes, dRes, prRes, zRes, vtRes] = await Promise.all([
        apiRequest('/admin/metrics'),
        apiRequest('/admin/heatmap'),
        apiRequest('/admin/peak-hours'),
        apiRequest('/vehicles/?status=ALL'),
        apiRequest('/admin/users'),
        apiRequest('/admin/maintenance'),
        apiRequest('/condition/'),
        apiRequest('/admin/pricing'),
        apiRequest('/zones/'),
        apiRequest('/vehicles/types')
      ]);

      if (mRes.success) setMetrics(mRes.metrics);
      if (hRes.success) setHeatmap(hRes.heatmap);
      if (pRes.success) setPeakHours(pRes.peak_hours);
      if (vRes.success) setVehicles(vRes.vehicles);
      if (uRes.success && uRes.users) setUsersList(uRes.users);
      if (mainRes.success) setMaintenanceList(mainRes.maintenance_records);
      if (dRes.success) setDamageReports(dRes.reports);
      if (prRes.success) setPricingRule(prRes.pricing_rule);
      if (zRes.success) setZones(zRes.zones);
      if (vtRes.success) setVehicleTypes(vtRes.types);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllAdminData();
  }, []);

  const handleAddVehicleSubmit = async (e) => {
    e.preventDefault();
    const res = await apiRequest('/vehicles/', {
      method: 'POST',
      body: JSON.stringify(newVehicle)
    });
    if (res.success) {
      setShowAddVehicleModal(false);
      setActionSuccess('New vehicle registered successfully!');
      setTimeout(() => setActionSuccess(''), 4000);
      loadAllAdminData();
    } else {
      alert(res.message || 'Failed to add vehicle');
    }
  };

  const handleUpdateVehicleStatus = async (vehId, newStatus) => {
    await apiRequest(`/vehicles/${vehId}`, {
      method: 'PATCH',
      body: JSON.stringify({ status: newStatus })
    });
    loadAllAdminData();
  };

  const handleToggleUserSuspension = async (targetUser) => {
    const action = targetUser.is_active ? 'suspend' : 'reactivate';
    if (!window.confirm(`Are you sure you want to ${action} ${targetUser.name}?`)) {
      return;
    }
    const res = await apiRequest(`/security/user/${targetUser.id}/suspend`, {
      method: 'POST',
      body: JSON.stringify({ suspend: targetUser.is_active })
    });
    if (res.success) {
      setActionSuccess(`User ${targetUser.name} ${action}d successfully`);
      setTimeout(() => setActionSuccess(''), 4000);
      loadAllAdminData();
    } else {
      alert(res.message || 'Failed to update user status');
    }
  };

  const handleUpdateMaintenance = async (recordId, newStatus) => {
    await apiRequest(`/admin/maintenance/${recordId}`, {
      method: 'PATCH',
      body: JSON.stringify({ status: newStatus })
    });
    loadAllAdminData();
  };

  const handleUpdatePricing = async (e) => {
    e.preventDefault();
    const res = await apiRequest('/admin/pricing', {
      method: 'POST',
      body: JSON.stringify(pricingRule)
    });
    if (res.success) {
      setActionSuccess('Platform pricing & discount rules updated successfully!');
      setTimeout(() => setActionSuccess(''), 4000);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      
      {/* Admin Control Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-campus-forest via-emerald-950 to-slate-950 text-white p-6 sm:p-8 rounded-3xl shadow-xl border border-campus-gold/30">
        <div>
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-campus-gold" />
            <span className="text-[11px] font-extrabold uppercase tracking-widest text-campus-gold">
              CHIEF CAMPUS MOBILITY ADMINISTRATOR CONTROL CENTER
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold font-display mt-1">
            Executive Admin Master Dashboard
          </h1>
          <p className="text-xs text-gray-300 mt-0.5">
            Full platform control • Manage all vehicles, users, pricing policies, KYC verifications, and audit logs.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {setTab && (
            <button
              onClick={() => setTab('security-dashboard')}
              className="px-3.5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl transition text-xs font-bold flex items-center gap-1.5 shadow-md"
            >
              <ShieldCheck className="w-4 h-4 text-blue-200" />
              <span>Security Center</span>
            </button>
          )}

          <button
            onClick={loadAllAdminData}
            className="p-2.5 bg-white/10 hover:bg-white/20 rounded-2xl transition text-xs font-bold flex items-center gap-1.5"
            title="Refresh All Metrics"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowAddVehicleModal(true)}
            className="px-4 py-2.5 bg-campus-gold hover:bg-amber-400 text-campus-forest rounded-2xl text-xs font-extrabold shadow-lg transition flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Register New Vehicle</span>
          </button>
        </div>
      </div>

      {actionSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-2xl flex items-center gap-3 text-xs font-bold animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* Navigation Sub-Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 text-xs font-bold">
        {[
          { id: 'overview', label: '📊 System Overview & Heatmap' },
          { id: 'fleet', label: `🚲 Fleet Management (${vehicles.length})` },
          { id: 'users', label: `👥 User Management (${usersList.length || 6})` },
          { id: 'maintenance', label: `🔧 Maintenance Queue (${maintenanceList.length})` },
          { id: 'damage', label: `📸 Damage Reports (${damageReports.length})` },
          { id: 'pricing', label: '💰 Pricing & Discount Engine' }
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`px-4 py-2.5 rounded-2xl transition whitespace-nowrap ${
              activeTab === t.id
                ? 'bg-campus-forest text-white shadow'
                : 'bg-white text-gray-600 border border-campus-border/70 hover:bg-campus-sand/40'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* TAB 1: OVERVIEW & HEATMAP */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          
          {/* KPI Metrics */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
              <span className="text-[10px] font-bold uppercase text-gray-400">Total Fleet</span>
              <div className="text-2xl font-extrabold text-campus-forest font-display">{metrics?.total_vehicles || vehicles.length || 20}</div>
              <div className="text-[11px] text-campus-emerald font-semibold">{metrics?.available_vehicles || 18} Ready for Rent</div>
            </div>

            <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
              <span className="text-[10px] font-bold uppercase text-gray-400">Active Rentals</span>
              <div className="text-2xl font-extrabold text-blue-600 font-display">{metrics?.active_rentals || 2}</div>
              <div className="text-[11px] text-gray-500 font-semibold">{metrics?.fleet_utilization_pct || 15}% Fleet Utilization</div>
            </div>

            <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
              <span className="text-[10px] font-bold uppercase text-gray-400">Total Revenue</span>
              <div className="text-2xl font-extrabold text-campus-forest font-display">₹{metrics?.total_revenue?.toFixed(2) || '405.00'}</div>
              <div className="text-[11px] text-campus-emerald font-semibold">{metrics?.total_bookings || 14} Total Bookings</div>
            </div>

            <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-1">
              <span className="text-[10px] font-bold uppercase text-gray-400">Maintenance & Damage</span>
              <div className="text-2xl font-extrabold text-amber-600 font-display">{metrics?.maintenance_vehicles || 1} in Shop</div>
              <div className="text-[11px] text-rose-600 font-semibold">{metrics?.pending_damage_reports || 0} Pending Damage Checks</div>
            </div>
          </div>

          {/* Campus Demand Heatmap */}
          <div className="bg-white rounded-3xl border border-campus-border/80 p-6 shadow-md space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h3 className="font-extrabold text-base text-campus-forest font-display">
                  Campus Zone Demand & Vehicle Flow Heatmap
                </h3>
                <p className="text-xs text-gray-500">
                  Zone-by-zone pickup vs return traffic volume and rebalancing alerts across Tamil Nadu colleges.
                </p>
              </div>
              <span className="text-[10px] font-extrabold uppercase px-3 py-1 bg-campus-sand rounded-full text-campus-forest">
                Real-Time Traffic Engine
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {heatmap.map((h) => (
                <div
                  key={h.zone_id}
                  className="p-4 rounded-2xl border border-campus-border/80 bg-campus-sand/20 space-y-2 text-xs"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-bold text-campus-forest">{h.zone_name}</div>
                      <span className="text-[10px] font-mono text-gray-400">{h.zone_code}</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                      h.rebalance_status === 'HIGH_DEMAND_DEFICIT' ? 'bg-rose-100 text-rose-800' :
                      h.rebalance_status === 'SURPLUS_OVERCROWDED' ? 'bg-amber-100 text-amber-800' :
                      'bg-emerald-50 text-emerald-700'
                    }`}>
                      {h.rebalance_status.replace(/_/g, ' ')}
                    </span>
                  </div>

                  <div className="space-y-1 pt-1 text-gray-600">
                    <div className="flex justify-between">
                      <span>Available Fleet:</span>
                      <span className="font-extrabold text-campus-forest">{h.available_vehicles} / {h.capacity}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Checkpoint Traffic:</span>
                      <span className="font-bold">{h.traffic_volume} trips ({h.total_pickups} pickups, {h.total_dropoffs} drops)</span>
                    </div>
                  </div>

                  <div className="pt-2">
                    <div className="flex justify-between text-[10px] text-gray-400 font-semibold mb-1">
                      <span>Demand Intensity</span>
                      <span>{(h.demand_intensity * 100).toFixed(0)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-campus-mint via-campus-gold to-rose-500 h-full"
                        style={{ width: `${Math.max(h.demand_intensity * 100, 15)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Peak Hours Distribution */}
          <div className="bg-white rounded-3xl border border-campus-border/80 p-6 shadow-md space-y-3">
            <h3 className="font-extrabold text-base text-campus-forest font-display">
              Campus Peak Booking Hours Histogram
            </h3>
            <div className="grid grid-cols-4 sm:grid-cols-8 lg:grid-cols-16 gap-2 text-center text-xs">
              {peakHours.map((p, idx) => (
                <div key={idx} className="p-2.5 bg-campus-sand/30 rounded-xl border border-campus-border/60">
                  <div className="text-[10px] font-bold text-gray-400">{p.hour}</div>
                  <div className="text-base font-extrabold text-campus-forest font-mono mt-1">{p.bookings}</div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* TAB 2: FLEET MANAGEMENT */}
      {activeTab === 'fleet' && (
        <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md overflow-hidden">
          <div className="p-5 border-b flex justify-between items-center text-xs">
            <div>
              <h3 className="font-extrabold text-base text-campus-forest font-display">Fleet Control & Registration Center</h3>
              <p className="text-gray-500 text-[11px]">Decrypted registration numbers, owner associations, and live status overrides</p>
            </div>
            <span className="text-gray-500 font-bold">Total {vehicles.length} Vehicles</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-campus-sand/40 border-b text-[10px] uppercase font-bold text-gray-500">
                <tr>
                  <th className="p-3.5">Vehicle Details</th>
                  <th className="p-3.5">Power & Engine</th>
                  <th className="p-3.5">Current Hub</th>
                  <th className="p-3.5">Health Score</th>
                  <th className="p-3.5">Tariff Rate</th>
                  <th className="p-3.5">Operational Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {vehicles.map((v) => (
                  <tr key={v.id} className="hover:bg-campus-sand/20 transition">
                    <td className="p-3.5">
                      <div className="flex items-center gap-3">
                        <VehicleVisual
                          vehicle={v}
                          size="thumbnail"
                          showBadge={false}
                          className="shrink-0"
                        />
                        <div>
                          <div className="font-extrabold text-campus-forest">{v.brand} {v.model}</div>
                          <div className="flex flex-col gap-0.5 mt-0.5 text-[11px]">
                            <div><span className="text-gray-400">Reg:</span> <strong className="font-mono text-campus-forest font-bold">{v.vehicle_number}</strong></div>
                            <div><span className="text-gray-400">Owner:</span> <strong className="text-gray-800">{v.owner_name || v.owner?.name || 'Campus Host'}</strong></div>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-campus-sand text-campus-forest flex items-center gap-1 w-max">
                        <span>⛽ {v.engine_cc || 125}cc ({v.fuel_level_percentage || 90}%)</span>
                      </span>
                    </td>
                    <td className="p-3.5 font-medium text-gray-600">{v.current_zone?.name || 'In Transit'}</td>
                    <td className="p-3.5 font-mono font-bold text-campus-emerald">{v.health_score || 95}/100</td>
                    <td className="p-3.5 font-extrabold text-campus-forest">₹{v.hourly_rate}/hr</td>
                    <td className="p-3.5">
                      <select
                        value={v.status}
                        onChange={(e) => handleUpdateVehicleStatus(v.id, e.target.value)}
                        className="p-1.5 bg-white border rounded-xl text-xs font-bold"
                      >
                        <option value="AVAILABLE">AVAILABLE</option>
                        <option value="RESERVED">RESERVED</option>
                        <option value="IN_USE">IN_USE</option>
                        <option value="MAINTENANCE">MAINTENANCE</option>
                        <option value="UNAVAILABLE">UNAVAILABLE</option>
                      </select>
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => setSelectedQRVehicle(v)}
                        className="px-3 py-1 bg-campus-sand text-campus-forest rounded-lg font-bold hover:bg-campus-emerald hover:text-white transition"
                      >
                        QR Sticker
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: USER & ROLE MANAGEMENT */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md overflow-hidden">
          <div className="p-5 border-b flex justify-between items-center text-xs">
            <div>
              <h3 className="font-extrabold text-base text-campus-forest font-display">Campus User & Role Directory</h3>
              <p className="text-gray-500 text-[11px]">Manage student riders, vehicle hosts, staff members, and administrators</p>
            </div>
            <span className="text-gray-500 font-bold">{usersList.length} Accounts Registered</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-campus-sand/40 border-b text-[10px] uppercase font-bold text-gray-500">
                <tr>
                  <th className="p-3.5">User Identity</th>
                  <th className="p-3.5">Role</th>
                  <th className="p-3.5">College Affiliation</th>
                  <th className="p-3.5">KYC Status</th>
                  <th className="p-3.5">Account State</th>
                  <th className="p-3.5 text-right">Administration</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {usersList.map((u) => (
                  <tr key={u.id} className="hover:bg-campus-sand/20 transition">
                    <td className="p-3.5">
                      <div className="font-extrabold text-campus-forest">{u.name}</div>
                      <div className="text-[11px] text-gray-500">{u.email} • ID: {u.student_id || 'N/A'}</div>
                    </td>

                    <td className="p-3.5">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                        u.role === 'ADMIN' ? 'bg-amber-100 text-amber-900 border border-amber-300' :
                        u.role === 'STAFF' ? 'bg-blue-100 text-blue-900 border border-blue-300' :
                        u.role === 'OWNER' ? 'bg-purple-100 text-purple-900 border border-purple-300' :
                        'bg-emerald-100 text-emerald-900 border border-emerald-300'
                      }`}>
                        {u.role}
                      </span>
                    </td>

                    <td className="p-3.5 text-gray-600 font-medium">
                      {u.college_name || 'PSG College of Technology'}
                    </td>

                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-50 text-emerald-700">
                        {u.is_verified ? '✓ VERIFIED' : 'PENDING'}
                      </span>
                    </td>

                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        u.is_active ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {u.is_active ? 'ACTIVE' : 'SUSPENDED'}
                      </span>
                    </td>

                    <td className="p-3.5 text-right">
                      {u.role !== 'ADMIN' && (
                        <button
                          onClick={() => handleToggleUserSuspension(u)}
                          className={`px-3 py-1 rounded-xl text-xs font-bold transition ${
                            u.is_active 
                              ? 'bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200' 
                              : 'bg-emerald-50 hover:bg-emerald-600 text-emerald-700 hover:text-white border border-emerald-200'
                          }`}
                        >
                          {u.is_active ? 'Suspend Account' : 'Reactivate'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: MAINTENANCE */}
      {activeTab === 'maintenance' && (
        <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md p-6 space-y-4">
          <h3 className="font-extrabold text-base text-campus-forest font-display border-b pb-2">
            Maintenance Service Queue & Diagnostics
          </h3>
          {maintenanceList.length === 0 ? (
            <div className="p-8 text-center text-xs text-gray-400">All vehicles are fully operational!</div>
          ) : (
            <div className="space-y-3 text-xs">
              {maintenanceList.map((m) => (
                <div key={m.id} className="p-4 bg-campus-sand/20 rounded-2xl border border-campus-border/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-campus-forest">{m.vehicle_model} ({m.vehicle_number})</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900">{m.issue_type}</span>
                    </div>
                    <p className="text-gray-600 mt-1">{m.description}</p>
                    {m.technician_notes && <p className="text-xs text-campus-emerald mt-0.5">Technician: {m.technician_notes}</p>}
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <select
                      value={m.status}
                      onChange={(e) => handleUpdateMaintenance(m.id, e.target.value)}
                      className="p-2 bg-white border rounded-xl font-bold text-xs"
                    >
                      <option value="SCHEDULED">SCHEDULED</option>
                      <option value="IN_PROGRESS">IN_PROGRESS</option>
                      <option value="COMPLETED">COMPLETED (Return to Pool)</option>
                    </select>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: DAMAGE REPORTS */}
      {activeTab === 'damage' && (
        <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md p-6 space-y-4">
          <h3 className="font-extrabold text-base text-campus-forest font-display border-b pb-2">
            Rider Vehicle Condition & Damage Submissions
          </h3>
          {damageReports.length === 0 ? (
            <div className="p-8 text-center text-xs text-gray-400">No damage reports submitted.</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              {damageReports.map((d) => (
                <div key={d.id} className="p-4 bg-campus-sand/20 rounded-2xl border border-campus-border/60 space-y-2">
                  <div className="flex justify-between font-bold text-campus-forest">
                    <span>{d.vehicle_model} ({d.vehicle_number})</span>
                    <span className="text-[10px] text-gray-400">{d.created_at}</span>
                  </div>
                  <div className="text-gray-600">Rider: {d.user_name} • Report: {d.report_type}</div>
                  {d.has_damage && (
                    <div className="p-2 bg-rose-50 border border-rose-200 rounded-xl text-rose-800">
                      <strong>Damage Reported:</strong> {d.damage_description} ({d.damage_category})
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 6: PRICING CONFIGURATION */}
      {activeTab === 'pricing' && pricingRule && (
        <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md p-6 max-w-lg space-y-4">
          <h3 className="font-extrabold text-base text-campus-forest font-display border-b pb-2">
            Campus Pricing & Discount Policy
          </h3>

          <form onSubmit={handleUpdatePricing} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-gray-700 mb-1">Student Discount Percentage (%)</label>
              <input
                type="number"
                value={pricingRule.student_discount_pct}
                onChange={(e) => setPricingRule({ ...pricingRule, student_discount_pct: Number(e.target.value) })}
                className="w-full p-2.5 bg-campus-sand/20 border rounded-xl font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Off-Peak Green Discount (%)</label>
              <input
                type="number"
                value={pricingRule.off_peak_discount_pct}
                onChange={(e) => setPricingRule({ ...pricingRule, off_peak_discount_pct: Number(e.target.value) })}
                className="w-full p-2.5 bg-campus-sand/20 border rounded-xl font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Late Return Fee (₹ / hour)</label>
              <input
                type="number"
                value={pricingRule.late_fee_per_hour}
                onChange={(e) => setPricingRule({ ...pricingRule, late_fee_per_hour: Number(e.target.value) })}
                className="w-full p-2.5 bg-campus-sand/20 border rounded-xl font-bold"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-campus-forest hover:bg-campus-emerald text-white rounded-2xl font-bold shadow transition"
            >
              Save Pricing Rules
            </button>
          </form>
        </div>
      )}

      {/* Modal: Add Vehicle */}
      {showAddVehicleModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <form onSubmit={handleAddVehicleSubmit} className="bg-white rounded-3xl max-w-md w-full border shadow-2xl p-6 space-y-4 text-xs">
            <div className="flex justify-between items-center border-b pb-2">
              <h3 className="font-extrabold text-base text-campus-forest">Register New Campus Vehicle</h3>
              <button type="button" onClick={() => setShowAddVehicleModal(false)}>✕</button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-bold mb-1">Vehicle Number</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. TN-38-SC-999"
                  value={newVehicle.vehicle_number}
                  onChange={(e) => setNewVehicle({ ...newVehicle, vehicle_number: e.target.value })}
                  className="w-full p-2 border rounded-xl uppercase font-mono font-bold"
                />
              </div>
              <div>
                <label className="block font-bold mb-1">Type</label>
                <select
                  value={newVehicle.type_id}
                  onChange={(e) => {
                    const tid = Number(e.target.value);
                    const t = vehicleTypes.find(x => x.id === tid);
                    setNewVehicle({ ...newVehicle, type_id: tid, is_electric: t ? t.is_electric : false });
                  }}
                  className="w-full p-2 border rounded-xl"
                >
                  {vehicleTypes.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-bold mb-1">Brand</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. TVS / Yamaha"
                  value={newVehicle.brand}
                  onChange={(e) => setNewVehicle({ ...newVehicle, brand: e.target.value })}
                  className="w-full p-2 border rounded-xl"
                />
              </div>
              <div>
                <label className="block font-bold mb-1">Model</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Jupiter 125"
                  value={newVehicle.model}
                  onChange={(e) => setNewVehicle({ ...newVehicle, model: e.target.value })}
                  className="w-full p-2 border rounded-xl"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-bold mb-1">Hourly Tariff (₹)</label>
                <input
                  type="number"
                  required
                  value={newVehicle.hourly_rate}
                  onChange={(e) => setNewVehicle({ ...newVehicle, hourly_rate: Number(e.target.value) })}
                  className="w-full p-2 border rounded-xl font-bold"
                />
              </div>
              <div>
                <label className="block font-bold mb-1">Starting Hub</label>
                <select
                  value={newVehicle.current_zone_id}
                  onChange={(e) => setNewVehicle({ ...newVehicle, current_zone_id: Number(e.target.value) })}
                  className="w-full p-2 border rounded-xl"
                >
                  {zones.map((z) => <option key={z.id} value={z.id}>{z.name}</option>)}
                </select>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button type="button" onClick={() => setShowAddVehicleModal(false)} className="flex-1 py-2 border rounded-xl font-semibold">Cancel</button>
              <button type="submit" className="flex-1 py-2 bg-campus-forest hover:bg-campus-emerald text-white font-bold rounded-xl">Register Vehicle</button>
            </div>
          </form>
        </div>
      )}

      {/* QR Modal */}
      {selectedQRVehicle && (
        <VehicleQRDisplayModal
          vehicle={selectedQRVehicle}
          onClose={() => setSelectedQRVehicle(null)}
        />
      )}

    </div>
  );
}

export default AdminDashboard;
