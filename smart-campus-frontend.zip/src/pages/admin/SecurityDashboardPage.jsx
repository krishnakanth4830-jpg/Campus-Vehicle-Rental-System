import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Users, 
  Bike, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  Ban, 
  Search, 
  Filter, 
  FileText, 
  FileCheck2, 
  History, 
  RefreshCw,
  Eye,
  Check,
  X,
  Phone,
  CreditCard,
  Building
} from 'lucide-react';
import { securityApi } from '../../api/services';
import { useAuth } from '../../context/AuthContext';

export default function SecurityDashboardPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('kyc'); // 'kyc', 'fleet', 'incidents', 'audit'

  // Data states
  const [renters, setRenters] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);

  // Filter & search states
  const [renterSearch, setRenterSearch] = useState('');
  const [renterStatusFilter, setRenterStatusFilter] = useState('ALL');
  const [incidentStatusFilter, setIncidentStatusFilter] = useState('ALL');
  const [auditActionFilter, setAuditActionFilter] = useState('');

  // Resolution modal state
  const [selectedIncident, setSelectedIncident] = useState(null);
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [repairCost, setRepairCost] = useState(0);
  const [depositDeduct, setDepositDeduct] = useState(0);

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    try {
      setLoading(true);
      const [statsRes, rentersRes, bikesRes, incidentsRes, auditRes] = await Promise.all([
        securityApi.getDashboardStats().catch(() => ({ data: { stats: {} } })),
        securityApi.listRenterVerifications().catch(() => ({ data: { verifications: [] } })),
        securityApi.listLookupBikes().catch(() => ({ data: { vehicles: [] } })),
        securityApi.listIncidents().catch(() => ({ data: { incidents: [] } })),
        securityApi.getAuditLogs({ limit: 40 }).catch(() => ({ data: { audit_logs: [] } }))
      ]);

      if (statsRes.data?.success) setStats(statsRes.data.stats);
      if (rentersRes.data?.success) setRenters(rentersRes.data.verifications || []);
      if (bikesRes.data?.success) setVehicles(bikesRes.data.vehicles || []);
      if (incidentsRes.data?.success) setIncidents(incidentsRes.data.incidents || []);
      if (auditRes.data?.success) setAuditLogs(auditRes.data.audit_logs || []);
    } catch (err) {
      console.error('Error loading security dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleReviewKYC = async (verificationId, newStatus, reason = '') => {
    try {
      const res = await securityApi.reviewRenterVerification(verificationId, {
        status: newStatus,
        rejection_reason: reason,
        admin_notes: `Reviewed by Admin ${user?.name || 'Staff'}`
      });
      if (res.data?.success) {
        loadAllData();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Error updating KYC status');
    }
  };

  const handleToggleUserSuspension = async (targetUserId, currentIsActive) => {
    try {
      const res = await securityApi.toggleUserSuspension(targetUserId, {
        suspend: currentIsActive,
        reason: currentIsActive ? 'Administrative safety suspension' : 'Reinstated by Admin'
      });
      if (res.data?.success) {
        loadAllData();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Error toggling user suspension');
    }
  };

  const handleToggleBikeSuspension = async (bikeId, currentStatus) => {
    try {
      const res = await securityApi.toggleBikeSuspension(bikeId, {
        suspend: currentStatus !== 'SUSPENDED',
        reason: 'Fleet safety compliance review'
      });
      if (res.data?.success) {
        loadAllData();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Error toggling vehicle suspension');
    }
  };

  const handleResolveIncident = async (e) => {
    e.preventDefault();
    if (!selectedIncident) return;

    try {
      const res = await securityApi.resolveIncident(selectedIncident.id, {
        status: 'RESOLVED',
        resolution_notes: resolutionNotes,
        repair_cost: parseFloat(repairCost) || 0.0,
        deduct_deposit_amount: parseFloat(depositDeduct) || 0.0
      });

      if (res.data?.success) {
        setSelectedIncident(null);
        setResolutionNotes('');
        setRepairCost(0);
        setDepositDeduct(0);
        loadAllData();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Error resolving incident');
    }
  };

  const filteredRenters = renters.filter((r) => {
    const matchesSearch = 
      r.full_name?.toLowerCase().includes(renterSearch.toLowerCase()) ||
      r.student_id?.toLowerCase().includes(renterSearch.toLowerCase()) ||
      r.college_email?.toLowerCase().includes(renterSearch.toLowerCase());
    const matchesStatus = renterStatusFilter === 'ALL' || r.status === renterStatusFilter;
    return matchesSearch && matchesStatus;
  });

  const filteredIncidents = incidents.filter((inc) => {
    return incidentStatusFilter === 'ALL' || inc.status === incidentStatusFilter;
  });

  const filteredAuditLogs = auditLogs.filter((log) => {
    return !auditActionFilter || log.action?.toLowerCase().includes(auditActionFilter.toLowerCase());
  });

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pt-20 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30 mb-3">
              <ShieldCheck className="w-3.5 h-3.5" /> CENTRAL CAMPUS SECURITY & COMPLIANCE
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">
              Rental Security & Verification Center
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              KYC verification queues, vehicle safety compliance, incident resolutions, and immutable audit logs.
            </p>
          </div>

          <button
            onClick={loadAllData}
            disabled={loading}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 flex items-center gap-2 transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh Telemetry</span>
          </button>
        </div>

        {/* Security Metric Counters */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-blue-500" /> Verified Renters
            </div>
            <div className="mt-2 text-2xl font-black text-slate-900 dark:text-white">
              {stats?.verified_renters ?? 0}
            </div>
            <div className="text-[10px] text-emerald-500 font-semibold mt-1">
              {stats?.renter_kyc_compliance_pct ?? 100}% KYC Compliance
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-500" /> Pending KYC
            </div>
            <div className="mt-2 text-2xl font-black text-amber-500">
              {stats?.pending_renter_verifications ?? 0}
            </div>
            <div className="text-[10px] text-slate-400 mt-1">Needs Approval</div>
          </div>

          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Bike className="w-3.5 h-3.5 text-emerald-500" /> Fleet Verified
            </div>
            <div className="mt-2 text-2xl font-black text-slate-900 dark:text-white">
              {stats?.verified_vehicles ?? 0}
            </div>
            <div className="text-[10px] text-emerald-500 font-semibold mt-1">
              {stats?.fleet_compliance_pct ?? 100}% Insured & RC Valid
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-500" /> Active Rentals
            </div>
            <div className="mt-2 text-2xl font-black text-blue-500">
              {stats?.active_rentals ?? 0}
            </div>
            <div className="text-[10px] text-slate-400 mt-1">Under GPS Watch</div>
          </div>

          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <ShieldAlert className="w-3.5 h-3.5 text-rose-500" /> Open Incidents
            </div>
            <div className="mt-2 text-2xl font-black text-rose-500">
              {stats?.open_incidents ?? 0}
            </div>
            <div className="text-[10px] text-rose-500 font-semibold mt-1">
              {stats?.critical_incidents ?? 0} Critical
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Ban className="w-3.5 h-3.5 text-slate-500" /> Suspended Users
            </div>
            <div className="mt-2 text-2xl font-black text-slate-700 dark:text-slate-300">
              {stats?.suspended_renters ?? 0}
            </div>
            <div className="text-[10px] text-slate-400 mt-1">Safety Blocked</div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 space-x-2 sm:space-x-4 overflow-x-auto pb-1">
          <button
            onClick={() => setActiveTab('kyc')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-bold rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'kyc'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Renter KYC Queue ({renters.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('fleet')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-bold rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'fleet'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Bike className="w-4 h-4" />
            <span>Vehicle Security & RC ({vehicles.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('incidents')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-bold rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'incidents'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>Incident Management ({incidents.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-bold rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'audit'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Audit Trail Log</span>
          </button>
        </div>

        {/* TAB 1: RENTER KYC QUEUE */}
        {activeTab === 'kyc' && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden">
            {/* Filters */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row gap-3 items-center justify-between">
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search student, roll number, email..."
                  value={renterSearch}
                  onChange={(e) => setRenterSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <Filter className="w-4 h-4 text-slate-400" />
                <select
                  value={renterStatusFilter}
                  onChange={(e) => setRenterStatusFilter(e.target.value)}
                  className="px-3 py-1.5 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                >
                  <option value="ALL">All KYC Statuses</option>
                  <option value="PENDING">Pending Review</option>
                  <option value="VERIFIED">Verified Active</option>
                  <option value="SUSPENDED">Suspended</option>
                  <option value="REJECTED">Rejected</option>
                </select>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
                    <th className="p-3">Student Name & ID</th>
                    <th className="p-3">Department & Year</th>
                    <th className="p-3">Driving Licence No.</th>
                    <th className="p-3">Emergency Contact</th>
                    <th className="p-3">KYC Status</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {filteredRenters.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-400">
                        No renter verification records found.
                      </td>
                    </tr>
                  ) : (
                    filteredRenters.map((r) => (
                      <tr key={r.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
                        <td className="p-3">
                          <div className="font-bold text-slate-900 dark:text-white">{r.full_name}</div>
                          <div className="font-mono text-[11px] text-slate-500">{r.student_id} • {r.college_email}</div>
                        </td>
                        <td className="p-3">
                          <div className="text-slate-800 dark:text-slate-200">{r.department}</div>
                          <div className="text-[11px] text-slate-400">{r.year_semester}</div>
                        </td>
                        <td className="p-3 font-mono">
                          <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-[11px] font-bold">
                            {r.driving_licence_number}
                          </span>
                          <div className="text-[10px] text-slate-400 mt-0.5">Exp: {r.licence_expiry_date || 'N/A'}</div>
                        </td>
                        <td className="p-3">
                          <div className="text-slate-800 dark:text-slate-200">{r.emergency_contact_name}</div>
                          <div className="font-mono text-[11px] text-slate-400">{r.emergency_contact_phone}</div>
                        </td>
                        <td className="p-3">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            r.status === 'VERIFIED' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/30' :
                            r.status === 'PENDING' ? 'bg-amber-500/10 text-amber-500 border border-amber-500/30' :
                            r.status === 'SUSPENDED' ? 'bg-rose-500/10 text-rose-500 border border-rose-500/30' : 'bg-slate-500/10 text-slate-500'
                          }`}>
                            {r.status === 'VERIFIED' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                            {r.status}
                          </span>
                        </td>
                        <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                          {r.status !== 'VERIFIED' && (
                            <button
                              onClick={() => handleReviewKYC(r.id, 'VERIFIED')}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-[11px] transition shadow-sm"
                            >
                              Approve ✓
                            </button>
                          )}
                          {r.status === 'VERIFIED' && (
                            <button
                              onClick={() => handleReviewKYC(r.id, 'SUSPENDED', 'Administrative compliance hold')}
                              className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-semibold text-[11px] transition shadow-sm"
                            >
                              Suspend ✕
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: FLEET SECURITY & RC VERIFICATION */}
        {activeTab === 'fleet' && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
                Active Campus Fleet Security Registry ({vehicles.length} Vehicles)
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
                    <th className="p-3">Bike ID & Plate</th>
                    <th className="p-3">Brand & Model</th>
                    <th className="p-3">Campus Zone</th>
                    <th className="p-3">Insurance & RC</th>
                    <th className="p-3">Verification Status</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {vehicles.map((v) => (
                    <tr key={v.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
                      <td className="p-3">
                        <div className="font-mono font-bold text-blue-600 dark:text-blue-400">{v.bike_id}</div>
                        <div className="font-mono text-[11px] text-slate-500">{v.registration_number}</div>
                      </td>
                      <td className="p-3">
                        <div className="font-bold text-slate-900 dark:text-white">{v.brand} {v.model}</div>
                        <div className="text-[11px] text-slate-400">{v.vehicle_type}</div>
                      </td>
                      <td className="p-3 text-slate-800 dark:text-slate-200">
                        {v.zone}
                      </td>
                      <td className="p-3">
                        <div className="text-emerald-500 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Insurance {v.insurance_status || 'VALID'}
                        </div>
                        <div className="text-[11px] text-blue-500">RC Verified ✓</div>
                      </td>
                      <td className="p-3">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          v.is_verified ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/30' : 'bg-rose-500/10 text-rose-500 border border-rose-500/30'
                        }`}>
                          {v.is_verified ? 'VERIFIED' : 'SUSPENDED'}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => handleToggleBikeSuspension(v.id, v.is_verified ? 'VERIFIED' : 'SUSPENDED')}
                          className={`px-2.5 py-1 rounded-lg text-white font-semibold text-[11px] transition shadow-sm ${
                            v.is_verified ? 'bg-rose-600 hover:bg-rose-500' : 'bg-emerald-600 hover:bg-emerald-500'
                          }`}
                        >
                          {v.is_verified ? 'Suspend' : 'Reactivate'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: INCIDENTS & DAMAGE RESOLUTION */}
        {activeTab === 'incidents' && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
                Safety & Damage Incident Log ({incidents.length})
              </h3>
              <select
                value={incidentStatusFilter}
                onChange={(e) => setIncidentStatusFilter(e.target.value)}
                className="px-3 py-1 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
              >
                <option value="ALL">All Incidents</option>
                <option value="REPORTED">Reported / Open</option>
                <option value="UNDER_INVESTIGATION">Under Investigation</option>
                <option value="RESOLVED">Resolved</option>
              </select>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
                    <th className="p-3">Incident Code</th>
                    <th className="p-3">Title & Location</th>
                    <th className="p-3">Severity</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Date</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {filteredIncidents.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-400">
                        No security incidents reported.
                      </td>
                    </tr>
                  ) : (
                    filteredIncidents.map((inc) => (
                      <tr key={inc.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
                        <td className="p-3 font-mono font-bold text-rose-600 dark:text-rose-400">
                          {inc.incident_code}
                        </td>
                        <td className="p-3">
                          <div className="font-bold text-slate-900 dark:text-white">{inc.title}</div>
                          <div className="text-[11px] text-slate-400">{inc.location} • {inc.description?.slice(0, 45)}...</div>
                        </td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            inc.severity === 'CRITICAL' ? 'bg-rose-500/20 text-rose-500' :
                            inc.severity === 'HIGH' ? 'bg-orange-500/20 text-orange-500' :
                            inc.severity === 'MEDIUM' ? 'bg-amber-500/20 text-amber-500' : 'bg-blue-500/20 text-blue-500'
                          }`}>
                            {inc.severity}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            inc.status === 'RESOLVED' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'
                          }`}>
                            {inc.status}
                          </span>
                        </td>
                        <td className="p-3 text-slate-400 text-[11px]">
                          {inc.created_at}
                        </td>
                        <td className="p-3 text-right">
                          {inc.status !== 'RESOLVED' && (
                            <button
                              onClick={() => {
                                setSelectedIncident(inc);
                                setResolutionNotes(inc.resolution_notes || 'Inspected and certified roadworthy.');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-[11px] transition shadow-sm"
                            >
                              Resolve
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: IMMUTABLE AUDIT LOGS */}
        {activeTab === 'audit' && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
                Immutable Security & KYC Audit Log ({filteredAuditLogs.length} Events)
              </h3>
              <input
                type="text"
                placeholder="Filter by action..."
                value={auditActionFilter}
                onChange={(e) => setAuditActionFilter(e.target.value)}
                className="px-3 py-1 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white w-48"
              />
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
                    <th className="p-3">Timestamp</th>
                    <th className="p-3">Action</th>
                    <th className="p-3">Security Event Details</th>
                    <th className="p-3">Client IP</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800 font-mono">
                  {filteredAuditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
                      <td className="p-3 text-slate-500 text-[11px] whitespace-nowrap">
                        {log.timestamp}
                      </td>
                      <td className="p-3">
                        <span className="bg-blue-500/10 text-blue-600 dark:text-blue-400 px-2 py-0.5 rounded font-bold text-[11px]">
                          {log.action}
                        </span>
                      </td>
                      <td className="p-3 text-slate-800 dark:text-slate-200 font-sans text-xs">
                        {log.details}
                      </td>
                      <td className="p-3 text-slate-400 text-[11px]">
                        {log.ip_address}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Resolution Modal */}
        {selectedIncident && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
            <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
              <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
                <h3 className="font-bold text-sm flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-400" />
                  Resolve Incident: {selectedIncident.incident_code}
                </h3>
                <button onClick={() => setSelectedIncident(null)} className="text-slate-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleResolveIncident} className="p-6 space-y-4 text-xs">
                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Resolution & Repair Notes
                  </label>
                  <textarea
                    rows={3}
                    value={resolutionNotes}
                    onChange={(e) => setResolutionNotes(e.target.value)}
                    required
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Repair Cost (₹)
                    </label>
                    <input
                      type="number"
                      value={repairCost}
                      onChange={(e) => setRepairCost(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Deduct from Deposit (₹)
                    </label>
                    <input
                      type="number"
                      value={depositDeduct}
                      onChange={(e) => setDepositDeduct(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white font-mono"
                    />
                  </div>
                </div>

                <div className="pt-3 flex items-center justify-end space-x-2 border-t border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setSelectedIncident(null)}
                    className="px-3 py-1.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg shadow-sm"
                  >
                    Mark as Resolved & Roadworthy
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
