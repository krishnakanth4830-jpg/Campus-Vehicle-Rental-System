import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { vehicleApi, zoneApi } from '../../api/services';
import BatteryIndicator from '../../components/vehicles/BatteryIndicator';
import HealthScoreBadge from '../../components/vehicles/HealthScoreBadge';
import QRDisplayCard from '../../components/qr/QRDisplayCard';
import BookingModal from '../../components/booking/BookingModal';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import { VehicleVisual } from '../../components/common/VehicleVisual';
import {
  Bike,
  Zap,
  MapPin,
  Users,
  Star,
  Activity,
  Calendar,
  CheckCircle2,
  ArrowLeft,
  ShieldCheck,
  Award
} from 'lucide-react';

const VehicleDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [vehicle, setVehicle] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [zones, setZones] = useState([]);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDetail = async () => {
      try {
        setLoading(true);
        const [vRes, zRes] = await Promise.all([
          vehicleApi.getVehicleDetail(id),
          zoneApi.getAllZones(),
        ]);
        if (vRes.data.success) {
          setVehicle(vRes.data.vehicle);
          setReviews(vRes.data.reviews || []);
        }
        if (zRes.data.success) setZones(zRes.data.zones);
      } catch (err) {
        console.error('Failed to load vehicle:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchDetail();
  }, [id]);

  if (loading) return <LoadingSpinner message="Retrieving vehicle telemetry..." />;
  if (!vehicle) {
    return (
      <div className="max-w-xl mx-auto py-20 text-center space-y-4">
        <h2 className="text-xl font-bold">Vehicle Not Found</h2>
        <p className="text-xs text-slate-500">The requested vehicle is not found in the fleet registry.</p>
        <Link to="/vehicles" className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold">
          Back to Catalog
        </Link>
      </div>
    );
  }

  const isAvailable = vehicle.status === 'AVAILABLE';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Back Button */}
      <button
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 px-3.5 py-2 rounded-xl shadow-sm transition-all"
      >
        <ArrowLeft className="w-4 h-4" />
        Back
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Image, Specs & Reviews */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Main Showcase Image */}
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="relative">
              <VehicleVisual vehicle={vehicle} size="hero" showBadge={false} />
              <div className="absolute top-4 left-4">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-900/80 backdrop-blur text-white font-mono">
                  {vehicle.vehicle_number}
                </span>
              </div>
              <div className="absolute top-4 right-4">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-600 text-white shadow-md">
                  {vehicle.status}
                </span>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">{vehicle.type_name}</span>
                  <h1 className="text-2xl font-black text-slate-900">{vehicle.brand} {vehicle.model}</h1>
                </div>
                <div className="text-right">
                  <span className="text-3xl font-black text-slate-900">₹{vehicle.hourly_rate}</span>
                  <span className="text-xs text-slate-500 font-medium"> / hour</span>
                </div>
              </div>

              {/* Vehicle Registration & Host Owner Info Banner */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 font-medium">Vehicle Number:</span>
                  <span className="font-mono font-bold text-emerald-800 bg-white px-2.5 py-1 rounded border border-slate-200 shadow-xs">{vehicle.vehicle_number}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 font-medium">Owner Name:</span>
                  <span className="font-bold text-slate-900">{vehicle.owner_name || vehicle.owner?.name || 'Campus Host'}</span>
                </div>
              </div>

              {/* Stationed Zone Tag */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  <span className="text-slate-600">Stationed at:</span>
                  <span className="font-bold text-slate-900">{vehicle.current_zone_name} ({vehicle.current_zone_code})</span>
                </div>
                <span className="text-[10px] font-bold text-slate-400 uppercase">Dedicated Hub Station</span>
              </div>

              {/* Badges & Telemetry */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                {vehicle.is_electric && (
                  <BatteryIndicator percentage={vehicle.battery_percentage} isCharging={vehicle.is_charging} estimatedRange={vehicle.estimated_range_km} />
                )}
                <HealthScoreBadge score={vehicle.health_score} condition={vehicle.condition_status} />
              </div>
            </div>
          </div>

          {/* Specifications Matrix */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-base font-bold text-slate-900">Technical Specifications</h3>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Rider Capacity</span>
                <span className="font-bold text-slate-800 text-sm">{vehicle.passenger_capacity} Passenger(s)</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Drive Mechanism</span>
                <span className="font-bold text-slate-800 text-sm">{vehicle.is_electric ? 'Electric Assist Motor' : 'Chain / Gear Pedal'}</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Trips Logged</span>
                <span className="font-bold text-slate-800 text-sm">{vehicle.total_trips} Campus Trips</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Clean Distance</span>
                <span className="font-bold text-slate-800 text-sm">{vehicle.total_distance_km} km</span>
              </div>
            </div>
          </div>

          {/* Student Reviews & Ratings */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-1.5">
                <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                <span>Rider Ratings & Feedback ({reviews.length})</span>
              </h3>
              {vehicle.average_rating > 0 && (
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-xl border border-emerald-200">
                  ★ {vehicle.average_rating} Average Rating
                </span>
              )}
            </div>

            {reviews.length === 0 ? (
              <p className="py-6 text-center text-xs text-slate-400">No student reviews yet for this vehicle.</p>
            ) : (
              <div className="divide-y divide-slate-100 space-y-3">
                {reviews.map((r) => (
                  <div key={r.id} className="pt-3 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900">{r.user_name}</span>
                      <div className="flex items-center text-amber-500">
                        {Array.from({ length: r.rating }).map((_, i) => (
                          <Star key={i} className="w-3.5 h-3.5 fill-amber-500" />
                        ))}
                      </div>
                    </div>
                    {r.comment && <p className="text-slate-600 leading-relaxed italic">"{r.comment}"</p>}
                    <span className="text-[10px] text-slate-400 block">
                      {new Date(r.created_at).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: QR Pass & Reservation Action */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Reservation Card */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4 text-center">
            <h3 className="text-base font-bold text-slate-900">Instant Campus Reservation</h3>
            <p className="text-xs text-slate-500">
              Lock in this vehicle with student discount. Unlocks in seconds via QR code.
            </p>

            {isAvailable ? (
              <button
                onClick={() => setShowBookingModal(true)}
                className="w-full py-3.5 px-4 rounded-2xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-lg shadow-emerald-600/20 hover:scale-105 transition-all"
              >
                Reserve Now (₹{vehicle.hourly_rate}/hr)
              </button>
            ) : (
              <button
                disabled
                className="w-full py-3.5 px-4 rounded-2xl text-xs font-bold text-slate-400 bg-slate-100 cursor-not-allowed"
              >
                Currently {vehicle.status}
              </button>
            )}

            <div className="pt-2 text-left text-[11px] text-slate-500 space-y-1">
              <p className="flex items-center gap-1.5 text-emerald-700 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                20% Student Discount automatically applied
              </p>
              <p className="flex items-center gap-1.5 text-slate-600">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Full refund upon on-time return to campus pool
              </p>
            </div>
          </div>

          {/* QR Code Pass */}
          <QRDisplayCard vehicle={vehicle} />

        </div>
      </div>

      {/* Booking Modal */}
      {showBookingModal && (
        <BookingModal
          isOpen={showBookingModal}
          onClose={() => setShowBookingModal(false)}
          vehicle={vehicle}
          zones={zones}
          onBookingSuccess={() => {
            setShowBookingModal(false);
          }}
        />
      )}

    </div>
  );
};

export default VehicleDetailPage;
