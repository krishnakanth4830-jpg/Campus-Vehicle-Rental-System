import React, { useState, useEffect } from 'react';
import { vehicleApi, zoneApi } from '../../api/services';
import VehicleCard from '../../components/vehicles/VehicleCard';
import VehicleFilterBar from '../../components/vehicles/VehicleFilterBar';
import BookingModal from '../../components/booking/BookingModal';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import { Bike, AlertCircle, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

const VehiclesCatalogPage = () => {
  const [vehicles, setVehicles] = useState([]);
  const [types, setTypes] = useState([]);
  const [zones, setZones] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters state
  const [search, setSearch] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [selectedZone, setSelectedZone] = useState('');
  const [selectedElectric, setSelectedElectric] = useState('');
  const [minBattery, setMinBattery] = useState('');
  const [sortBy, setSortBy] = useState('default');

  const [selectedVehicleForBooking, setSelectedVehicleForBooking] = useState(null);

  const fetchCatalogData = async () => {
    try {
      setLoading(true);
      const params = {};
      if (search) params.search = search;
      if (selectedType) params.type_id = selectedType;
      if (selectedZone) params.zone_id = selectedZone;
      if (selectedElectric !== '') params.is_electric = selectedElectric;
      if (minBattery) params.min_battery = minBattery;
      if (sortBy !== 'default') params.sort = sortBy;

      const [vRes, tRes, zRes] = await Promise.all([
        vehicleApi.getVehicles(params),
        vehicleApi.getVehicleTypes(),
        zoneApi.getAllZones(),
      ]);

      if (vRes.data.success) setVehicles(vRes.data.vehicles);
      if (tRes.data.success) setTypes(tRes.data.types);
      if (zRes.data.success) setZones(zRes.data.zones);
    } catch (err) {
      console.error('Failed to load fleet catalog:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCatalogData();
  }, [search, selectedType, selectedZone, selectedElectric, minBattery, sortBy]);

  const handleResetFilters = () => {
    setSearch('');
    setSelectedType('');
    setSelectedZone('');
    setSelectedElectric('');
    setMinBattery('');
    setSortBy('default');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Bike className="w-6 h-6 text-emerald-600" />
            Campus Fleet & Hub Stations
          </h1>
          <p className="text-xs text-slate-500">
            Browse all 20 campus-approved bicycles, smart e-bikes, and e-scooters.
          </p>
        </div>

        <Link
          to="/recommend"
          className="px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all w-fit"
        >
          <Sparkles className="w-4 h-4" />
          <span>Not sure what to ride? Try Smart Match</span>
        </Link>
      </div>

      {/* Filter Bar */}
      <VehicleFilterBar
        search={search}
        setSearch={setSearch}
        selectedType={selectedType}
        setSelectedType={setSelectedType}
        selectedZone={selectedZone}
        setSelectedZone={setSelectedZone}
        selectedElectric={selectedElectric}
        setSelectedElectric={setSelectedElectric}
        minBattery={minBattery}
        setMinBattery={setMinBattery}
        sortBy={sortBy}
        setSortBy={setSortBy}
        types={types}
        zones={zones}
        onReset={handleResetFilters}
      />

      {/* Fleet Grid */}
      {loading ? (
        <LoadingSpinner message="Filtering available campus vehicles..." />
      ) : vehicles.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <AlertCircle className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-slate-900">No Vehicles Matched</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search criteria or resetting filters to view all stationed campus vehicles.
          </p>
          <button
            onClick={handleResetFilters}
            className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 transition-colors"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {vehicles.map((vehicle) => (
            <VehicleCard
              key={vehicle.id}
              vehicle={vehicle}
              onBook={(v) => setSelectedVehicleForBooking(v)}
            />
          ))}
        </div>
      )}

      {/* Booking Modal */}
      {selectedVehicleForBooking && (
        <BookingModal
          isOpen={!!selectedVehicleForBooking}
          onClose={() => setSelectedVehicleForBooking(null)}
          vehicle={selectedVehicleForBooking}
          zones={zones}
          onBookingSuccess={() => {
            fetchCatalogData();
          }}
        />
      )}

    </div>
  );
};

export default VehiclesCatalogPage;
