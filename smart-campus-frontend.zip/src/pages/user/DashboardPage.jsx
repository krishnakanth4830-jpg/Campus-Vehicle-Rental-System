import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { vehicleApi, bookingApi, zoneApi, ecoApi } from '../../api/services';
import VehicleCard from '../../components/vehicles/VehicleCard';
import BookingModal from '../../components/booking/BookingModal';
import EcoScoreCard from '../../components/dashboard/EcoScoreCard';
import ZoneHeatmapCard from '../../components/dashboard/ZoneHeatmapCard';
import { OfficialCampusQRSection } from '../../components/qr/OfficialCampusQRSection';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import { Link, useNavigate } from 'react-router-dom';
import {
  Bike,
  Sparkles,
  Calendar,
  Zap,
  MapPin,
  ArrowRight,
  AlertCircle,
  Clock,
  ShieldCheck,
  LifeBuoy
} from 'lucide-react';

const DashboardPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [vehicles, setVehicles] = useState([]);
  const [zones, setZones] = useState([]);
  const [activeBooking, setActiveBooking] = useState(null);
  const [ecoStats, setEcoStats] = useState(null);
  const [selectedVehicleForBooking, setSelectedVehicleForBooking] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [vRes, bRes, zRes, eRes] = await Promise.all([
        vehicleApi.getVehicles({ status: 'AVAILABLE' }),
        bookingApi.getMyBookings(),
        zoneApi.getAllZones(),
        ecoApi.getStats().catch(() => ({ data: { user_stats: null } })),
      ]);

      if (vRes.data.success) setVehicles(vRes.data.vehicles.slice(0, 4));
      if (zRes.data.success) setZones(zRes.data.zones);
      if (eRes.data) setEcoStats(eRes.data);

      if (bRes.data.success && bRes.data.active_bookings?.length > 0) {
        // Find most recent active or confirmed booking
        const current = bRes.data.active_bookings[0];
        setActiveBooking(current);
      } else {
        setActiveBooking(null);
      }
    } catch (err) {
      console.error('Failed to load dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  if (loading) return <LoadingSpinner message="Loading your campus rider dashboard..." />;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Welcome & Role Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase font-mono">
              {user?.role} • {user?.campus_id}
            </span>
            <span className="text-xs text-slate-400 font-medium">({user?.department})</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">
            Welcome back, {user?.full_name}! 👋
          </h1>
          <p className="text-xs text-slate-500">
            Current Campus Mobility Status: <span className="text-emerald-600 font-bold">Active Rider</span> with 20% student discount enabled.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <Link
            to="/recommend"
            className="px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all"
          >
            <Sparkles className="w-4 h-4" />
            <span>AI Vehicle Match</span>
          </Link>
          <Link
            to="/vehicles"
            className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
          >
            Fleet Catalog
          </Link>
        </div>
      </div>

      {/* Active Rental Alert Banner if user has a booking */}
      {activeBooking && (
        <div className="bg-gradient-to-r from-emerald-600 via-teal-700 to-slate-900 text-white p-6 rounded-3xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-4 animate-in fade-in duration-300">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center shrink-0">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/20 uppercase tracking-wider">
                  {activeBooking.status === 'ACTIVE' ? 'Trip In Progress' : 'Reserved Vehicle'}
                </span>
                <span className="text-xs font-mono text-emerald-200">Ref: {activeBooking.booking_reference}</span>
              </div>
              <h3 className="text-lg font-bold text-white mt-0.5">
                {activeBooking.vehicle_model} ({activeBooking.vehicle_number})
              </h3>
              <p className="text-xs text-slate-300">
                Pickup: {activeBooking.pickup_zone_name} → Return to: {activeBooking.return_zone_name}
              </p>
            </div>
          </div>

          <Link
            to={`/active-rental?booking=${activeBooking.id}`}
            className="w-full md:w-auto px-6 py-3 rounded-2xl text-xs font-bold text-slate-900 bg-emerald-300 hover:bg-emerald-200 shadow-lg transition-all text-center flex items-center justify-center gap-2"
          >
            <span>Open Rental Dashboard & QR</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      )}

      {/* Grid: Eco Score & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6">
          <EcoScoreCard ecoStats={ecoStats} />
        </div>

        {/* Quick Hub Navigation & Assist */}
        <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Link
            to="/recommend"
            className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm hover:border-emerald-300 hover:shadow-md transition-all space-y-2 group flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-700">
                Smart Vehicle Matcher
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                Find the ideal bike or scooter tailored to your route distance and budget.
              </p>
            </div>
            <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 pt-2">
              Start Matcher →
            </span>
          </Link>

          <Link
            to="/emergency-rides"
            className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm hover:border-amber-300 hover:shadow-md transition-all space-y-2 group flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
              <LifeBuoy className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-amber-700">
                Campus Ride Assist
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                Late night travel, rain assistance, or heavy luggage emergency requests.
              </p>
            </div>
            <span className="text-xs font-bold text-amber-600 flex items-center gap-1 pt-2">
              Open Board →
            </span>
          </Link>

          <Link
            to="/my-bookings"
            className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm hover:border-blue-300 hover:shadow-md transition-all space-y-2 group flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-700">
                Rental History & Receipts
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                View completed trips, rate rides, and check digital payment summaries.
              </p>
            </div>
            <span className="text-xs font-bold text-blue-600 flex items-center gap-1 pt-2">
              View History →
            </span>
          </Link>

          <Link
            to="/profile"
            className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm hover:border-slate-300 hover:shadow-md transition-all space-y-2 group flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-2xl bg-slate-100 text-slate-700 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">
                Digital Campus ID Card
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                Manage your student mobility credentials and password settings.
              </p>
            </div>
            <span className="text-xs font-bold text-slate-700 flex items-center gap-1 pt-2">
              Manage Profile →
            </span>
          </Link>
        </div>
      </div>

      {/* Campus Hubs & Live Station Availability */}
      <ZoneHeatmapCard zones={zones} />

      {/* Dedicated Section: OFFICIAL CAMPUS QR STICKER */}
      <OfficialCampusQRSection />

      {/* Nearby Available Vehicles */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-black text-slate-900">Ready to Ride on Campus</h3>
            <p className="text-xs text-slate-500">Pick up immediately from designated campus stations</p>
          </div>
          <Link to="/vehicles" className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1">
            Browse All ({vehicles.length}) →
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {vehicles.map((v) => (
            <VehicleCard
              key={v.id}
              vehicle={v}
              onBook={(veh) => setSelectedVehicleForBooking(veh)}
            />
          ))}
        </div>
      </div>

      {/* Booking Modal */}
      {selectedVehicleForBooking && (
        <BookingModal
          isOpen={!!selectedVehicleForBooking}
          onClose={() => setSelectedVehicleForBooking(null)}
          vehicle={selectedVehicleForBooking}
          zones={zones}
          onBookingSuccess={() => {
            fetchDashboardData();
          }}
        />
      )}

    </div>
  );
};

export default DashboardPage;
