import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Bike, Shield, Sparkles, Loader2, AlertCircle, Building2, Wrench, GraduationCap, KeyRound } from 'lucide-react';
import { ForgotPasswordModal } from '../../components/auth/ForgotPasswordModal';

const LoginPage = () => {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingDemoRole, setLoadingDemoRole] = useState(null);
  const [error, setError] = useState('');
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e, customEmail, customPass) => {
    e?.preventDefault();
    setError('');

    const loginId = customEmail || identifier;
    const loginPass = customPass || password;

    if (!loginId || !loginPass) {
      setError('Please enter your Campus Email or Student ID and password.');
      return;
    }

    try {
      setLoading(true);
      const res = await login(loginId, loginPass);
      if (res.success) {
        if (res.user?.role === 'ADMIN') {
          navigate('/admin/dashboard');
        } else if (res.user?.role === 'STAFF') {
          navigate('/staff/dashboard');
        } else if (res.user?.role === 'OWNER') {
          navigate('/owner/dashboard');
        } else {
          navigate('/dashboard');
        }
      } else {
        setError(res.message || 'Login failed. Please check credentials.');
      }
    } catch (err) {
      setError(err.message || 'Login failed. Please check credentials.');
    } finally {
      setLoading(false);
      setLoadingDemoRole(null);
    }
  };

  const handleInstantDemoLogin = async (role, demoEmail, demoPass) => {
    setIdentifier(demoEmail);
    setPassword(demoPass);
    setLoadingDemoRole(role);
    await handleLogin(null, demoEmail, demoPass);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md space-y-6">
        
        {/* Header with Campus Mobility Logo */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-black border-2 border-emerald-400/60 p-1 flex items-center justify-center mx-auto shadow-xl overflow-hidden">
            <img
              src="/campus-mobility-logo.jpg"
              alt="Campus Mobility Logo"
              className="w-full h-full object-contain"
            />
          </div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">
            CAMPUS<span className="text-emerald-600"> MOBILITY</span> • Sign In
          </h2>
          <p className="text-xs text-slate-500">Access your student, owner, staff, or fleet administration account</p>
        </div>

        {/* 1-Click Demo Credentials Pill Bar */}
        <div className="bg-emerald-50/80 border border-emerald-200 p-3.5 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-emerald-900">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>1-Click Demo Accounts:</span>
            </span>
            <span className="text-[10px] text-emerald-700 font-normal">Instant Login</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              type="button"
              disabled={loading}
              onClick={() => handleInstantDemoLogin('STUDENT', 'student@campus.edu', 'studentpassword123')}
              className="px-2.5 py-2 rounded-xl bg-white border border-emerald-300 text-emerald-800 text-xs font-bold hover:bg-emerald-50 shadow-sm transition-all flex items-center justify-center gap-1 disabled:opacity-50"
            >
              {loadingDemoRole === 'STUDENT' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <GraduationCap className="w-3.5 h-3.5" />}
              <span>Student</span>
            </button>

            <button
              type="button"
              disabled={loading}
              onClick={() => handleInstantDemoLogin('OWNER', 'owner@campus.edu', 'ownerpassword123')}
              className="px-2.5 py-2 rounded-xl bg-white border border-purple-300 text-purple-900 text-xs font-bold hover:bg-purple-50 shadow-sm transition-all flex items-center justify-center gap-1 disabled:opacity-50"
            >
              {loadingDemoRole === 'OWNER' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Building2 className="w-3.5 h-3.5" />}
              <span>Owner</span>
            </button>

            <button
              type="button"
              disabled={loading}
              onClick={() => handleInstantDemoLogin('STAFF', 'staff@campus.edu', 'staffpassword123')}
              className="px-2.5 py-2 rounded-xl bg-white border border-blue-300 text-blue-900 text-xs font-bold hover:bg-blue-50 shadow-sm transition-all flex items-center justify-center gap-1 disabled:opacity-50"
            >
              {loadingDemoRole === 'STAFF' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Wrench className="w-3.5 h-3.5" />}
              <span>Staff</span>
            </button>

            <button
              type="button"
              disabled={loading}
              onClick={() => handleInstantDemoLogin('ADMIN', 'admin@campus.edu', 'adminpassword123')}
              className="px-2.5 py-2 rounded-xl bg-white border border-amber-300 text-amber-900 text-xs font-bold hover:bg-amber-50 shadow-sm transition-all flex items-center justify-center gap-1 disabled:opacity-50"
            >
              {loadingDemoRole === 'ADMIN' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Shield className="w-3.5 h-3.5" />}
              <span>Admin</span>
            </button>
          </div>
        </div>

        {/* Login Form */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xl space-y-5">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Campus Email or ID
              </label>
              <input
                type="text"
                placeholder="e.g. student@campus.edu or staff@campus.edu"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                required
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="login-page-password" className="block text-xs font-bold text-slate-700">
                  Account Password
                </label>
                <button
                  type="button"
                  onClick={() => setShowForgotPassword(true)}
                  className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 hover:underline focus:outline-none focus:ring-2 focus:ring-emerald-500/40 rounded px-1 transition"
                  aria-label="Forgot Password?"
                >
                  Forgot Password?
                </button>
              </div>
              <input
                id="login-page-password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 px-4 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-md shadow-emerald-600/20 hover:shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading && !loadingDemoRole && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>Sign In to Campus Mobility</span>
            </button>
          </form>

          <div className="pt-4 border-t border-slate-100 text-center text-xs text-slate-500">
            New campus rider?{' '}
            <Link to="/register" className="font-bold text-emerald-600 hover:text-emerald-700">
              Register Student Account
            </Link>
          </div>
        </div>

      </div>

      {/* Forgot Password Modal Dialog */}
      <ForgotPasswordModal
        isOpen={showForgotPassword}
        onClose={() => setShowForgotPassword(false)}
        initialEmail={identifier}
      />
    </div>
  );
};

export default LoginPage;
