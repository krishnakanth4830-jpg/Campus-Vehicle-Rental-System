import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { vehicleApi, zoneApi, ecoApi } from '../../api/services';
import VehicleCard from '../../components/vehicles/VehicleCard';
import BookingModal from '../../components/booking/BookingModal';
import ZoneHeatmapCard from '../../components/dashboard/ZoneHeatmapCard';
import { OfficialCampusQRSection } from '../../components/qr/OfficialCampusQRSection';
import {
  Bike,
  Zap,
  Sparkles,
  MapPin,
  Leaf,
  ShieldCheck,
  QrCode,
  ArrowRight,
  RotateCcw,
  Activity,
  Heart,
  Trees
} from 'lucide-react';

const HomePage = () => {
  const [vehicles, setVehicles] = useState([]);
  const [zones, setZones] = useState([]);
  const [campusStats, setCampusStats] = useState(null);
  const [selectedVehicleForBooking, setSelectedVehicleForBooking] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const loadHomeData = async () => {
      try {
        setLoading(true);
        const [vRes, zRes, eRes] = await Promise.all([
          vehicleApi.getVehicles({ status: 'AVAILABLE' }),
          zoneApi.getAllZones(),
          ecoApi.getStats().catch(() => ({ data: { campus_stats: null } })),
        ]);

        if (vRes.data.success) setVehicles(vRes.data.vehicles.slice(0, 6));
        if (zRes.data.success) setZones(zRes.data.zones);
        if (eRes.data?.campus_stats) setCampusStats(eRes.data.campus_stats);
      } catch (err) {
        console.error('Failed to load homepage data:', err);
      } finally {
        setLoading(false);
      }
    };
    loadHomeData();
  }, []);

  return (
    <div className="space-y-16 pb-20">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-950 text-white py-20 px-4 sm:px-6 lg:px-8 rounded-b-[40px] shadow-2xl">
        <div className="max-w-7xl mx-auto relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-black/40 border border-emerald-400/40 text-emerald-300 text-xs font-bold backdrop-blur-md shadow-lg">
              <img src="/campus-mobility-logo.jpg" alt="Campus Mobility" className="w-4 h-4 rounded-full object-contain" />
              <span>CAMPUS MOBILITY • Zero-Carbon Micro-Mobility</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight">
              Campus Mobility <span className="text-emerald-400 underline decoration-emerald-500/40">Smarter & Greener.</span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              Rent smart e-bikes, cycles, and scooters stationed at key campus hubs. Unlock in seconds with QR codes, get AI vehicle recommendations, and contribute to our university sustainability score.
            </p>

            {/* Quick Action CTA Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <Link
                to="/vehicles"
                className="px-6 py-3.5 rounded-2xl text-sm font-bold text-slate-900 bg-emerald-400 hover:bg-emerald-300 shadow-xl shadow-emerald-500/20 hover:scale-105 transition-all flex items-center gap-2"
              >
                <Bike className="w-4 h-4 text-slate-900" />
                <span>Explore Campus Fleet</span>
                <ArrowRight className="w-4 h-4" />
              </Link>

              <Link
                to="/recommend"
                className="px-6 py-3.5 rounded-2xl text-sm font-bold text-white bg-white/10 hover:bg-white/20 border border-white/20 backdrop-blur-md transition-all flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Smart Match Wizard</span>
              </Link>
            </div>

            {/* Quick Metric Badges */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-white/10 max-w-lg">
              <div>
                <p className="text-2xl font-black text-emerald-400">20+</p>
                <p className="text-xs text-slate-300">Fleet Vehicles</p>
              </div>
              <div>
                <p className="text-2xl font-black text-emerald-400">6 Hubs</p>
                <p className="text-xs text-slate-300">Campus Zones</p>
              </div>
              <div>
                <p className="text-2xl font-black text-emerald-400">0 kg</p>
                <p className="text-xs text-slate-300">Emissions</p>
              </div>
            </div>
          </div>

          {/* Hero Visual Card / QR Preview */}
          <div className="lg:col-span-5">
            <div className="bg-white/10 backdrop-blur-xl border border-white/20 p-6 rounded-3xl shadow-2xl space-y-5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">Live Campus Pulse</span>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              </div>

              <div className="p-4 bg-slate-900/80 rounded-2xl border border-white/10 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Main Campus Gate (ZN-MG)</span>
                  <span className="font-bold text-emerald-400">9 Available</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Central Library Hub (ZN-LIB)</span>
                  <span className="font-bold text-emerald-400">5 Available</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Academic Block (ZN-ACAD)</span>
                  <span className="font-bold text-emerald-400">6 Available</span>
                </div>
              </div>

              <div className="p-4 bg-emerald-500/20 rounded-2xl border border-emerald-400/30 flex items-center gap-3">
                <QrCode className="w-10 h-10 text-emerald-300 shrink-0" />
                <div className="text-xs">
                  <p className="font-bold text-white">Instant QR Unlock</p>
                  <p className="text-emerald-200 text-[11px]">Scan with phone camera or web scanner to begin your trip immediately.</p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* Dedicated Section: OFFICIAL CAMPUS QR STICKER */}
      <OfficialCampusQRSection className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" />

      {/* Core Innovation Highlights */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            Why Campus Mobility
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            Engineered Specially for University Life
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Unlike commercial rental apps, our system features zone redistribution, student discounts, and condition diagnostics.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              <RotateCcw className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Return-to-Pool Redistribution</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              When returning a ride, consent to pool it for the next peer. Vehicles are instantly available at your return zone with live tracking.
            </p>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Smart Vehicle Recommendation</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Enter your trip distance, budget, and passenger count to receive transparent suitability scoring without paid external AI APIs.
            </p>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Health Diagnostics & Photos</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Inspect vehicle health scores (0-100), upload condition photos before and after rides, and flag damage directly to campus maintenance.
            </p>
          </div>
        </div>
      </section>

      {/* Campus Zones & Station Heatmap */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ZoneHeatmapCard zones={zones} />
      </section>

      {/* Featured Vehicles Ready for Immediate Reservation */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-black text-slate-900">Available Vehicles on Campus</h3>
            <p className="text-xs text-slate-500">Pick up now with 20% student discount applied</p>
          </div>

          <Link
            to="/vehicles"
            className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
          >
            View All 20 Vehicles →
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {vehicles.map((v) => (
            <VehicleCard
              key={v.id}
              vehicle={v}
              onBook={(veh) => setSelectedVehicleForBooking(veh)}
            />
          ))}
        </div>
      </section>

      {/* Booking Modal */}
      {selectedVehicleForBooking && (
        <BookingModal
          isOpen={!!selectedVehicleForBooking}
          onClose={() => setSelectedVehicleForBooking(null)}
          vehicle={selectedVehicleForBooking}
          zones={zones}
          onBookingSuccess={() => {
            // refresh
          }}
        />
      )}

    </div>
  );
};

export default HomePage;
