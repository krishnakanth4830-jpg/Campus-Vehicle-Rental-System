import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Bike, Shield, User, Lock, ArrowRight, AlertCircle, Sparkles, Loader2, Building2, Wrench, GraduationCap, KeyRound } from 'lucide-react';
import { ForgotPasswordModal } from '../../components/auth/ForgotPasswordModal';

export function Login({ setTab }) {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingDemoRole, setLoadingDemoRole] = useState(null);
  const [error, setError] = useState(null);
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  const performLogin = async (loginEmail, loginPass) => {
    setLoading(true);
    setError(null);

    const res = await login(loginEmail, loginPass);
    setLoading(false);
    setLoadingDemoRole(null);

    if (res.success) {
      if (res.user?.role === 'ADMIN') {
        setTab('admin-dashboard');
      } else if (res.user?.role === 'STAFF') {
        setTab('staff-dashboard');
      } else if (res.user?.role === 'OWNER') {
        setTab('owner-dashboard');
      } else {
        setTab('dashboard');
      }
    } else {
      setError(res.message || 'Invalid login credentials. Please try again.');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please fill in all fields.');
      return;
    }
    await performLogin(email, password);
  };

  // 1-Click Instant Demo Login
  const handleInstantDemoLogin = async (demoRole, demoEmail, demoPass) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    setLoadingDemoRole(demoRole);
    await performLogin(demoEmail, demoPass);
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center py-10 px-4">
      <div className="bg-white rounded-3xl max-w-md w-full border border-campus-border/80 shadow-2xl p-6 sm:p-8 space-y-6">
        
        {/* Brand Header with Campus Mobility Logo */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-black border-2 border-emerald-400/60 p-1 flex items-center justify-center mx-auto shadow-xl overflow-hidden">
            <img
              src="/campus-mobility-logo.jpg"
              alt="Campus Mobility Logo"
              className="w-full h-full object-contain"
            />
          </div>
          <h2 className="text-xl font-extrabold text-campus-forest font-display tracking-tight">
            CAMPUS<span className="text-emerald-600"> MOBILITY</span> • Sign In
          </h2>
          <p className="text-xs text-gray-500">Smart mobility portal for students, owners, staff & admins</p>
        </div>

        {/* 1-Click Demo Accounts Pill Bar */}
        <div className="bg-campus-sand/40 border border-campus-border p-3.5 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-[11px] font-bold text-campus-forest">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-campus-gold" />
              <span>1-CLICK DEMO LOGIN (SELECT ROLE):</span>
            </span>
            <span className="text-[10px] text-gray-500 font-normal">Instant Access</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              type="button"
              disabled={loading}
              onClick={() => handleInstantDemoLogin('STUDENT', 'student@campus.edu', 'studentpassword123')}
              className="p-2.5 rounded-xl bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-200 transition font-bold shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              {loadingDemoRole === 'STUDENT' ? <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-600" /> : <GraduationCap className="w-4 h-4 text-emerald-600" />}
              <span>🎓 Student</span>
            </button>

            <button
              type="button"
              disabled={loading}
              onClick={() => handleInstantDemoLogin('OWNER', 'owner@campus.edu', 'ownerpassword123')}
              className="p-2.5 rounded-xl bg-white hover:bg-purple-50 text-purple-900 border border-purple-200 transition font-bold shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              {loadingDemoRole === 'OWNER' ? <Loader2 className="w-3.5 h-3.5 animate-spin text-purple-600" /> : <Building2 className="w-4 h-4 text-purple-600" />}
              <span>🏢 Owner</span>
            </button>

            <button
              type="button"
              disabled={loading}
              onClick={() => handleInstantDemoLogin('STAFF', 'staff@campus.edu', 'staffpassword123')}
              className="p-2.5 rounded-xl bg-white hover:bg-blue-50 text-blue-900 border border-blue-200 transition font-bold shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              {loadingDemoRole === 'STAFF' ? <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600" /> : <Wrench className="w-4 h-4 text-blue-600" />}
              <span>👨‍🏫 Staff</span>
            </button>

            <button
              type="button"
              disabled={loading}
              onClick={() => handleInstantDemoLogin('ADMIN', 'admin@campus.edu', 'adminpassword123')}
              className="p-2.5 rounded-xl bg-white hover:bg-amber-50 text-amber-900 border border-amber-300 transition font-bold shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              {loadingDemoRole === 'ADMIN' ? <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-600" /> : <Shield className="w-4 h-4 text-campus-gold" />}
              <span>🛡️ Admin</span>
            </button>
          </div>
        </div>

        {/* Error Banner */}
        {error && (
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2 text-xs text-rose-700 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Standard Manual Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-gray-700 mb-1">Campus Email or ID</label>
            <div className="relative">
              <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="student@campus.edu / staff@campus.edu / admin@campus.edu"
                className="w-full pl-10 pr-4 py-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-campus-emerald/40 font-medium"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="login-password" className="block font-bold text-gray-700">Password</label>
              <button
                type="button"
                onClick={() => setShowForgotPassword(true)}
                className="text-[11px] font-bold text-campus-emerald hover:text-campus-forest hover:underline focus:outline-none focus:ring-2 focus:ring-campus-emerald/40 rounded px-1 transition"
                aria-label="Forgot Password?"
              >
                Forgot Password?
              </button>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
              <input
                id="login-password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full pl-10 pr-4 py-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-campus-emerald/40 font-medium"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-campus-forest to-campus-emerald text-white rounded-2xl font-bold shadow-lg hover:shadow-xl hover:from-campus-emerald hover:to-campus-forest transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading && !loadingDemoRole && <Loader2 className="w-4 h-4 animate-spin" />}
            <span>{loading ? 'Authenticating...' : 'Sign In to Campus Mobility'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Footer */}
        <div className="text-center text-xs text-gray-500">
          New student rider?{' '}
          <button
            onClick={() => setTab('register')}
            className="font-bold text-campus-emerald hover:underline"
          >
            Register Student Account
          </button>
        </div>

      </div>

      {/* Forgot Password Modal Dialog */}
      <ForgotPasswordModal
        isOpen={showForgotPassword}
        onClose={() => setShowForgotPassword(false)}
        initialEmail={email}
      />
    </div>
  );
}

export default Login;
