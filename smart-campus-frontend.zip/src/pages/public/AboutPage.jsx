import React from 'react';
import { Bike, Leaf, Shield, Heart, Award, Sparkles, Trees, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';

const AboutPage = () => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      
      {/* Title Header */}
      <div className="text-center space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
          Green Campus Initiative
        </span>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          Smart Campus Vehicle Rental & Mobility System
        </h1>
        <p className="text-sm text-slate-500 max-w-2xl mx-auto">
          An integrated university micro-mobility platform dedicated to decarbonizing student and staff commute across university hubs.
        </p>
      </div>

      {/* Vision & Mission Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            <Leaf className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Zero-Emission Campus Vision</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Eliminating gasoline vehicle dependency on campus roads through a shared network of electric bicycles, kick-scooters, and pedal bikes stationed at academic, residential, and recreational hubs.
          </p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold">
            <Sparkles className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Return-to-Pool Innovation</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Unlike static commercial car rentals, our system employs dynamic zone redistribution where students return vehicles into shared pools, immediately updating availability for the next peer.
          </p>
        </div>
      </div>

      {/* Unique Capabilities Grid */}
      <div className="bg-slate-900 text-white p-8 rounded-3xl shadow-xl space-y-6">
        <h3 className="text-xl font-bold text-emerald-400">Architectural Innovations</h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-xs text-slate-300">
          <div className="space-y-1.5">
            <h4 className="font-bold text-white text-sm">1. Multi-factor Matcher</h4>
            <p className="text-slate-400">Deterministic suitability scoring considering trip distance, budget constraints, passengers, and battery range.</p>
          </div>

          <div className="space-y-1.5">
            <h4 className="font-bold text-white text-sm">2. Diagnostic Health (0-100)</h4>
            <p className="text-slate-400">Real-time health assessment combining maintenance history, reported damage incidents, and battery degradation.</p>
          </div>

          <div className="space-y-1.5">
            <h4 className="font-bold text-white text-sm">3. QR Secure Activation</h4>
            <p className="text-slate-400">Encrypted token verification prevents unauthorized unlocks and double-booking concurrency collisions.</p>
          </div>

          <div className="space-y-1.5">
            <h4 className="font-bold text-white text-sm">4. Carbon Offset Ledger</h4>
            <p className="text-slate-400">Tracks gram-level CO2 avoided vs. fossil-fuel vehicle trips, computing campus tree equivalency.</p>
          </div>

          <div className="space-y-1.5">
            <h4 className="font-bold text-white text-sm">5. Pre/Post Inspection Photos</h4>
            <p className="text-slate-400">Secure photographic proof upload protecting student riders while maintaining fleet integrity.</p>
          </div>

          <div className="space-y-1.5">
            <h4 className="font-bold text-white text-sm">6. Zone Demand Heatmap</h4>
            <p className="text-slate-400">Visualizes peak morning/evening influx and net vehicle movements between university hubs.</p>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
        <h3 className="text-lg font-bold text-slate-900">Frequently Asked Questions</h3>
        
        <div className="space-y-4 text-xs">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <h4 className="font-bold text-slate-900">How do I unlock a vehicle?</h4>
            <p className="text-slate-600">Reserve a vehicle online, walk to the designated campus hub, open your Active Rental screen, and scan the QR code located on the handlebar.</p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <h4 className="font-bold text-slate-900">Can I return the vehicle to a different campus hub?</h4>
            <p className="text-slate-600">Yes! You can return your vehicle to any of our 6 active campus zones (Main Gate, Library, Academic Block, Hostels, Cafeteria, Sports Complex). Simply select Return-to-Pool.</p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <h4 className="font-bold text-slate-900">What happens if a vehicle is low on battery?</h4>
            <p className="text-slate-600">Our pre-trip validator warns you if the route distance exceeds the vehicle's estimated range. Low-battery vehicles are automatically queued for solar charging.</p>
          </div>
        </div>
      </div>

    </div>
  );
};

export default AboutPage;
