import React from 'react';
import { MapPin, QrCode, Bike, RotateCcw, CheckCircle2, Shield, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const HowItWorksPage = () => {
  const steps = [
    {
      num: '01',
      title: 'Find & Reserve',
      desc: 'Browse vehicles by campus zone or use our Smart Match Recommendation tool to select the best e-bike, cycle, or scooter for your trip.',
      icon: MapPin,
      color: 'bg-emerald-50 text-emerald-600 border-emerald-200'
    },
    {
      num: '02',
      title: 'Scan QR at Hub',
      desc: 'Walk to the designated pickup station. Tap "Scan QR" in your Active Rental dashboard and point your phone at the vehicle token.',
      icon: QrCode,
      color: 'bg-teal-50 text-teal-600 border-teal-200'
    },
    {
      num: '03',
      title: 'Ride & Save Carbon',
      desc: 'Enjoy a sweat-free zero-emission commute across campus. Live trip timer and battery range indicators keep you updated.',
      icon: Bike,
      color: 'bg-blue-50 text-blue-600 border-blue-200'
    },
    {
      num: '04',
      title: 'Return to Pool',
      desc: 'Park in any designated campus zone, upload quick condition photos if needed, and confirm Return-to-Pool to make it available for the next student.',
      icon: RotateCcw,
      color: 'bg-indigo-50 text-indigo-600 border-indigo-200'
    }
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      
      {/* Title */}
      <div className="text-center space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
          User Guide
        </span>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          How Smart Campus Mobility Works
        </h1>
        <p className="text-sm text-slate-500 max-w-xl mx-auto">
          Four simple steps to navigate our green campus in minutes.
        </p>
      </div>

      {/* Steps Flow */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {steps.map((step) => {
          const Icon = step.icon;
          return (
            <div
              key={step.num}
              className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3 relative overflow-hidden"
            >
              <div className="flex items-center justify-between">
                <div className={`p-3 rounded-2xl border ${step.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
                <span className="text-2xl font-black text-slate-200 font-mono">{step.num}</span>
              </div>

              <h3 className="text-base font-bold text-slate-900">{step.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{step.desc}</p>
            </div>
          );
        })}
      </div>

      {/* Call to action */}
      <div className="bg-gradient-to-r from-emerald-800 to-teal-900 text-white p-8 rounded-3xl text-center space-y-4 shadow-xl">
        <h3 className="text-xl font-black">Ready for your first campus green ride?</h3>
        <p className="text-xs text-emerald-200 max-w-md mx-auto">
          Sign up with your student email and enjoy a 20% discount on all campus e-bikes and bicycles.
        </p>
        <div className="flex justify-center gap-3 pt-2">
          <Link
            to="/register"
            className="px-6 py-3 rounded-xl bg-emerald-400 text-slate-900 text-xs font-bold hover:bg-emerald-300 shadow-md transition-all"
          >
            Register Student Account
          </Link>
          <Link
            to="/vehicles"
            className="px-6 py-3 rounded-xl bg-white/10 text-white border border-white/20 text-xs font-bold hover:bg-white/20 transition-all"
          >
            Browse Available Fleet
          </Link>
        </div>
      </div>

    </div>
  );
};

export default HowItWorksPage;
