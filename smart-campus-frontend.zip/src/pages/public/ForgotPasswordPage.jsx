import React, { useState } from 'react';
import { Bike, KeyRound, User, ArrowRight, CheckCircle2, AlertCircle, Loader2, ShieldCheck, ArrowLeft } from 'lucide-react';
import { apiRequest } from '../../api/client';

export function ForgotPasswordPage({ setTab }) {
  const [emailOrId, setEmailOrId] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState('');

  const handleGoBack = () => {
    if (setTab) {
      setTab('login');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!emailOrId.trim()) {
      setError('Please enter your Campus Email or Student/Staff ID.');
      return;
    }

    setLoading(true);
    setError(null);

    const res = await apiRequest('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email: emailOrId.trim() })
    });

    setLoading(false);

    if (res.success) {
      setSubmitted(true);
      setMessage(res.message || 'If an account exists for this campus email or ID, a password reset link has been sent.');
    } else {
      setError(res.message || 'Unable to process reset request. Please try again.');
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-10 px-4">
      <div className="bg-white rounded-3xl max-w-md w-full border border-campus-border/80 shadow-2xl p-6 sm:p-8 space-y-6 animate-in fade-in">
        
        {/* Brand Header with Campus Mobility Logo */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-black border-2 border-emerald-400/60 p-1 flex items-center justify-center mx-auto shadow-xl overflow-hidden">
            <img
              src="/campus-mobility-logo.jpg"
              alt="Campus Mobility Logo"
              className="w-full h-full object-contain"
            />
          </div>
          <h2 className="text-xl font-extrabold text-campus-forest font-display tracking-tight">
            CAMPUS<span className="text-emerald-600"> MOBILITY</span> • Reset Password
          </h2>
          <p className="text-xs text-gray-500">
            Recover your student, owner, staff, or admin login credentials
          </p>
        </div>

        {submitted ? (
          <div className="space-y-4 text-center py-2 animate-in fade-in">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center mx-auto shadow-sm">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-extrabold text-campus-forest font-display">
                Reset Link Dispatched
              </h3>
              <p className="text-xs text-gray-600 leading-relaxed px-2">
                {message}
              </p>
            </div>
            <div className="p-3 bg-campus-sand/20 rounded-xl border border-campus-border/60 text-[11px] text-gray-500 flex items-center justify-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-campus-emerald" />
              <span>Valid for all campus account roles</span>
            </div>
            <button
              type="button"
              onClick={handleGoBack}
              className="w-full py-3 px-4 bg-campus-forest text-white rounded-xl text-xs font-bold hover:bg-campus-emerald transition shadow-md flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Return to Sign In</span>
            </button>
          </div>
        ) : (
          <>
            <p className="text-xs text-gray-600 leading-relaxed">
              Enter your registered <strong>Campus Email address</strong> or <strong>Student/Staff ID</strong>. If an account is associated with this identifier, a password reset link will be dispatched to your email.
            </p>

            {error && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2 text-xs text-rose-700 animate-in fade-in">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label htmlFor="page-email-input" className="block font-bold text-gray-700 mb-1">
                  Campus Email or ID
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                  <input
                    id="page-email-input"
                    type="text"
                    required
                    autoFocus
                    value={emailOrId}
                    onChange={(e) => setEmailOrId(e.target.value)}
                    placeholder="student@campus.edu / 21CS108 / staff@campus.edu"
                    className="w-full pl-10 pr-4 py-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-campus-emerald/40 font-medium text-xs text-campus-charcoal"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || !emailOrId.trim()}
                className="w-full py-3 bg-gradient-to-r from-campus-forest to-campus-emerald text-white rounded-2xl font-bold shadow-lg hover:shadow-xl hover:from-campus-emerald hover:to-campus-forest transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
                <span>{loading ? 'Transmitting Request...' : 'Send Password Reset Link'}</span>
              </button>
            </form>

            <div className="pt-2 text-center text-xs text-gray-500 border-t border-campus-border/40">
              Remember your password?{' '}
              <button
                type="button"
                onClick={handleGoBack}
                className="font-bold text-campus-emerald hover:underline"
              >
                Back to Sign In
              </button>
            </div>
          </>
        )}

      </div>
    </div>
  );
}

export default ForgotPasswordPage;
