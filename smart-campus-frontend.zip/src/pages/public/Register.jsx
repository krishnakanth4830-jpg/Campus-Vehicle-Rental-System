import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Bike, User, Mail, Phone, BookOpen, Lock, ArrowRight, AlertCircle, Shield } from 'lucide-react';

export function Register({ setTab }) {
  const { register } = useAuth();
  const [formData, setFormData] = useState({
    name: '',
    student_id: '',
    email: '',
    phone: '',
    department: 'Information Technology',
    year_of_study: '3rd Year',
    role: 'STUDENT',
    password: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const res = await register(formData);
    setLoading(false);

    if (res.success) {
      setTab('dashboard');
    } else {
      setError(res.message || 'Registration failed.');
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center py-10 px-4">
      <div className="bg-white rounded-3xl max-w-lg w-full border border-campus-border/80 shadow-2xl p-6 sm:p-8 space-y-6">
        
        {/* Brand Header with Campus Mobility Logo */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-black border-2 border-emerald-400/60 p-1 flex items-center justify-center mx-auto shadow-xl overflow-hidden">
            <img
              src="/campus-mobility-logo.jpg"
              alt="Campus Mobility Logo"
              className="w-full h-full object-contain"
            />
          </div>
          <h2 className="text-xl font-extrabold text-campus-forest font-display tracking-tight">
            CAMPUS<span className="text-emerald-600"> MOBILITY</span> • Register
          </h2>
          <p className="text-xs text-gray-500">Instant access to campus bicycles, e-scooters & mobility perks</p>
        </div>

        {/* Error Banner */}
        {error && (
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2 text-xs text-rose-700">
            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-gray-700 mb-1">Full Name</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Senthil Kumar"
                className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-campus-emerald/40"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Student / Staff ID</label>
              <input
                type="text"
                required
                value={formData.student_id}
                onChange={(e) => setFormData({ ...formData, student_id: e.target.value })}
                placeholder="e.g. 727721EUIT145"
                className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-campus-emerald/40 uppercase font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-gray-700 mb-1">Campus Email</label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="name@campus.edu"
                className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-campus-emerald/40"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Phone Number</label>
              <input
                type="tel"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="9876543210"
                className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-campus-emerald/40"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-gray-700 mb-1">Role</label>
              <select
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                className="w-full p-2.5 bg-white border border-campus-border/80 rounded-xl font-medium"
              >
                <option value="STUDENT">Student</option>
                <option value="STAFF">Staff / Faculty</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Department</label>
              <select
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                className="w-full p-2.5 bg-white border border-campus-border/80 rounded-xl font-medium"
              >
                <option value="Information Technology">IT</option>
                <option value="Computer Science & Engg">CSE</option>
                <option value="Electronics & Comm Engg">ECE</option>
                <option value="Mechanical Engineering">Mech</option>
                <option value="Electrical & Electronics">EEE</option>
                <option value="AI & Data Science">AI & DS</option>
                <option value="Civil Engineering">Civil</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Year</label>
              <select
                value={formData.year_of_study}
                onChange={(e) => setFormData({ ...formData, year_of_study: e.target.value })}
                className="w-full p-2.5 bg-white border border-campus-border/80 rounded-xl font-medium"
              >
                <option value="1st Year">1st Year</option>
                <option value="2nd Year">2nd Year</option>
                <option value="3rd Year">3rd Year</option>
                <option value="4th Year">4th Year</option>
                <option value="Faculty">Faculty</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-bold text-gray-700 mb-1">Password</label>
            <input
              type="password"
              required
              minLength={6}
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              placeholder="At least 6 characters"
              className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-campus-emerald/40"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-campus-forest to-campus-emerald text-white rounded-2xl font-bold shadow-lg hover:shadow-xl transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <span>{loading ? 'Creating Account...' : 'Complete Registration (+50 Eco Pts)'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="text-center text-xs text-gray-500">
          Already registered on campus?{' '}
          <button
            onClick={() => setTab('login')}
            className="font-bold text-campus-emerald hover:underline"
          >
            Sign In
          </button>
        </div>

      </div>
    </div>
  );
}
