import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useBooking } from '../../context/BookingContext';
import { CampusMap } from '../../components/map/CampusMap';
import { OfficialCampusQRSection } from '../../components/qr/OfficialCampusQRSection';
import { 
  Bike, Zap, ShieldCheck, MapPin, QrCode, Leaf, 
  ArrowRight, Award, Clock, HeartHandshake, Compass 
} from 'lucide-react';

export function Home({ setTab }) {
  const { isAuthenticated, user } = useAuth();
  const { zones = [], vehicles = [] } = useBooking();

  const safeVehicles = Array.isArray(vehicles) ? vehicles : [];
  const safeZones = Array.isArray(zones) ? zones : [];

  const totalAvailable = safeVehicles.filter(v => v && v.status === 'AVAILABLE').length;
  const evCount = safeVehicles.filter(v => v && v.is_electric).length;
  const normalCount = safeVehicles.length - evCount;

  return (
    <div className="space-y-12 pb-16">
      
      {/* Hero Section */}
      <section className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-campus-forest via-campus-emerald to-emerald-900 text-white shadow-2xl p-8 sm:p-12 border border-campus-mint/30">
        <div className="relative z-10 max-w-2xl space-y-6">
          <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-black/40 backdrop-blur-md border border-emerald-400/40 text-campus-mint text-xs font-bold shadow-lg">
            <img src="/campus-mobility-logo.jpg" alt="Campus Mobility" className="w-4 h-4 rounded-full object-contain" />
            <span>CAMPUS MOBILITY • Clean Micro-Transit</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold font-display leading-tight tracking-tight">
            Smart Campus Mobility & Live Telemetry System.
          </h1>

          <p className="text-sm sm:text-base text-gray-200 leading-relaxed">
            Rent campus bicycles, geared bikes, and smart e-scooters with instant QR unlock, dynamic student pricing, and campus Return-to-Pool hubs.
          </p>

          <div className="flex flex-wrap gap-3 pt-2">
            <button
              onClick={() => setTab('vehicles')}
              className="px-6 py-3.5 bg-campus-gold hover:bg-amber-400 text-campus-forest font-extrabold text-xs sm:text-sm rounded-2xl shadow-xl transition flex items-center gap-2"
            >
              <Bike className="w-4 h-4" />
              <span>Browse Campus Fleet ({totalAvailable} Ready)</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => setTab('recommendation')}
              className="px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white border border-white/30 font-bold text-xs sm:text-sm rounded-2xl backdrop-blur-md transition flex items-center gap-2"
            >
              <Zap className="w-4 h-4 text-campus-gold" />
              <span>Smart Vehicle Match</span>
            </button>
          </div>

          {/* Quick Metrics */}
          <div className="pt-6 border-t border-white/10 grid grid-cols-3 gap-4 text-left">
            <div>
              <div className="text-xl sm:text-2xl font-extrabold text-campus-mint">{vehicles.length}+</div>
              <div className="text-[11px] text-gray-300">Total Fleet ({normalCount} Cycles • {evCount} EVs)</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-extrabold text-campus-gold">{zones.length}</div>
              <div className="text-[11px] text-gray-300">Campus Mobility Hubs</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-extrabold text-white">15%</div>
              <div className="text-[11px] text-gray-300">Student Discount Active</div>
            </div>
          </div>
        </div>
      </section>

      {/* Dedicated Section: OFFICIAL CAMPUS QR STICKER */}
      <OfficialCampusQRSection />

      {/* Interactive Map & Hub Availability */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <CampusMap zones={zones} />
        </div>

        <div className="bg-white rounded-3xl border border-campus-border/80 p-6 shadow-md flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-extrabold text-campus-forest uppercase tracking-wider mb-2">
              <Compass className="w-4 h-4 text-campus-emerald" />
              <span>Active Campus Hubs</span>
            </div>
            <h3 className="font-extrabold text-lg text-campus-forest font-display">Pick Up & Return Anywhere</h3>
            <p className="text-xs text-gray-500 mt-1">
              Select any hub to pick up a vehicle. Return to any active checkpoint on campus to replenish the pool.
            </p>

            <div className="mt-4 space-y-2.5 max-h-60 overflow-y-auto pr-1">
              {zones.map((z) => (
                <div key={z.id} className="p-3 bg-campus-sand/30 hover:bg-campus-sand/60 rounded-2xl border border-campus-border/60 flex items-center justify-between text-xs transition">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-campus-emerald flex-shrink-0" />
                    <div>
                      <div className="font-bold text-campus-forest">{z.name}</div>
                      <div className="text-[10px] text-gray-500">{z.description}</div>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-xl bg-campus-forest text-campus-mint font-bold text-[11px]">
                    {z.available_vehicles} available
                  </span>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => setTab('vehicles')}
            className="w-full py-2.5 bg-campus-forest hover:bg-campus-emerald text-white rounded-2xl font-bold text-xs transition shadow flex items-center justify-center gap-2"
          >
            <span>View All Vehicles in Hubs</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </section>

      {/* Feature Pillars */}
      <section className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { icon: Zap, title: "EV & Manual Options", desc: "Choose between pedal bicycles, geared bikes, and smart electric scooters." },
          { icon: QrCode, title: "Instant QR Unlock", desc: "No physical key exchange. Point your mobile camera at the vehicle QR sticker." },
          { icon: Leaf, title: "Return-to-Pool", desc: "Reassign vehicles dynamically to new drop-off hubs and earn bonus Eco Points." },
          { icon: ShieldCheck, title: "Health & Damage Check", desc: "Pre/post rental condition photos and dynamic vehicle health diagnostics." }
        ].map((f, i) => {
          const Icon = f.icon;
          return (
            <div key={i} className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-2.5 hover:border-campus-emerald transition">
              <div className="w-10 h-10 rounded-2xl bg-campus-sand/60 text-campus-forest flex items-center justify-center">
                <Icon className="w-5 h-5 text-campus-emerald" />
              </div>
              <h4 className="font-extrabold text-sm text-campus-forest font-display">{f.title}</h4>
              <p className="text-xs text-gray-600 leading-relaxed">{f.desc}</p>
            </div>
          );
        })}
      </section>

    </div>
  );
}
