import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { apiRequest } from '../../api/client';
import { X, QrCode, Download, Printer, ShieldCheck } from 'lucide-react';

export function VehicleQRDisplayModal({ vehicle, onClose }) {
  const [qrData, setQrData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadQR() {
      if (!vehicle) return;
      const res = await apiRequest(`/vehicles/${vehicle.id}/qr`);
      if (res.success) {
        setQrData(res);
      }
      setLoading(false);
    }
    loadQR();

    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [vehicle, onClose]);

  if (!vehicle) return null;

  const modalContent = (
    <div 
      className="fixed inset-0 z-[9999] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="bg-white rounded-3xl max-w-sm w-full border border-campus-border/80 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200 text-center my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="bg-campus-forest text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2 text-left">
            <QrCode className="w-5 h-5 text-campus-gold" />
            <div>
              <span className="text-[9px] font-extrabold uppercase tracking-widest text-campus-mint block">
                CAMPUS MOBILITY PROTOCOL
              </span>
              <h2 className="text-sm font-extrabold font-display">
                OFFICIAL CAMPUS QR STICKER
              </h2>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-white/10 text-gray-300 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* QR Body */}
        <div className="p-6 space-y-4">
          <div>
            <h3 className="font-extrabold text-base text-campus-forest">{vehicle.brand} {vehicle.model}</h3>
            <div className="mt-1 flex flex-col items-center gap-1 text-xs">
              <span className="font-mono font-bold text-campus-forest bg-slate-100 px-2.5 py-0.5 rounded border border-slate-200">
                Vehicle Number: {vehicle.vehicle_number}
              </span>
              <span className="text-gray-600 font-medium">
                Owner: <strong className="text-gray-900">{vehicle.owner_name || vehicle.owner?.name || 'Campus Host'}</strong>
              </span>
            </div>
          </div>

          {/* Official Provided QR Sticker Container */}
          <div className="p-3 bg-white rounded-2xl border-2 border-slate-200 shadow-md inline-block mx-auto">
            <img
              src="/official_campus_qr.jpg"
              alt="OFFICIAL CAMPUS QR STICKER"
              className="w-56 h-auto mx-auto select-none rounded-xl"
            />
          </div>

          <p className="text-xs font-bold text-campus-forest">
            Scan to Access Official Campus Rental
          </p>

          <div className="flex items-center justify-center gap-1.5 text-[11px] text-gray-500 font-medium">
            <ShieldCheck className="w-4 h-4 text-campus-emerald" />
            <span>Scan via rider app or camera to unlock & start ride</span>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-gray-50 border-t border-gray-100">
          <button
            onClick={() => window.print()}
            className="w-full py-2.5 bg-campus-forest text-white text-xs font-bold rounded-2xl hover:bg-campus-emerald transition flex items-center justify-center gap-2"
          >
            <Printer className="w-4 h-4" />
            <span>Print Vehicle Sticker</span>
          </button>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalContent, document.body) : null;
}
