import React from 'react';
import { QrCode, Shield, Download, Smartphone } from 'lucide-react';

const QRDisplayCard = ({ vehicle }) => {
  if (!vehicle) return null;

  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm text-center space-y-4">
      <div className="inline-flex p-3 rounded-2xl bg-emerald-50 text-emerald-700">
        <QrCode className="w-6 h-6" />
      </div>

      <div>
        <span className="text-[9px] font-extrabold uppercase tracking-widest text-emerald-700 block mb-0.5">
          CAMPUS MOBILITY PROTOCOL
        </span>
        <h3 className="text-sm font-extrabold text-slate-900 font-display">OFFICIAL CAMPUS QR STICKER</h3>
        <p className="text-xs text-slate-500">Scan at pickup station to verify and unlock</p>
      </div>

      {/* Official QR Code Graphic */}
      <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 inline-block mx-auto shadow-sm">
        <img
          src="/official_campus_qr.jpg"
          alt="OFFICIAL CAMPUS QR STICKER"
          className="w-48 h-auto object-contain mx-auto rounded-xl select-none"
        />
      </div>

      <p className="text-xs font-bold text-slate-900">
        Scan to Access Official Campus Rental
      </p>

      <div className="bg-slate-100 p-2.5 rounded-xl text-xs font-mono font-bold text-slate-700 flex items-center justify-between">
        <span>Vehicle: {vehicle.vehicle_number}</span>
        <span className="text-slate-500 font-normal">Token: {vehicle.qr_code_token}</span>
      </div>

      <div className="text-left text-xs text-slate-500 bg-emerald-50/60 p-3 rounded-xl border border-emerald-100 space-y-1">
        <p className="font-semibold text-emerald-900 flex items-center gap-1">
          <Shield className="w-3.5 h-3.5" />
          Secure QR Verification Protocol:
        </p>
        <p>1. Ensure your booking is active for this vehicle.</p>
        <p>2. Tap 'Scan QR' in the Active Rental tab.</p>
        <p>3. Vehicle unlocks automatically upon verification.</p>
      </div>
    </div>
  );
};

export default QRDisplayCard;
