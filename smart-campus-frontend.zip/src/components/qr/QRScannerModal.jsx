import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { apiRequest } from '../../api/client';
import { X, QrCode, Camera, CheckCircle2, AlertCircle, ArrowRight, Zap } from 'lucide-react';

export function QRScannerModal({ targetVehicle, onVerifySuccess, onClose }) {
  const [manualToken, setManualToken] = useState(targetVehicle?.qr_code_token || targetVehicle?.vehicle_number || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [scanSuccess, setScanSuccess] = useState(null);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  const handleVerifyQR = async (tokenToVerify) => {
    const token = tokenToVerify || manualToken;
    if (!token.trim()) {
      setError('Please enter or scan a valid vehicle QR code.');
      return;
    }

    setLoading(true);
    setError(null);

    const res = await apiRequest('/qr/scan-lookup', {
      method: 'POST',
      body: JSON.stringify({ qr_token: token.trim() })
    });

    setLoading(false);

    if (res.success && res.is_valid) {
      setScanSuccess(res);
      setTimeout(() => {
        onVerifySuccess(res);
      }, 1200);
    } else {
      setError(res.message || 'Invalid vehicle QR code.');
    }
  };

  const modalContent = (
    <div 
      className="fixed inset-0 z-[9999] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="bg-white rounded-3xl max-w-md w-full border border-campus-border/80 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200 my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="bg-campus-forest text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <QrCode className="w-5 h-5 text-campus-gold" />
            <span className="font-extrabold text-sm font-display">Campus Vehicle QR Scanner</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-white/10 text-gray-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-center">
          
          {scanSuccess ? (
            <div className="py-6 space-y-3">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto animate-bounce">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="font-extrabold text-base text-campus-forest">QR Code Verified!</h3>
              <p className="text-xs text-gray-600">
                Matched vehicle: <strong className="text-campus-forest">{scanSuccess.vehicle?.brand} {scanSuccess.vehicle?.model}</strong> ({scanSuccess.vehicle?.vehicle_number})
              </p>
            </div>
          ) : (
            <>
              {/* Camera Scanner Simulation Frame */}
              <div className="relative w-56 h-56 mx-auto bg-campus-forest/90 rounded-3xl border-4 border-campus-mint/50 overflow-hidden flex flex-col items-center justify-center shadow-inner">
                {/* Laser scan line animation */}
                <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-campus-mint to-transparent animate-pulse top-1/2"></div>
                
                <QrCode className="w-24 h-24 text-campus-mint/70 animate-pulse" />
                <span className="text-[11px] font-bold text-campus-mint mt-2 tracking-wide">
                  ALIGN QR CODE HERE
                </span>

                {/* Corner guide markers */}
                <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-campus-gold"></div>
                <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-campus-gold"></div>
                <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-campus-gold"></div>
                <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-campus-gold"></div>
              </div>

              {/* Error Message */}
              {error && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2 text-xs text-rose-700 text-left">
                  <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* 1-Click Instant Demo Verification Button */}
              {targetVehicle && (
                <div className="p-3 bg-campus-sand/40 border border-campus-border/60 rounded-2xl text-left">
                  <div className="text-[10px] uppercase font-bold text-gray-500 mb-1">Target Vehicle To Unlock</div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-bold text-xs text-campus-forest">{targetVehicle.brand} {targetVehicle.model}</div>
                      <div className="text-[11px] font-mono text-gray-500">{targetVehicle.vehicle_number}</div>
                    </div>
                    <button
                      onClick={() => handleVerifyQR(targetVehicle.qr_code_token || targetVehicle.vehicle_number)}
                      disabled={loading}
                      className="px-3 py-1.5 bg-campus-emerald text-white text-xs font-bold rounded-xl hover:bg-campus-forest transition shadow"
                    >
                      {loading ? 'Verifying...' : '⚡ Simulate Scan'}
                    </button>
                  </div>
                </div>
              )}

              {/* Manual QR Code Input */}
              <div className="pt-2 text-left">
                <label className="block text-[11px] font-bold text-gray-600 mb-1">
                  Or Enter Vehicle QR Token / Number manually:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={manualToken}
                    onChange={(e) => setManualToken(e.target.value)}
                    placeholder="e.g. TN-38-CY-101 or token..."
                    className="flex-1 px-3 py-2 bg-campus-sand/20 border border-campus-border/80 rounded-xl text-xs text-campus-charcoal focus:outline-none focus:ring-2 focus:ring-campus-emerald/40 font-mono"
                  />
                  <button
                    onClick={() => handleVerifyQR(manualToken)}
                    disabled={loading || !manualToken.trim()}
                    className="px-4 py-2 bg-campus-forest text-white rounded-xl text-xs font-bold hover:bg-campus-emerald transition disabled:opacity-50"
                  >
                    Verify
                  </button>
                </div>
              </div>
            </>
          )}

        </div>

      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalContent, document.body) : null;
}
