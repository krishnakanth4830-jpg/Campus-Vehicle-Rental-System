﻿import React from 'react';
import { QrCode, ShieldCheck, Printer, Download, Sparkles, Smartphone, CheckCircle2 } from 'lucide-react';
import officialQrImg from '../../assets/official_campus_qr.jpg';

export function OfficialCampusQRSection({ className = '', showActions = true }) {
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>OFFICIAL CAMPUS QR STICKER - Campus Mobility</title>
            <style>
              body {
                font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                margin: 0;
                background-color: #f8fafc;
              }
              .sticker-card {
                background: #ffffff;
                border: 2px solid #e2e8f0;
                border-radius: 24px;
                padding: 32px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.08);
                text-align: center;
                max-width: 380px;
                width: 100%;
              }
              .sticker-header {
                font-size: 14px;
                font-weight: 800;
                letter-spacing: 0.1em;
                color: #064e3b;
                margin-bottom: 8px;
                text-transform: uppercase;
              }
              .qr-image-wrapper {
                background: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 20px;
                padding: 16px;
                display: inline-block;
                margin: 16px 0;
              }
              .qr-image {
                width: 280px;
                height: auto;
                display: block;
                border-radius: 12px;
              }
              .subtext {
                font-size: 13px;
                font-weight: 700;
                color: #0f172a;
                margin-top: 12px;
              }
              .footer-badge {
                font-size: 11px;
                color: #64748b;
                margin-top: 6px;
              }
            </style>
          </head>
          <body>
            <div class="sticker-card">
              <div class="sticker-header">OFFICIAL CAMPUS QR STICKER</div>
              <div class="qr-image-wrapper">
                <img src="/official_campus_qr.jpg" class="qr-image" alt="Official Campus QR Sticker" />
              </div>
              <div class="subtext">Scan to Access Official Campus Rental</div>
              <div class="footer-badge">CAMPUS MOBILITY • Verified Transit Pass</div>
            </div>
            <script>
              window.onload = function() {
                window.print();
              };
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    }
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = '/official_campus_qr.jpg';
    link.download = 'Official-Campus-QR-Sticker.jpg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section className={`w-full ${className}`}>
      <div className="bg-white rounded-3xl border border-campus-border/80 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden relative group">
        
        {/* Top Header Banner */}
        <div className="bg-gradient-to-r from-campus-forest via-emerald-950 to-slate-900 text-white px-6 py-5 flex flex-wrap items-center justify-between gap-3 border-b border-campus-mint/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-campus-mint/20 border border-campus-mint/40 text-campus-mint flex items-center justify-center shrink-0 shadow-inner">
              <QrCode className="w-5 h-5 text-campus-gold" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-campus-mint">
                  CAMPUS MOBILITY PROTOCOL
                </span>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/20 text-campus-mint border border-campus-mint/30 flex items-center gap-1">
                  <CheckCircle2 className="w-2.5 h-2.5" />
                  <span>100% Scannable</span>
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-black font-display tracking-tight text-white mt-0.5">
                OFFICIAL CAMPUS QR STICKER
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {showActions && (
              <>
                <button
                  onClick={handleDownload}
                  className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-white/20 shadow-sm"
                  title="Download High-Resolution Official QR"
                >
                  <Download className="w-3.5 h-3.5 text-campus-gold" />
                  <span className="hidden sm:inline">Download</span>
                </button>
                <button
                  onClick={handlePrint}
                  className="px-3.5 py-1.5 bg-campus-gold hover:bg-amber-400 text-campus-forest rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 shadow-md"
                  title="Print Official Sticker"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Sticker</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Sticker Card Body */}
        <div className="p-6 sm:p-8 flex flex-col items-center justify-center text-center bg-gradient-to-b from-slate-50/50 via-white to-campus-sand/20">
          
          {/* Outer Sticker Container with subtle border, shadow, and rounded corners */}
          <div className="bg-white rounded-3xl p-5 sm:p-7 border-2 border-slate-200/90 shadow-xl max-w-sm sm:max-w-md w-full transition-transform duration-300 hover:scale-[1.01] relative">
            
            {/* Top Corner Pill */}
            <div className="absolute -top-3.5 left-1/2 transform -translate-x-1/2 px-3 py-1 rounded-full bg-campus-forest text-campus-mint text-[10px] font-extrabold uppercase tracking-wider border border-campus-mint/30 shadow-md flex items-center gap-1.5 whitespace-nowrap">
              <ShieldCheck className="w-3.5 h-3.5 text-campus-gold" />
              <span>Official Vehicle & Hub Access Pass</span>
            </div>

            {/* Centered QR Code Image Container with clean white space */}
            <div className="mt-2 p-3 bg-white rounded-2xl border border-slate-100 flex items-center justify-center mx-auto overflow-hidden">
              <img
                src={officialQrImg}
                alt="OFFICIAL CAMPUS QR STICKER"
                className="w-full max-w-[280px] sm:max-w-[320px] h-auto object-contain mx-auto select-none rounded-xl"
                style={{ imageRendering: 'auto' }}
              />
            </div>

            {/* Required Text Below Image */}
            <div className="mt-4 pt-3 border-t border-slate-100 space-y-1">
              <p className="text-sm sm:text-base font-extrabold text-campus-forest tracking-tight">
                Scan to Access Official Campus Rental
              </p>
              <p className="text-xs text-gray-500 font-medium flex items-center justify-center gap-1">
                <Smartphone className="w-3.5 h-3.5 text-campus-emerald" />
                <span>Compatible with all smartphone cameras and UPI/Rider apps</span>
              </p>
            </div>
          </div>

          {/* Guidelines info badge */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3 text-xs text-gray-600 max-w-lg">
            <span className="flex items-center gap-1 font-semibold text-campus-forest">
              <CheckCircle2 className="w-4 h-4 text-campus-emerald" />
              <span>Instant Station Unlock</span>
            </span>
            <span className="text-gray-300">•</span>
            <span className="flex items-center gap-1 font-semibold text-campus-forest">
              <CheckCircle2 className="w-4 h-4 text-campus-emerald" />
              <span>Zero App Download Required</span>
            </span>
            <span className="text-gray-300">•</span>
            <span className="flex items-center gap-1 font-semibold text-campus-forest">
              <CheckCircle2 className="w-4 h-4 text-campus-emerald" />
              <span>High-Precision Scannability</span>
            </span>
          </div>

        </div>

      </div>
    </section>
  );
}

export default OfficialCampusQRSection;
