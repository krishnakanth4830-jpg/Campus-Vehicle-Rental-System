import React, { useState } from 'react';
import Modal from '../common/Modal';
import PhotoUploader from './PhotoUploader';
import { rentalApi } from '../../api/services';
import { AlertTriangle, Loader2, CheckCircle2, ShieldAlert } from 'lucide-react';

const DamageReportModal = ({ isOpen, onClose, booking, vehicle, onReportSubmitted }) => {
  const [reportedDamage, setReportedDamage] = useState('Scratched Frame / Handle');
  const [notes, setNotes] = useState('');
  const [photos, setPhotos] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  if (!booking || !vehicle) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    try {
      setSubmitting(true);
      
      // If photos contain File objects, use FormData
      const hasRealFiles = photos.some((p) => p instanceof File);
      
      let res;
      if (hasRealFiles) {
        const formData = new FormData();
        formData.append('booking_id', booking.id);
        formData.append('vehicle_id', vehicle.id);
        formData.append('inspection_type', 'POST_RENTAL');
        formData.append('reported_damage', reportedDamage);
        formData.append('notes', notes);
        formData.append('has_damage', 'true');
        photos.forEach((f) => {
          if (f instanceof File) formData.append('photos', f);
        });
        res = await rentalApi.uploadConditionReport(formData);
      } else {
        res = await rentalApi.uploadConditionReport({
          booking_id: booking.id,
          vehicle_id: vehicle.id,
          inspection_type: 'POST_RENTAL',
          reported_damage: reportedDamage,
          notes: notes,
          has_damage: true,
          photos: typeof photos[0] === 'string' ? photos : [],
        });
      }

      if (res.data.success) {
        setSuccess(true);
        if (onReportSubmitted) onReportSubmitted(res.data.report);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to submit damage report.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Report Vehicle Issue or Damage" maxWidth="max-w-lg">
      {success ? (
        <div className="text-center py-6 space-y-3">
          <div className="w-14 h-14 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-slate-900">Damage Report Logged</h3>
          <p className="text-xs text-slate-600 max-w-sm mx-auto">
            Report flagged for Campus Fleet Maintenance. Our technical team will inspect {vehicle.vehicle_number}. You will not be held liable for pre-existing or wear-and-tear conditions.
          </p>
          <button
            onClick={onClose}
            className="mt-4 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-slate-900 hover:bg-slate-800"
          >
            Close
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5 text-xs text-amber-800">
            <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Honest Campus Inspection</p>
              <p className="text-[11px] text-amber-700">
                Reporting issues ensures the next student has a safe ride and assists campus maintenance in quick repairs.
              </p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Issue Category
            </label>
            <select
              value={reportedDamage}
              onChange={(e) => setReportedDamage(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:ring-2 focus:ring-amber-500"
              required
            >
              <option value="Loose or Squeaking Brakes">Loose or Squeaking Brakes</option>
              <option value="Flat or Low Pressure Tire">Flat or Low Pressure Tire</option>
              <option value="Chain / Pedal Mechanism Issue">Chain / Pedal Mechanism Issue</option>
              <option value="Scratched Frame / Handle">Scratched Frame / Handle</option>
              <option value="Headlight / Tail LED Not Working">Headlight / Tail LED Not Working</option>
              <option value="Battery Charging / Gauge Fluctuation">Battery Charging / Gauge Fluctuation</option>
              <option value="Other Minor Physical Defect">Other Minor Physical Defect</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Description & Location of Defect
            </label>
            <textarea
              rows={3}
              placeholder="e.g. Left handlebar grip was loose upon return..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:ring-2 focus:ring-amber-500"
              required
            />
          </div>

          <PhotoUploader onPhotosChange={setPhotos} maxPhotos={3} />

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-semibold">
              {error}
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 shadow-md flex items-center gap-1.5"
            >
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>Submit Issue to Fleet Tech</span>
            </button>
          </div>
        </form>
      )}
    </Modal>
  );
};

export default DamageReportModal;
