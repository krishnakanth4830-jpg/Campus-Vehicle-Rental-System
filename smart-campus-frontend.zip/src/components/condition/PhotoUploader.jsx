import React, { useState } from 'react';
import { Camera, Upload, X, Image as ImageIcon, Sparkles } from 'lucide-react';

const PhotoUploader = ({ onPhotosChange, maxPhotos = 3 }) => {
  const [previews, setPreviews] = useState([]);
  const [files, setFiles] = useState([]);

  const handleFileSelect = (e) => {
    const selectedFiles = Array.from(e.target.files);
    if (!selectedFiles.length) return;

    const newFiles = [...files, ...selectedFiles].slice(0, maxPhotos);
    setFiles(newFiles);

    // Create preview URLs
    const newPreviews = newFiles.map((file) => URL.createObjectURL(file));
    setPreviews(newPreviews);

    if (onPhotosChange) {
      onPhotosChange(newFiles);
    }
  };

  const removePhoto = (index) => {
    const newFiles = files.filter((_, i) => i !== index);
    const newPreviews = previews.filter((_, i) => i !== index);
    setFiles(newFiles);
    setPreviews(newPreviews);
    if (onPhotosChange) {
      onPhotosChange(newFiles);
    }
  };

  // Add demo sample photo for instant browser testing without files
  const addSamplePhoto = () => {
    const sampleUrl = 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=600';
    if (previews.length < maxPhotos) {
      const updatedPreviews = [...previews, sampleUrl];
      setPreviews(updatedPreviews);
      if (onPhotosChange) {
        onPhotosChange(updatedPreviews);
      }
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-xs">
        <label className="font-bold text-slate-700 flex items-center gap-1.5">
          <Camera className="w-4 h-4 text-slate-500" />
          Vehicle Inspection Photos ({previews.length}/{maxPhotos})
        </label>
        {previews.length < maxPhotos && (
          <button
            type="button"
            onClick={addSamplePhoto}
            className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Add Demo Photo
          </button>
        )}
      </div>

      {/* Grid of photos and upload dropzone */}
      <div className="grid grid-cols-3 gap-3">
        {previews.map((preview, index) => (
          <div key={index} className="relative aspect-video rounded-xl overflow-hidden border border-slate-200 bg-slate-100 group">
            <img src={preview} alt={`Inspection ${index + 1}`} className="w-full h-full object-cover" />
            <button
              type="button"
              onClick={() => removePhoto(index)}
              className="absolute top-1.5 right-1.5 p-1 rounded-full bg-slate-900/70 text-white hover:bg-rose-600 transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}

        {previews.length < maxPhotos && (
          <label className="flex flex-col items-center justify-center aspect-video rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 hover:bg-slate-100 cursor-pointer transition-colors text-slate-500 hover:text-slate-700 p-2 text-center">
            <Upload className="w-5 h-5 mb-1 text-slate-400" />
            <span className="text-[11px] font-semibold">Upload Photo</span>
            <span className="text-[9px] text-slate-400">PNG, JPG up to 10MB</span>
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileSelect}
              className="hidden"
            />
          </label>
        )}
      </div>
    </div>
  );
};

export default PhotoUploader;
