import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { KeyRound, Mail, User, ArrowRight, CheckCircle2, AlertCircle, Loader2, X, ShieldCheck } from 'lucide-react';
import { apiRequest } from '../../api/client';

export function ForgotPasswordModal({ isOpen, onClose, initialEmail = '' }) {
  const [emailOrId, setEmailOrId] = useState(initialEmail);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (isOpen) {
      setEmailOrId(initialEmail);
      setSubmitted(false);
      setError(null);
      setMessage('');

      const handleKeyDown = (e) => {
        if (e.key === 'Escape') onClose();
      };
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = 'auto';
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [isOpen, initialEmail, onClose]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!emailOrId.trim()) {
      setError('Please enter your Campus Email or Student/Staff ID.');
      return;
    }

    setLoading(true);
    setError(null);

    const res = await apiRequest('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email: emailOrId.trim() })
    });

    setLoading(false);

    if (res.success) {
      setSubmitted(true);
      setMessage(res.message || 'If an account exists for this campus email or ID, a password reset link has been sent.');
    } else {
      setError(res.message || 'Unable to process reset request. Please try again.');
    }
  };

  if (!isOpen) return null;

  const modalContent = (
    <div
      className="fixed inset-0 z-[9999] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="forgot-password-title"
    >
      <div
        className="bg-white rounded-3xl max-w-md w-full border border-campus-border/80 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200 my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-campus-forest text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-campus-emerald/30 border border-campus-mint/30 flex items-center justify-center text-campus-mint">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-campus-mint block">
                CAMPUS SECURITY
              </span>
              <h2 id="forgot-password-title" className="text-base font-extrabold font-display">
                Reset Account Password
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-gray-300 hover:text-white transition focus:outline-none focus:ring-2 focus:ring-campus-mint"
            aria-label="Close password reset modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {submitted ? (
            <div className="space-y-4 text-center py-2 animate-in fade-in">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-extrabold text-campus-forest font-display">
                  Reset Link Dispatched
                </h3>
                <p className="text-xs text-gray-600 leading-relaxed px-2">
                  {message}
                </p>
              </div>
              <div className="p-3 bg-campus-sand/20 rounded-xl border border-campus-border/60 text-[11px] text-gray-500 flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-campus-emerald" />
                <span>Valid for all roles (Student, Owner, Staff, Admin)</span>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 px-4 bg-campus-forest text-white rounded-xl text-xs font-bold hover:bg-campus-emerald transition shadow-md focus:outline-none focus:ring-2 focus:ring-campus-emerald"
              >
                Back to Sign In
              </button>
            </div>
          ) : (
            <>
              <p className="text-xs text-gray-600 leading-relaxed">
                Enter your registered <strong>Campus Email address</strong> or <strong>Student/Staff ID</strong> below. We will send you instructions to securely reset your credentials.
              </p>

              {error && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs text-rose-700 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                <div>
                  <label htmlFor="reset-email-input" className="block font-bold text-gray-700 mb-1">
                    Campus Email or ID
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                    <input
                      id="reset-email-input"
                      type="text"
                      required
                      autoFocus
                      value={emailOrId}
                      onChange={(e) => setEmailOrId(e.target.value)}
                      placeholder="e.g. student@campus.edu or 21CS108"
                      className="w-full pl-10 pr-4 py-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-campus-emerald/40 font-medium text-xs text-campus-charcoal"
                    />
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="flex-1 py-2.5 px-4 border border-campus-border/80 text-gray-700 rounded-xl font-bold hover:bg-gray-100 transition focus:outline-none focus:ring-2 focus:ring-gray-300"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={loading || !emailOrId.trim()}
                    className="flex-1 py-2.5 px-4 bg-gradient-to-r from-campus-forest to-campus-emerald text-white rounded-xl font-bold hover:from-campus-emerald hover:to-campus-forest transition shadow-md flex items-center justify-center gap-1.5 disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-campus-emerald"
                  >
                    {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ArrowRight className="w-3.5 h-3.5" />}
                    <span>{loading ? 'Sending...' : 'Send Reset Link'}</span>
                  </button>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalContent, document.body) : null;
}

export default ForgotPasswordModal;
