import React, { useMemo } from 'react';
import { Search, Filter, Fuel, MapPin, Sliders, Shield, GraduationCap, Building2 } from 'lucide-react';

export function VehicleFilter({ zones = [], filters = {}, setFilters, onReset }) {
  // Extract unique colleges and cities from zones list safely
  const safeZones = Array.isArray(zones) ? zones : [];

  const { colleges, cities } = useMemo(() => {
    const colSet = new Set();
    const citySet = new Set();
    safeZones.forEach(z => {
      if (z && z.college_name) colSet.add(z.college_name);
      if (z && z.city) citySet.add(z.city);
    });
    return {
      colleges: Array.from(colSet).sort(),
      cities: Array.from(citySet).sort()
    };
  }, [safeZones]);

  // Filter available zones by chosen college/city
  const filteredZones = useMemo(() => {
    return safeZones.filter(z => {
      if (!z) return false;
      if (filters?.college_name && z.college_name !== filters.college_name) return false;
      if (filters?.city && z.city !== filters.city) return false;
      return true;
    });
  }, [safeZones, filters?.college_name, filters?.city]);

  return (
    <div className="bg-white rounded-3xl border border-campus-border/80 p-5 shadow-sm space-y-4">
      
      {/* Top Search & Category Selector */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
        
        {/* Search Bar */}
        <div className="md:col-span-5 relative">
          <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            placeholder="Search TVS, Royal Enfield, Yamaha, Hyundai or TN number..."
            value={filters?.search || ''}
            onChange={(e) => setFilters && setFilters({ ...filters, search: e.target.value })}
            className="w-full pl-10 pr-4 py-2.5 bg-campus-sand/30 border border-campus-border/70 rounded-2xl text-xs text-campus-charcoal focus:outline-none focus:ring-2 focus:ring-campus-emerald/50"
          />
        </div>

        {/* Petrol Vehicle Category Quick Tabs */}
        <div className="md:col-span-7 flex p-1 bg-campus-sand/40 border border-campus-border/60 rounded-2xl overflow-x-auto text-xs">
          {[
            { id: '', label: 'All Petrol Fleet' },
            { id: 'SCOOTER', label: '🛵 Scooters' },
            { id: 'MOTORCYCLE', label: '🏍️ Motorcycles' },
            { id: 'CRUISER', label: '🦅 Cruisers (350cc)' },
            { id: 'MOPED', label: '🛵 Mopeds' },
            { id: 'CAR', label: '🚗 Cars' }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setFilters && setFilters({ ...filters, category: cat.id })}
              className={`flex-1 py-1.5 px-2 rounded-xl font-bold transition whitespace-nowrap text-center ${
                filters?.category === cat.id
                  ? 'bg-campus-forest text-white shadow-sm'
                  : 'text-gray-600 hover:text-campus-forest'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

      </div>

      {/* College & District Filter Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-gray-100 text-xs">
        
        {/* Tamil Nadu College Selector */}
        <div>
          <label className="block text-[11px] font-bold text-gray-500 mb-1 flex items-center gap-1">
            <GraduationCap className="w-3.5 h-3.5 text-campus-emerald" />
            <span>Select Tamil Nadu College</span>
          </label>
          <select
            value={filters?.college_name || ''}
            onChange={(e) => setFilters && setFilters({ ...filters, college_name: e.target.value, zone_id: '' })}
            className="w-full p-2 bg-campus-sand/20 border border-campus-border/70 rounded-xl text-xs text-campus-charcoal focus:outline-none focus:ring-2 focus:ring-campus-emerald/40 font-medium"
          >
            <option value="">🎓 All Tamil Nadu Colleges ({colleges.length})</option>
            {colleges.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        {/* City / District Selector */}
        <div>
          <label className="block text-[11px] font-bold text-gray-500 mb-1 flex items-center gap-1">
            <Building2 className="w-3 h-3 text-campus-emerald" />
            <span>TN City / District</span>
          </label>
          <select
            value={filters?.city || ''}
            onChange={(e) => setFilters && setFilters({ ...filters, city: e.target.value, college_name: '', zone_id: '' })}
            className="w-full p-2 bg-white border border-campus-border/70 rounded-xl text-xs text-campus-charcoal focus:outline-none focus:ring-2 focus:ring-campus-emerald/40"
          >
            <option value="">All Cities ({cities.length})</option>
            {cities.map((city) => (
              <option key={city} value={city}>{city}</option>
            ))}
          </select>
        </div>

        {/* Campus Pickup Zone */}
        <div>
          <label className="block text-[11px] font-bold text-gray-500 mb-1 flex items-center gap-1">
            <MapPin className="w-3 h-3 text-campus-emerald" />
            <span>Campus Pickup Hub</span>
          </label>
          <select
            value={filters?.zone_id || ''}
            onChange={(e) => setFilters && setFilters({ ...filters, zone_id: e.target.value })}
            className="w-full p-2 bg-white border border-campus-border/70 rounded-xl text-xs text-campus-charcoal focus:outline-none focus:ring-2 focus:ring-campus-emerald/40"
          >
            <option value="">All Campus Hubs ({filteredZones.length})</option>
            {filteredZones.map((z) => (
              <option key={z.id} value={z.id}>
                {z.name} ({z.city})
              </option>
            ))}
          </select>
        </div>

        {/* Availability Status */}
        <div>
          <label className="block text-[11px] font-bold text-gray-500 mb-1 flex items-center gap-1">
            <Filter className="w-3 h-3 text-campus-emerald" />
            <span>Availability Status</span>
          </label>
          <select
            value={filters?.status || 'AVAILABLE'}
            onChange={(e) => setFilters && setFilters({ ...filters, status: e.target.value })}
            className="w-full p-2 bg-white border border-campus-border/70 rounded-xl text-xs text-campus-charcoal focus:outline-none focus:ring-2 focus:ring-campus-emerald/40"
          >
            <option value="AVAILABLE">Available Now (Ready to Ride)</option>
            <option value="ALL">All Statuses (Including In-Use)</option>
            <option value="RESERVED">Reserved</option>
            <option value="IN_USE">In Use</option>
          </select>
        </div>

      </div>

    </div>
  );
}
