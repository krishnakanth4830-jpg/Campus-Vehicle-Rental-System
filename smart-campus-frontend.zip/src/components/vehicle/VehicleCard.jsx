import React from 'react';
import { Fuel, ShieldCheck, MapPin, Star, QrCode, ArrowRight } from 'lucide-react';
import { VehicleVisual } from '../common/VehicleVisual';

export function VehicleCard({ vehicle, onSelectBooking, onViewQR }) {
  const isAvailable = vehicle.status === 'AVAILABLE';
  const fuelPct = vehicle.fuel_level_percentage || 90;
  const engineCc = vehicle.engine_cc || 125;
  const mileage = vehicle.mileage_kmpl || 45;

  return (
    <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col group">
      
      {/* Clean Vector Vehicle Visual & Floating Badges */}
      <div className="relative overflow-hidden">
        <VehicleVisual vehicle={vehicle} size="card" showBadge={false} />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 z-10">
          {/* Petrol / EV Engine Badge */}
          <span className="px-2.5 py-1 rounded-full text-[11px] font-extrabold bg-campus-forest/90 backdrop-blur-md text-campus-mint border border-campus-mint/40 shadow-sm flex items-center gap-1">
            <Fuel className="w-3.5 h-3.5 text-campus-gold" />
            <span>{vehicle.is_electric ? '⚡ Pure Electric' : `⛽ ${engineCc}cc Petrol`}</span>
          </span>

          {/* Status Badge */}
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold tracking-wider uppercase backdrop-blur-md shadow-sm ${
            isAvailable ? 'bg-emerald-600 text-white' :
            vehicle.status === 'RESERVED' ? 'bg-amber-500 text-white' :
            vehicle.status === 'IN_USE' ? 'bg-sky-600 text-white' :
            'bg-rose-600 text-white'
          }`}>
            {vehicle.status}
          </span>
        </div>

        {/* QR Code Quick View Button */}
        <button
          onClick={() => onViewQR(vehicle)}
          className="absolute top-3 right-3 p-2 rounded-2xl bg-white/90 hover:bg-white text-campus-forest shadow-md border border-gray-200 transition z-10"
          title="Inspect Vehicle QR Code"
        >
          <QrCode className="w-4 h-4" />
        </button>

        {/* TN License Number Floating Pill */}
        <div className="absolute bottom-3 left-3 px-2.5 py-1 rounded-xl bg-black/75 backdrop-blur-sm text-white text-[11px] font-mono font-bold flex items-center gap-1 border border-white/20 z-10">
          <span className="text-[9px] bg-blue-600 text-white font-black px-1 rounded mr-1">IND</span>
          <span>{vehicle.vehicle_number}</span>
        </div>

        {/* Health Score Pill */}
        <div className="absolute bottom-3 right-3 px-2.5 py-1 rounded-xl bg-black/75 backdrop-blur-sm text-white text-[11px] font-bold flex items-center gap-1 border border-white/20 z-10">
          <ShieldCheck className="w-3.5 h-3.5 text-campus-mint" />
          <span>Health {vehicle.health_score || 95}/100</span>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Category & Rating */}
          <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
            <span className="font-bold uppercase tracking-wider text-[10px] text-campus-emerald">
              {vehicle.type_name}
            </span>
            <span className="flex items-center gap-1 font-bold text-amber-500">
              <Star className="w-3.5 h-3.5 fill-amber-400" />
              <span>{vehicle.average_rating || 4.9}</span>
            </span>
          </div>

          {/* Title */}
          <h3 className="font-extrabold text-base text-campus-forest font-display tracking-tight group-hover:text-campus-emerald transition">
            {vehicle.brand} {vehicle.model}
          </h3>

          {/* Vehicle Number & Owner Name Badge */}
          <div className="mt-2.5 p-2.5 bg-slate-50 rounded-xl border border-slate-200/80 flex flex-col gap-1 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-gray-500 font-medium">Vehicle Number:</span>
              <span className="font-mono font-bold text-campus-forest bg-white px-2 py-0.5 rounded border border-gray-200 shadow-xs">{vehicle.vehicle_number}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-500 font-medium">Owner Name:</span>
              <span className="font-semibold text-gray-800">{vehicle.owner_name || vehicle.owner?.name || 'Campus Host'}</span>
            </div>
          </div>

          {/* Zone Location */}
          <div className="mt-2.5 flex items-center gap-1.5 text-xs text-gray-600 bg-campus-sand/40 p-2 rounded-xl border border-campus-border/40">
            <MapPin className="w-3.5 h-3.5 text-campus-emerald flex-shrink-0" />
            <span className="truncate font-medium">
              {vehicle.current_zone ? vehicle.current_zone.name : 'Campus Hub'}
            </span>
          </div>

          {/* Petrol Tank Gauge & Mileage */}
          <div className="mt-3 space-y-1">
            <div className="flex justify-between text-[11px] font-semibold text-gray-600">
              <span className="flex items-center gap-1">
                <Fuel className="w-3 h-3 text-campus-forest" />
                <span>Fuel Tank {fuelPct}%</span>
              </span>
              <span className="text-campus-emerald font-bold">{mileage} km/l Mileage</span>
            </div>
            <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all ${
                  fuelPct > 50 ? 'bg-campus-emerald' :
                  fuelPct > 25 ? 'bg-amber-400' : 'bg-red-500'
                }`}
                style={{ width: `${fuelPct}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Pricing & Booking CTA */}
        <div className="mt-5 pt-3 border-t border-gray-100 flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase font-bold text-gray-400">Campus Tariff</div>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-extrabold text-campus-forest">₹{vehicle.hourly_rate}</span>
              <span className="text-xs text-gray-500 font-medium">/ hour</span>
            </div>
          </div>

          {isAvailable ? (
            <button
              onClick={() => onSelectBooking(vehicle)}
              className="px-4 py-2 rounded-2xl bg-gradient-to-r from-campus-forest to-campus-emerald text-white text-xs font-bold shadow-md hover:shadow-lg hover:from-campus-emerald hover:to-campus-forest transition-all flex items-center gap-1.5 group-hover:translate-x-0.5"
            >
              <span>Book Ride</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              disabled
              className="px-3.5 py-2 rounded-2xl bg-gray-100 text-gray-400 text-xs font-semibold cursor-not-allowed"
            >
              Unavailable
            </button>
          )}
        </div>

      </div>

    </div>
  );
}
