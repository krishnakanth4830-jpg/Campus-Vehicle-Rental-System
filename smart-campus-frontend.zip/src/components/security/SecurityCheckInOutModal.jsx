import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { 
  ShieldCheck, 
  Gauge, 
  BatteryCharging, 
  Camera, 
  CheckSquare, 
  AlertTriangle, 
  HardHat, 
  CheckCircle2, 
  X, 
  FileText,
  MapPin
} from 'lucide-react';
import { securityApi, zoneApi } from '../../api/services';

export default function SecurityCheckInOutModal({
  isOpen,
  onClose,
  mode = 'checkin', // 'checkin' or 'checkout'
  booking,
  onSuccess
}) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [zones, setZones] = useState([]);

  const isCheckin = mode === 'checkin';

  useEffect(() => {
    if (isOpen) {
      const handleKeyDown = (e) => {
        if (e.key === 'Escape') onClose();
      };
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = 'auto';
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [isOpen, onClose]);

  const [formData, setFormData] = useState({
    odometer: '',
    fuel_battery: '',
    notes: '',
    helmet_toggle: true,
    safety_checklist_agreed: true,
    damage_detected: false,
    damage_surcharge: 0,
    penalty_reason: '',
    return_zone_id: '',
    photos: [
      'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?w=500&auto=format&fit=crop&q=60'
    ]
  });

  useEffect(() => {
    if (isOpen && booking) {
      if (isCheckin) {
        setFormData({
          odometer: booking.vehicle?.current_kilometers || 120.0,
          fuel_battery: booking.vehicle?.battery_level || 90.0,
          notes: 'Pre-ride inspection verified: Brakes, tires, and lights in standard operating condition.',
          helmet_toggle: true,
          safety_checklist_agreed: true,
          damage_detected: false,
          damage_surcharge: 0,
          penalty_reason: '',
          return_zone_id: booking.return_zone_id || booking.pickup_zone_id || 1,
          photos: [
            'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?w=500&auto=format&fit=crop&q=60'
          ]
        });
      } else {
        const startOdo = parseFloat(booking.checkin_odometer || booking.vehicle?.current_kilometers || 120.0);
        setFormData({
          odometer: (startOdo + 4.2).toFixed(1),
          fuel_battery: 80.0,
          notes: 'Vehicle returned to hub. All controls intact and helmet safely deposited in locker.',
          helmet_toggle: true,
          safety_checklist_agreed: true,
          damage_detected: false,
          damage_surcharge: 0,
          penalty_reason: '',
          return_zone_id: booking.return_zone_id || booking.pickup_zone_id || 1,
          photos: [
            'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?w=500&auto=format&fit=crop&q=60'
          ]
        });
      }
      loadZones();
    }
  }, [isOpen, mode, booking]);

  const loadZones = async () => {
    try {
      const res = await zoneApi.getAllZones();
      if (res.data?.zones) {
        setZones(res.data.zones);
      }
    } catch (err) {
      console.error('Error loading zones:', err);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!booking) return;

    try {
      setLoading(true);
      setError(null);

      let res;
      if (isCheckin) {
        res = await securityApi.checkin({
          booking_id: booking.id,
          odometer_start: parseFloat(formData.odometer) || 0.0,
          fuel_battery_start: parseFloat(formData.fuel_battery) || 100.0,
          condition_notes: formData.notes,
          inspection_photos: formData.photos,
          helmet_issued: formData.helmet_toggle,
          safety_checklist_agreed: formData.safety_checklist_agreed
        });
      } else {
        res = await securityApi.checkout({
          booking_id: booking.id,
          odometer_end: parseFloat(formData.odometer) || 0.0,
          fuel_battery_end: parseFloat(formData.fuel_battery) || 80.0,
          return_condition_notes: formData.notes,
          return_photos: formData.photos,
          damage_detected: formData.damage_detected,
          damage_surcharge: parseFloat(formData.damage_surcharge) || 0.0,
          penalty_reason: formData.penalty_reason,
          helmet_returned: formData.helmet_toggle,
          return_zone_id: formData.return_zone_id
        });
      }

      if (res.data?.success) {
        if (onSuccess) onSuccess(res.data.booking);
        onClose();
      } else {
        setError(res.data?.message || 'Check-in/out submission failed');
      }
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Error updating rental security inspection');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !booking) return null;

  const modalContent = (
    <div 
      className="fixed inset-0 z-[9999] flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                {isCheckin ? 'Pre-Ride Security Check-In' : 'Post-Ride Return Inspection'}
              </h3>
              <p className="text-xs text-slate-400">
                Rental: {booking.booking_code} • {booking.vehicle?.brand} {booking.vehicle?.model}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-500 text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Odometer & Fuel Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <Gauge className="w-4 h-4 text-blue-600" />
                  {isCheckin ? 'Start Odometer (km)' : 'Return Odometer (km)'}
                </label>
                <input
                  type="number"
                  step="0.1"
                  name="odometer"
                  value={formData.odometer}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white font-mono focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <BatteryCharging className="w-4 h-4 text-emerald-600" />
                  {isCheckin ? 'Fuel / Battery Start (%)' : 'Fuel / Battery Return (%)'}
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  name="fuel_battery"
                  value={formData.fuel_battery}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white font-mono focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Return Zone (Checkout only) */}
            {!isCheckin && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-blue-600" /> Return Campus Zone / Hub
                </label>
                <select
                  name="return_zone_id"
                  value={formData.return_zone_id}
                  onChange={handleChange}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {zones.map((z) => (
                    <option key={z.id} value={z.id}>
                      {z.name} ({z.college_name || z.city})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Helmet & Safety Mandatory Checks */}
            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2.5">
              <label className="flex items-center justify-between cursor-pointer">
                <span className="text-xs font-medium text-slate-800 dark:text-slate-200 flex items-center gap-2">
                  <HardHat className="w-4 h-4 text-amber-500" />
                  {isCheckin ? 'ISI Safety Helmet Issued & Verified' : 'ISI Safety Helmet Returned in Locker'}
                </span>
                <input
                  type="checkbox"
                  name="helmet_toggle"
                  checked={formData.helmet_toggle}
                  onChange={handleChange}
                  className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                <span className="text-xs font-medium text-slate-800 dark:text-slate-200 flex items-center gap-2">
                  <CheckSquare className="w-4 h-4 text-blue-500" />
                  {isCheckin ? 'Brakes, Mirrors & Headlight Check Passed' : 'Zero Undisclosed Structural Damage'}
                </span>
                <input
                  type="checkbox"
                  name="safety_checklist_agreed"
                  checked={formData.safety_checklist_agreed}
                  onChange={handleChange}
                  className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
              </label>
            </div>

            {/* Damage & Surcharges (Checkout only) */}
            {!isCheckin && (
              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-xl border border-amber-200 dark:border-amber-800/50 space-y-2">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-semibold text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600" /> Flag New Scratches or Mechanical Damage
                  </span>
                  <input
                    type="checkbox"
                    name="damage_detected"
                    checked={formData.damage_detected}
                    onChange={handleChange}
                    className="w-4 h-4 rounded border-amber-300 text-amber-600 focus:ring-amber-500"
                  />
                </label>

                {formData.damage_detected && (
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-amber-200 dark:border-amber-800/50">
                    <div>
                      <label className="block text-[11px] font-medium text-amber-800 dark:text-amber-300 mb-1">
                        Damage Surcharge (₹)
                      </label>
                      <input
                        type="number"
                        name="damage_surcharge"
                        value={formData.damage_surcharge}
                        onChange={handleChange}
                        className="w-full px-2 py-1 text-xs bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-amber-800 dark:text-amber-300 mb-1">
                        Reason / Notes
                      </label>
                      <input
                        type="text"
                        name="penalty_reason"
                        value={formData.penalty_reason}
                        onChange={handleChange}
                        placeholder="e.g. Scratched mirror"
                        className="w-full px-2 py-1 text-xs bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Inspection Notes */}
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Inspection Notes & Physical Assessment
              </label>
              <textarea
                name="notes"
                rows={2}
                value={formData.notes}
                onChange={handleChange}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            {/* Actions */}
            <div className="pt-3 flex items-center justify-end space-x-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-xl shadow-md shadow-blue-500/20 disabled:opacity-50 flex items-center gap-2 transition"
              >
                {loading ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>{isCheckin ? 'Complete Pre-Ride Check-In' : 'Authorize Return Check-Out'}</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalContent, document.body) : null;
}
