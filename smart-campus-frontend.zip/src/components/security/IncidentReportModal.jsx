import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { 
  AlertTriangle, 
  ShieldAlert, 
  Camera, 
  MapPin, 
  FileText, 
  PhoneCall, 
  CheckCircle2, 
  X,
  Flame,
  Wrench
} from 'lucide-react';
import { securityApi } from '../../api/services';

export default function IncidentReportModal({
  isOpen,
  onClose,
  vehicleId,
  bookingId,
  onSuccess
}) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successCode, setSuccessCode] = useState(null);

  useEffect(() => {
    if (isOpen) {
      const handleKeyDown = (e) => {
        if (e.key === 'Escape') onClose();
      };
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = 'auto';
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [isOpen, onClose]);

  const [formData, setFormData] = useState({
    vehicle_id: vehicleId || '',
    booking_id: bookingId || '',
    incident_type: 'SCRATCH_DENT',
    title: 'Minor Scratch on Front Fairing',
    description: 'Encountered loose gravel near Library parking bay resulting in light surface scrape.',
    severity: 'LOW',
    location: 'Central Library Parking Bay #4',
    third_party_involved: false,
    police_notified: false,
    photos: [
      'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?w=500&auto=format&fit=crop&q=60'
    ]
  });

  const incidentTypes = [
    { value: 'SCRATCH_DENT', label: 'Scratch / Cosmetic Dent' },
    { value: 'ACCIDENT', label: 'Collision / Road Accident' },
    { value: 'BREAKDOWN', label: 'Engine / Mechanical Breakdown' },
    { value: 'PUNCTURE', label: 'Tire Puncture / Flat' },
    { value: 'HELMET_LOST', label: 'Lost / Damaged Helmet' },
    { value: 'THEFT_ATTEMPT', label: 'Vandalism / Theft Attempt' },
    { value: 'OTHER', label: 'Other Safety Hazard' }
  ];

  const severities = [
    { value: 'LOW', label: 'Low (Minor cosmetic)', color: 'text-blue-500 border-blue-500/30 bg-blue-500/10' },
    { value: 'MEDIUM', label: 'Medium (Requires repair)', color: 'text-amber-500 border-amber-500/30 bg-amber-500/10' },
    { value: 'HIGH', label: 'High (Immediate servicing needed)', color: 'text-orange-500 border-orange-500/30 bg-orange-500/10' },
    { value: 'CRITICAL', label: 'Critical (Safety Hazard / Accident)', color: 'text-rose-500 border-rose-500/30 bg-rose-500/10' }
  ];

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.vehicle_id) {
      setError('Please provide a valid vehicle ID');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await securityApi.createIncident({
        ...formData,
        vehicle_id: parseInt(formData.vehicle_id),
        booking_id: formData.booking_id ? parseInt(formData.booking_id) : null
      });

      if (res.data?.success) {
        setSuccessCode(res.data.incident?.incident_code || 'INC-2026-PROCESSED');
        if (onSuccess) onSuccess(res.data.incident);
        setTimeout(() => {
          onClose();
          setSuccessCode(null);
        }, 1800);
      } else {
        setError(res.data?.message || 'Failed to submit incident report');
      }
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Error filing incident report');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const modalContent = (
    <div 
      className="fixed inset-0 z-[9999] flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-rose-950/80 text-white px-6 py-4 flex items-center justify-between border-b border-rose-900/60">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Campus Incident & Damage Report
              </h3>
              <p className="text-xs text-rose-200/80">
                Official Campus Security & Fleet Maintenance Incident Logging
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-500 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successCode && (
            <div className="mb-4 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 text-sm flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 flex-shrink-0" />
              <div>
                <p className="font-bold">Incident Logged: {successCode}</p>
                <p className="text-xs text-emerald-600 dark:text-emerald-400">
                  Campus Security Desk and Maintenance have been dispatched.
                </p>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Incident Category
                </label>
                <select
                  name="incident_type"
                  value={formData.incident_type}
                  onChange={handleChange}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-rose-500 outline-none"
                >
                  {incidentTypes.map((t) => (
                    <option key={t.value} value={t.value}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Severity Level
                </label>
                <select
                  name="severity"
                  value={formData.severity}
                  onChange={handleChange}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-rose-500 outline-none"
                >
                  {severities.map((s) => (
                    <option key={s.value} value={s.value}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Incident Title / Summary
              </label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-rose-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-rose-500" /> Incident Location
              </label>
              <input
                type="text"
                name="location"
                value={formData.location}
                onChange={handleChange}
                required
                placeholder="e.g. Mechanical Lab Road, Campus West"
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-rose-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Detailed Incident Description
              </label>
              <textarea
                name="description"
                rows={3}
                value={formData.description}
                onChange={handleChange}
                required
                placeholder="Please describe exactly what happened, any road conditions, third parties involved, etc."
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-rose-500 outline-none"
              />
            </div>

            {/* Emergency & Third party toggles */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
              <label className="flex items-center justify-between cursor-pointer">
                <span className="text-xs text-slate-800 dark:text-slate-200">
                  Third party vehicle / pedestrian involved
                </span>
                <input
                  type="checkbox"
                  name="third_party_involved"
                  checked={formData.third_party_involved}
                  onChange={handleChange}
                  className="w-4 h-4 rounded border-slate-300 text-rose-600 focus:ring-rose-500"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                <span className="text-xs text-slate-800 dark:text-slate-200">
                  Campus Patrol / Police Station Notified
                </span>
                <input
                  type="checkbox"
                  name="police_notified"
                  checked={formData.police_notified}
                  onChange={handleChange}
                  className="w-4 h-4 rounded border-slate-300 text-rose-600 focus:ring-rose-500"
                />
              </label>
            </div>

            {/* Actions */}
            <div className="pt-3 flex items-center justify-end space-x-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-5 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 active:bg-rose-700 rounded-xl shadow-md shadow-rose-500/20 disabled:opacity-50 flex items-center gap-2 transition"
              >
                {loading ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Transmitting...</span>
                  </>
                ) : (
                  <>
                    <ShieldAlert className="w-4 h-4" />
                    <span>Submit Official Security Report</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalContent, document.body) : null;
}
