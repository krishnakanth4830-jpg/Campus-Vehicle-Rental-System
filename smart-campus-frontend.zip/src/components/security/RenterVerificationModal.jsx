import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { 
  ShieldCheck, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Upload, 
  FileText, 
  CreditCard, 
  Phone, 
  User, 
  Calendar, 
  MapPin, 
  Lock, 
  Check, 
  X,
  Sparkles
} from 'lucide-react';
import { securityApi } from '../../api/services';
import { useAuth } from '../../context/AuthContext';

export default function RenterVerificationModal({ isOpen, onClose, onSuccess }) {
  const { user, updateUser, refreshUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [fetchingStatus, setFetchingStatus] = useState(true);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState('');
  const [currentVerification, setCurrentVerification] = useState(null);

  const [formData, setFormData] = useState({
    full_name: user?.name || 'Karthik Subramanian',
    student_id: user?.student_id || '21CS108',
    college_email: user?.email || 'student@campus.edu',
    mobile_number: user?.phone || '+91 98765 43210',
    department: user?.department || 'Computer Science & Engineering',
    year_semester: '3rd Year / Sem 5',
    dob: '2003-05-18',
    current_address: 'Campus Hostel Block B, Room 304',
    emergency_contact_name: 'Dr. Subramanian (Guardian)',
    emergency_contact_phone: '+91 98765 43210',
    emergency_relation: 'Parent / Guardian',
    driving_licence_number: 'TN-38-20230009412',
    licence_expiry_date: '2034-12-31',
    licence_photo_url: '',
    id_card_photo_url: '',
    profile_photo_url: '',
    aadhaar_last_four: '4589',
    has_declared_truth: true,
  });

  useEffect(() => {
    if (isOpen) {
      loadStatus();
      const handleKeyDown = (e) => {
        if (e.key === 'Escape') onClose();
      };
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = 'auto';
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [isOpen, onClose]);

  const loadStatus = async () => {
    try {
      setFetchingStatus(true);
      setError(null);
      const res = await securityApi.getRenterStatus();
      const data = res.data || res;
      if (data?.success && data.verification) {
        const v = data.verification;
        setCurrentVerification(v);
        setFormData((prev) => ({
          ...prev,
          full_name: v.full_name || prev.full_name || user?.name || '',
          student_id: v.student_id || v.student_id_number || prev.student_id || user?.student_id || '',
          college_email: v.college_email || prev.college_email || user?.email || '',
          mobile_number: (v.mobile_number && !v.mobile_number.includes('*')) ? v.mobile_number : (prev.mobile_number || user?.phone || ''),
          department: v.department || prev.department || user?.department || '',
          year_semester: v.year_semester || v.year_of_study || prev.year_semester || '',
          emergency_contact_name: v.emergency_contact_name || prev.emergency_contact_name || '',
          emergency_contact_phone: (v.emergency_contact_phone && !v.emergency_contact_phone.includes('*')) ? v.emergency_contact_phone : (prev.emergency_contact_phone || ''),
          emergency_relation: v.emergency_relation || prev.emergency_relation || '',
          driving_licence_number: (v.driving_licence_number && !v.driving_licence_number.includes('*')) ? v.driving_licence_number : (prev.driving_licence_number || ''),
          licence_expiry_date: v.licence_expiry_date || prev.licence_expiry_date || '',
          aadhaar_last_four: v.aadhaar_last_four || prev.aadhaar_last_four || '4589',
        }));
      }
    } catch (err) {
      console.error('Error fetching KYC status:', err);
    } finally {
      setFetchingStatus(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleFillDemo = () => {
    setFormData({
      full_name: user?.name || 'Karthik Subramanian',
      student_id: user?.student_id || '21CS108',
      college_email: user?.email || 'student@campus.edu',
      mobile_number: user?.phone || '+91 98765 43210',
      department: user?.department || 'Computer Science & Engineering',
      year_semester: '3rd Year / Sem 5',
      dob: '2003-05-18',
      current_address: 'Campus Hostel Block B, Room 304, Coimbatore',
      emergency_contact_name: 'Dr. Subramanian (Guardian)',
      emergency_contact_phone: '+91 98765 43210',
      emergency_relation: 'Parent / Guardian',
      driving_licence_number: 'TN-38-20230009412',
      licence_expiry_date: '2034-12-31',
      licence_photo_url: '',
      id_card_photo_url: '',
      profile_photo_url: '',
      aadhaar_last_four: '4589',
      has_declared_truth: true,
    });
    setError(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.has_declared_truth) {
      setError('Please declare that the submitted identity proofs are authentic.');
      return;
    }
    if (!formData.student_id || !formData.driving_licence_number) {
      setError('Student ID and Driving Licence Number are mandatory.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await securityApi.submitRenterVerification({
        ...formData,
        auto_verify: true,
      });

      const data = res.data || res;
      if (data?.success) {
        setSuccessMsg('KYC verification submitted and verified successfully!');
        if (updateUser) {
          updateUser({ is_verified: true, verification_status: 'VERIFIED' });
        }
        if (refreshUser) {
          refreshUser();
        }
        setTimeout(() => {
          if (onSuccess) onSuccess(data.verification);
          onClose();
        }, 1000);
      } else {
        setError(data?.message || 'Verification submission failed.');
      }
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Error submitting KYC verification.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const isAlreadyVerified = currentVerification?.status === 'VERIFIED' || user?.is_verified;

  const modalContent = (
    <div 
      className="fixed inset-0 z-[9999] flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Mandatory Renter KYC Verification
                {isAlreadyVerified && (
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    <CheckCircle2 className="w-3 h-3 mr-1" /> VERIFIED
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400">
                Official Campus Vehicle Security & Student Identity Authentication
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-500 text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 text-sm flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {isAlreadyVerified && !successMsg && (
            <div className="mb-6 p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 flex items-start space-x-3">
              <ShieldCheck className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="text-sm font-semibold text-blue-900 dark:text-blue-200">
                  Your Account is Fully KYC Verified ✓
                </h4>
                <p className="text-xs text-blue-700 dark:text-blue-300 mt-0.5">
                  You are authorized to rent and unlock all campus scooters, bikes, and cars. You can update your emergency contact or licence details below anytime.
                </p>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Section 1: Student Identity */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-blue-600" /> Student Profile & College Affiliation
                </h4>
                <button
                  type="button"
                  onClick={handleFillDemo}
                  className="text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:text-blue-700 bg-blue-50 dark:bg-blue-950/60 px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800 transition flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3 text-blue-500" />
                  <span>Auto-Fill Demo KYC</span>
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Full Legal Name
                  </label>
                  <input
                    type="text"
                    name="full_name"
                    value={formData.full_name}
                    onChange={handleChange}
                    required
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Student ID / College Roll No.
                  </label>
                  <input
                    type="text"
                    name="student_id"
                    value={formData.student_id}
                    onChange={handleChange}
                    required
                    placeholder="e.g. CS2023-8819"
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    College Email Address
                  </label>
                  <input
                    type="email"
                    name="college_email"
                    value={formData.college_email}
                    onChange={handleChange}
                    required
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Mobile Phone Number
                  </label>
                  <input
                    type="tel"
                    name="mobile_number"
                    value={formData.mobile_number}
                    onChange={handleChange}
                    required
                    placeholder="+91 98765 43210"
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Department / Branch
                  </label>
                  <input
                    type="text"
                    name="department"
                    value={formData.department}
                    onChange={handleChange}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Year / Semester
                  </label>
                  <input
                    type="text"
                    name="year_semester"
                    value={formData.year_semester}
                    onChange={handleChange}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Section 2: Licence & Driving Credential */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-blue-600" /> Driving Licence & Government KYC
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Driving Licence Number
                  </label>
                  <input
                    type="text"
                    name="driving_licence_number"
                    value={formData.driving_licence_number}
                    onChange={handleChange}
                    required
                    placeholder="e.g. TN-38-20230009412"
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Licence Expiry Date
                  </label>
                  <input
                    type="date"
                    name="licence_expiry_date"
                    value={formData.licence_expiry_date}
                    onChange={handleChange}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Aadhaar / National ID (Last 4 Digits)
                  </label>
                  <input
                    type="text"
                    name="aadhaar_last_four"
                    maxLength={4}
                    value={formData.aadhaar_last_four}
                    onChange={handleChange}
                    placeholder="4589"
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Campus / Hostel Address
                  </label>
                  <input
                    type="text"
                    name="current_address"
                    value={formData.current_address}
                    onChange={handleChange}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Section 3: Emergency Contact */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-blue-600" /> Emergency Contact (Campus Safety SOS)
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Contact Name
                  </label>
                  <input
                    type="text"
                    name="emergency_contact_name"
                    value={formData.emergency_contact_name}
                    onChange={handleChange}
                    required
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Emergency Phone
                  </label>
                  <input
                    type="tel"
                    name="emergency_contact_phone"
                    value={formData.emergency_contact_phone}
                    onChange={handleChange}
                    required
                    placeholder="+91 98765 00000"
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Relation
                  </label>
                  <input
                    type="text"
                    name="emergency_relation"
                    value={formData.emergency_relation}
                    onChange={handleChange}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Declaration */}
            <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
              <label className="flex items-start space-x-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  name="has_declared_truth"
                  checked={formData.has_declared_truth}
                  onChange={handleChange}
                  className="mt-0.5 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-xs text-slate-600 dark:text-slate-400">
                  I hereby declare that all details and documents provided are authentic and valid. I agree to comply with campus speed limits, traffic safety rules, and helmet mandates.
                </span>
              </label>
            </div>

            {/* Actions */}
            <div className="pt-4 flex items-center justify-end space-x-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
              >
                Close
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-xl shadow-md shadow-blue-500/20 disabled:opacity-50 flex items-center gap-2 transition"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Verifying...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>{isAlreadyVerified ? 'Update & Re-Verify KYC' : 'Submit & Verify KYC'}</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalContent, document.body) : null;
}
