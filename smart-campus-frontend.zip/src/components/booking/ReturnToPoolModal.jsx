import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { apiRequest } from '../../api/client';
import { 
  X, CheckCircle2, AlertTriangle, Camera, Upload, 
  MapPin, Battery, Fuel, Leaf, ArrowRight, ShieldCheck 
} from 'lucide-react';

export function ReturnToPoolModal({ booking, zones, onClose, onSuccess }) {
  const [returnZoneId, setReturnZoneId] = useState(booking.return_zone_id || booking.pickup_zone_id || zones[0]?.id);
  const [returnToPool, setReturnToPool] = useState(true);
  const [batteryLevel, setBatteryLevel] = useState(booking.vehicle?.battery_percentage || 85);
  const [distanceKm, setDistanceKm] = useState(2.4);
  const [hasDamage, setHasDamage] = useState(false);
  const [damageDescription, setDamageDescription] = useState('');
  const [damageCategory, setDamageCategory] = useState('SCRATCH');
  const [userComments, setUserComments] = useState('Returned in great clean condition.');
  const [uploadedPhotos, setUploadedPhotos] = useState([]);
  
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError(null);

    const formData = new FormData();
    formData.append('photo', file);

    const res = await apiRequest('/condition/upload-photo', {
      method: 'POST',
      body: formData
    });

    setUploading(false);

    if (res.success && res.url) {
      setUploadedPhotos(prev => [...prev, res.url]);
    } else {
      setError(res.message || 'Photo upload failed.');
    }
  };

  const handleCompleteReturn = async () => {
    setSubmitting(true);
    setError(null);

    // 1. Submit Condition Report
    await apiRequest('/condition/', {
      method: 'POST',
      body: JSON.stringify({
        booking_id: booking.id,
        vehicle_id: booking.vehicle_id,
        report_type: 'AFTER_RENTAL',
        battery_level: Number(batteryLevel),
        photos: uploadedPhotos,
        user_comments: userComments,
        has_damage: hasDamage,
        damage_description: damageDescription,
        damage_category: hasDamage ? damageCategory : 'NONE'
      })
    });

    // 2. Complete Booking with Return-to-Pool
    const res = await apiRequest(`/bookings/${booking.id}/return`, {
      method: 'POST',
      body: JSON.stringify({
        return_zone_id: Number(returnZoneId),
        return_to_pool: returnToPool,
        distance_km: Number(distanceKm),
        battery_percentage: Number(batteryLevel)
      })
    });

    setSubmitting(false);

    if (res.success) {
      onSuccess(res);
    } else {
      setError(res.message || 'Failed to complete return.');
    }
  };

  const modalContent = (
    <div 
      className="fixed inset-0 z-[9999] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="bg-white rounded-3xl max-w-lg w-full border border-campus-border/80 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200 my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="bg-campus-forest text-white p-5 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-campus-mint">
              END RENTAL & RETURN-TO-POOL
            </span>
            <h2 className="text-base font-extrabold font-display">
              {booking.vehicle_model} ({booking.vehicle_number})
            </h2>
          </div>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-white/10 text-gray-300 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto text-xs">
          
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2 text-rose-700">
              <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Special Feature: Return-to-Pool Box */}
          <div className="p-4 bg-gradient-to-r from-campus-sand/60 to-campus-cream rounded-2xl border-2 border-campus-emerald/40 space-y-2">
            <div className="flex items-center gap-2 font-bold text-campus-forest text-xs">
              <Leaf className="w-4 h-4 text-campus-emerald" />
              <span>Smart Return-to-Pool Verification</span>
            </div>
            <p className="text-gray-600 text-[11px] leading-relaxed">
              Would you like to make this vehicle immediately available for the next campus student/staff at your return zone?
            </p>
            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={() => setReturnToPool(true)}
                className={`flex-1 py-2 px-3 rounded-xl font-bold border transition flex items-center justify-center gap-1.5 ${
                  returnToPool
                    ? 'bg-campus-forest text-white border-campus-forest shadow-sm'
                    : 'bg-white text-gray-700 border-gray-300'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-campus-mint" />
                <span>Yes, Return to Pool (+20 Eco Pts)</span>
              </button>
              <button
                type="button"
                onClick={() => setReturnToPool(false)}
                className={`py-2 px-3 rounded-xl font-semibold border transition ${
                  !returnToPool
                    ? 'bg-amber-100 text-amber-900 border-amber-400 font-bold'
                    : 'bg-white text-gray-600 border-gray-300'
                }`}
              >
                Flag for Service
              </button>
            </div>
          </div>

          {/* Return Zone Selection */}
          <div>
            <label className="block font-bold text-gray-700 mb-1 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-campus-emerald" />
              <span>Current Return Zone</span>
            </label>
            <select
              value={returnZoneId}
              onChange={(e) => setReturnZoneId(e.target.value)}
              className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-campus-emerald/40"
            >
              {zones.map((z) => (
                <option key={z.id} value={z.id}>{z.name}</option>
              ))}
            </select>
          </div>

          {/* Trip Distance & Battery Remaining */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-gray-700 mb-1">Trip Distance (km)</label>
              <input
                type="number"
                step="0.1"
                min="0.5"
                max="25"
                value={distanceKm}
                onChange={(e) => setDistanceKm(e.target.value)}
                className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl font-mono focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1 flex items-center gap-1">
                <Fuel className="w-3.5 h-3.5 text-campus-emerald" />
                <span>Return Petrol Level (%)</span>
              </label>
              <input
                type="number"
                min="10"
                max="100"
                value={batteryLevel}
                onChange={(e) => setBatteryLevel(e.target.value)}
                className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl font-mono focus:outline-none"
              />
            </div>
          </div>

          {/* Vehicle Condition Photos Upload */}
          <div className="space-y-2">
            <label className="block font-bold text-gray-700 flex items-center justify-between">
              <span>Vehicle Condition Photo Upload</span>
              <span className="text-[10px] text-gray-400 font-normal">Assistance Verification</span>
            </label>
            
            <div className="flex items-center gap-2">
              <label className="flex-1 border-2 border-dashed border-campus-border/80 hover:border-campus-emerald p-3 rounded-2xl flex items-center justify-center gap-2 cursor-pointer bg-campus-sand/20 hover:bg-campus-sand/40 transition">
                <Camera className="w-4 h-4 text-campus-emerald" />
                <span className="font-semibold text-gray-600">{uploading ? 'Uploading...' : 'Take or Upload Photo'}</span>
                <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
              </label>
            </div>

            {uploadedPhotos.length > 0 && (
              <div className="flex gap-2 overflow-x-auto py-1">
                {uploadedPhotos.map((url, idx) => (
                  <img key={idx} src={url} alt="Condition" className="w-14 h-14 object-cover rounded-xl border border-campus-border/80 shadow-sm" />
                ))}
              </div>
            )}
          </div>

          {/* Issue & Damage Reporting Toggle */}
          <div className="p-3 bg-gray-50 border border-gray-200 rounded-2xl space-y-2">
            <label className="flex items-center gap-2 cursor-pointer font-bold text-gray-700">
              <input
                type="checkbox"
                checked={hasDamage}
                onChange={(e) => setHasDamage(e.target.checked)}
                className="w-4 h-4 rounded text-campus-emerald focus:ring-campus-emerald"
              />
              <span>Report vehicle issue or damage encountered during ride</span>
            </label>

            {hasDamage && (
              <div className="space-y-2 pt-2 border-t border-gray-200 animate-in fade-in">
                <div>
                  <label className="block font-bold text-gray-600 mb-1">Issue Category</label>
                  <select
                    value={damageCategory}
                    onChange={(e) => setDamageCategory(e.target.value)}
                    className="w-full p-2 bg-white border rounded-xl"
                  >
                    <option value="SCRATCH">Surface Scratch / Dent</option>
                    <option value="TIRE_PUNCTURE">Tire Puncture / Low Pressure</option>
                    <option value="BRAKE_ISSUE">Brake Slack / Loose Handle</option>
                    <option value="BATTERY_DRAIN">Rapid Battery Drain (EV)</option>
                    <option value="OTHER">Other Operational Issue</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-gray-600 mb-1">Issue Description</label>
                  <textarea
                    rows={2}
                    value={damageDescription}
                    onChange={(e) => setDamageDescription(e.target.value)}
                    placeholder="Describe the issue for campus maintenance team..."
                    className="w-full p-2 bg-white border rounded-xl"
                  />
                </div>
              </div>
            )}
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-5 bg-gray-50 border-t border-gray-100 flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-gray-600 hover:bg-gray-200 rounded-2xl transition"
          >
            Cancel
          </button>
          <button
            onClick={handleCompleteReturn}
            disabled={submitting}
            className="px-5 py-2.5 bg-gradient-to-r from-campus-forest to-campus-emerald text-white text-xs font-bold rounded-2xl shadow-lg hover:shadow-xl transition flex items-center gap-1.5 disabled:opacity-50"
          >
            <span>{submitting ? 'Completing...' : 'Complete Return & Claim Eco Score'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalContent, document.body) : null;
}
