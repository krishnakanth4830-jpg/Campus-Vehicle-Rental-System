import React from 'react';
import { Tag, Clock, Shield, Sparkles, AlertCircle } from 'lucide-react';

const PriceBreakdownCard = ({ quote, userRole = 'STUDENT' }) => {
  if (!quote) return null;

  return (
    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2.5 text-xs">
      <div className="flex items-center justify-between font-bold text-slate-800 pb-2 border-b border-slate-200">
        <span>Smart Pricing Calculation</span>
        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full uppercase">
          {userRole} Fare
        </span>
      </div>

      <div className="flex items-center justify-between text-slate-600">
        <span>Vehicle Unlock / Base Fee</span>
        <span className="font-semibold text-slate-800">₹{quote.base_price?.toFixed(2)}</span>
      </div>

      <div className="flex items-center justify-between text-slate-600">
        <span className="flex items-center gap-1">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          Duration Charge ({quote.duration_hours} hr @ ₹{quote.hourly_rate}/hr)
        </span>
        <span className="font-semibold text-slate-800">₹{quote.duration_charge?.toFixed(2)}</span>
      </div>

      {quote.role_discount_amount > 0 && (
        <div className="flex items-center justify-between text-emerald-700 font-semibold">
          <span className="flex items-center gap-1">
            <Tag className="w-3.5 h-3.5" />
            {userRole === 'STUDENT' ? 'Student Campus Discount' : 'Staff Discount'} ({quote.role_discount_pct}%)
          </span>
          <span>- ₹{quote.role_discount_amount?.toFixed(2)}</span>
        </div>
      )}

      {quote.is_offpeak && quote.offpeak_discount_amount > 0 && (
        <div className="flex items-center justify-between text-teal-700 font-semibold">
          <span className="flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" />
            Off-Peak Rush Discount ({quote.offpeak_discount_pct}%)
          </span>
          <span>- ₹{quote.offpeak_discount_amount?.toFixed(2)}</span>
        </div>
      )}

      <div className="flex items-center justify-between text-slate-500 pt-1 border-t border-slate-200">
        <span className="flex items-center gap-1">
          <Shield className="w-3.5 h-3.5 text-slate-400" />
          Refundable Security Deposit
        </span>
        <span className="font-medium text-slate-700">₹{quote.deposit_amount?.toFixed(2)}</span>
      </div>

      <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-sm font-black text-slate-900">
        <span>Estimated Total (Fare + Deposit)</span>
        <span className="text-base text-emerald-700">
          ₹{(quote.total_price + quote.deposit_amount).toFixed(2)}
        </span>
      </div>
      
      <p className="text-[10px] text-slate-400 leading-tight">
        * Deposit of ₹{quote.deposit_amount?.toFixed(2)} is auto-refunded to your Campus Wallet upon on-time return to any designated campus zone. Late returns are charged at ₹25/hr.
      </p>
    </div>
  );
};

export default PriceBreakdownCard;
