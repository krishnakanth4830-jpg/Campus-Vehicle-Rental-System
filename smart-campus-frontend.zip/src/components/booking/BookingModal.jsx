import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { useAuth } from '../../context/AuthContext';
import { useBooking } from '../../context/BookingContext';
import { apiRequest } from '../../api/client';
import { 
  X, Zap, Bike, Clock, MapPin, ShieldCheck, 
  CreditCard, CheckCircle2, AlertCircle, ArrowRight, Wallet 
} from 'lucide-react';
import RenterVerificationModal from '../security/RenterVerificationModal';
import { VehicleVisual } from '../common/VehicleVisual';

export function BookingModal({ vehicle, zones, onClose, onSuccess }) {
  const { user, isAuthenticated } = useAuth();
  const { fetchActiveBooking } = useBooking();

  const [pickupZoneId, setPickupZoneId] = useState(vehicle?.current_zone_id || zones[0]?.id || 1);
  const [returnZoneId, setReturnZoneId] = useState(vehicle?.current_zone_id || zones[0]?.id || 1);
  const [durationHours, setDurationHours] = useState(1.0);
  const [paymentMethod, setPaymentMethod] = useState('CAMPUS_WALLET');
  
  const [pricing, setPricing] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showKYCModal, setShowKYCModal] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  // Fetch live price calculation whenever duration or vehicle changes
  useEffect(() => {
    async function calculate() {
      if (!vehicle) return;
      const res = await apiRequest('/bookings/calculate-price', {
        method: 'POST',
        body: JSON.stringify({
          vehicle_id: vehicle.id,
          duration_hours: durationHours
        })
      });
      if (res.success && res.pricing) {
        setPricing(res.pricing);
      }
    }
    calculate();
  }, [vehicle, durationHours]);

  const handleConfirmBooking = async () => {
    if (!isAuthenticated) {
      setError('Please log in to confirm your booking.');
      return;
    }

    setLoading(true);
    setError(null);

    const res = await apiRequest('/bookings/', {
      method: 'POST',
      body: JSON.stringify({
        vehicle_id: vehicle.id,
        pickup_zone_id: Number(pickupZoneId),
        return_zone_id: Number(returnZoneId),
        duration_hours: Number(durationHours),
        payment_method: paymentMethod
      })
    });

    setLoading(false);

    if (res.success) {
      await fetchActiveBooking();
      onSuccess(res.booking);
    } else {
      if (res.verification_required) {
        setShowKYCModal(true);
      }
      setError(res.message || 'Booking could not be confirmed.');
    }
  };

  if (!vehicle) return null;

  const modalContent = (
    <div 
      className="fixed inset-0 z-[9999] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="bg-white rounded-3xl max-w-xl w-full border border-campus-border/80 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200 my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="bg-campus-forest text-white p-5 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-campus-mint">
              CAMPUS MOBILITY BOOKING
            </span>
            <h2 className="text-lg font-extrabold font-display">{vehicle.brand} {vehicle.model}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-gray-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          
          {/* Error Banner */}
          {error && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-xs text-rose-700">
              <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Clean Vector Vehicle Visual Highlights (No Photographs) */}
          <div className="flex items-center gap-3.5 p-3.5 bg-campus-sand/40 border border-campus-border/60 rounded-2xl">
            <VehicleVisual
              vehicle={vehicle}
              size="small"
              showBadge={false}
              className="border border-white shadow-md flex-shrink-0"
            />
            <div className="flex-1 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-campus-forest text-sm">{vehicle.brand} {vehicle.model}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-campus-forest text-campus-mint">
                  {vehicle.is_electric ? '⚡ Pure Electric' : `⛽ ${vehicle.engine_cc || 125}cc • Tank ${vehicle.fuel_level_percentage || 90}%`}
                </span>
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-gray-700">
                <span><span className="text-gray-500 font-medium">Vehicle Number:</span> <strong className="font-mono text-campus-forest">{vehicle.vehicle_number}</strong></span>
                <span><span className="text-gray-500 font-medium">Owner Name:</span> <strong className="text-gray-900">{vehicle.owner_name || vehicle.owner?.name || 'Campus Host'}</strong></span>
                <span>• ₹{vehicle.hourly_rate}/hr</span>
              </div>
            </div>
          </div>

          {/* Pickup & Return Zone Selectors */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-bold text-gray-700 mb-1 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-campus-emerald" />
                <span>Pickup Zone</span>
              </label>
              <select
                value={pickupZoneId}
                onChange={(e) => setPickupZoneId(e.target.value)}
                className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-campus-emerald/40 text-xs"
              >
                {Object.entries(
                  (zones || []).reduce((acc, z) => {
                    if (!z) return acc;
                    const college = z.college_name || 'Tamil Nadu Campuses';
                    if (!acc[college]) acc[college] = [];
                    acc[college].push(z);
                    return acc;
                  }, {})
                ).map(([college, cZones]) => (
                  <optgroup key={college} label={`🎓 ${college}`}>
                    {cZones.map((z) => (
                      <option key={z.id} value={z.id}>
                        {z.name} ({z.city})
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-campus-gold" />
                <span>Planned Return Hub</span>
              </label>
              <select
                value={returnZoneId}
                onChange={(e) => setReturnZoneId(e.target.value)}
                className="w-full p-2.5 bg-campus-sand/20 border border-campus-border/80 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-campus-emerald/40 text-xs"
              >
                {Object.entries(
                  (zones || []).reduce((acc, z) => {
                    if (!z) return acc;
                    const college = z.college_name || 'Tamil Nadu Campuses';
                    if (!acc[college]) acc[college] = [];
                    acc[college].push(z);
                    return acc;
                  }, {})
                ).map(([college, cZones]) => (
                  <optgroup key={college} label={`🎓 ${college}`}>
                    {cZones.map((z) => (
                      <option key={z.id} value={z.id}>
                        {z.name} ({z.city})
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>
          </div>

          {/* Duration Selector */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-2 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-campus-forest" />
              <span>Rental Duration</span>
            </label>
            <div className="grid grid-cols-4 gap-2 text-xs">
              {[0.5, 1.0, 2.0, 4.0].map((hrs) => (
                <button
                  key={hrs}
                  type="button"
                  onClick={() => setDurationHours(hrs)}
                  className={`py-2 px-3 rounded-xl font-bold border transition ${
                    durationHours === hrs
                      ? 'bg-campus-forest text-white border-campus-forest shadow'
                      : 'bg-white text-gray-700 border-campus-border/80 hover:bg-campus-sand/40'
                  }`}
                >
                  {hrs === 0.5 ? '30 mins' : `${hrs} hr${hrs > 1 ? 's' : ''}`}
                </button>
              ))}
            </div>
          </div>

          {/* Itemized Price Breakdown */}
          {pricing && (
            <div className="p-4 bg-campus-cream rounded-2xl border border-campus-border/80 space-y-2 text-xs">
              <div className="font-bold text-campus-forest flex items-center justify-between border-b border-campus-border/60 pb-1.5">
                <span>Smart Fare Breakdown</span>
                <span className="text-[10px] text-campus-emerald font-semibold">Campus Standard Rates</span>
              </div>

              <div className="flex justify-between text-gray-600">
                <span>Base Rate ({durationHours} hr{durationHours > 1 ? 's' : ''} × ₹{pricing.hourly_rate})</span>
                <span>₹{pricing.duration_charge.toFixed(2)}</span>
              </div>

              {pricing.discount_breakdown?.map((d, i) => (
                <div key={i} className="flex justify-between text-campus-emerald font-semibold">
                  <span>- {d.label}</span>
                  <span>-₹{d.amount.toFixed(2)}</span>
                </div>
              ))}

              <div className="pt-2 border-t border-campus-border/60 flex justify-between items-baseline font-extrabold text-sm text-campus-forest">
                <span>Total Payable</span>
                <span className="text-lg text-campus-forest font-display">₹{pricing.total_price.toFixed(2)}</span>
              </div>
            </div>
          )}

          {/* Payment Method Selector */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-2">
              Select Payment Method
            </label>
            <div className="grid grid-cols-3 gap-2 text-xs">
              {[
                { id: 'CAMPUS_WALLET', label: 'Campus Wallet', icon: Wallet },
                { id: 'UPI_MOCK', label: 'Instant UPI', icon: CreditCard },
                { id: 'STUDENT_ID_CARD', label: 'Student ID Tag', icon: ShieldCheck }
              ].map((pm) => {
                const Icon = pm.icon;
                return (
                  <button
                    key={pm.id}
                    type="button"
                    onClick={() => setPaymentMethod(pm.id)}
                    className={`p-2.5 rounded-xl border font-semibold flex flex-col items-center gap-1 transition ${
                      paymentMethod === pm.id
                        ? 'bg-campus-emerald/10 border-campus-emerald text-campus-forest ring-1 ring-campus-emerald'
                        : 'bg-white border-campus-border/80 text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-4 h-4 text-campus-emerald" />
                    <span className="text-[11px]">{pm.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* Modal Footer CTA */}
        <div className="p-5 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase font-bold text-gray-400">Total Amount</div>
            <div className="text-xl font-extrabold text-campus-forest font-display">
              ₹{pricing ? pricing.total_price.toFixed(2) : vehicle.hourly_rate}
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-gray-600 hover:bg-gray-200 rounded-2xl transition"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirmBooking}
              disabled={loading}
              className="px-5 py-2.5 bg-gradient-to-r from-campus-forest to-campus-emerald text-white text-xs font-bold rounded-2xl shadow-lg hover:shadow-xl hover:from-campus-emerald hover:to-campus-forest transition flex items-center gap-1.5 disabled:opacity-50"
            >
              <span>{loading ? 'Confirming...' : 'Confirm & Proceed to QR Unlock'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>

      {showKYCModal && (
        <RenterVerificationModal
          isOpen={showKYCModal}
          onClose={() => setShowKYCModal(false)}
          onSuccess={() => {
            setShowKYCModal(false);
            handleConfirmBooking();
          }}
        />
      )}
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalContent, document.body) : null;
}
