import React from 'react';

/**
 * Standardized vehicle category normalization logic.
 * Inspects database fields (category, vehicle_type, type, type_code, is_electric, fuel_type)
 * to return one of: 'MOTORCYCLE', 'SCOOTER', 'CAR', 'SUV', 'VAN', 'BICYCLE', 'EV', or 'GENERIC'.
 */
export function getVehicleCategory(vehicle) {
  if (!vehicle) return 'GENERIC';

  // 1. Check EV flag / power type first if explicitly pure electric
  const isElectric = vehicle.is_electric === true || 
    vehicle.fuel_type === 'ELECTRIC' || 
    vehicle.fuel_or_power_type === 'ELECTRIC';

  // 2. Extract raw category / type strings from various API shapes
  const rawCat = (
    vehicle.category ||
    vehicle.vehicle_type?.category ||
    vehicle.type?.category ||
    vehicle.type_code ||
    vehicle.vehicle_type?.code ||
    vehicle.type_name ||
    vehicle.type?.name ||
    ''
  ).toString().toUpperCase();

  const rawName = (
    (vehicle.brand ? `${vehicle.brand} ` : '') +
    (vehicle.model || '') + ' ' +
    (vehicle.type_name || '') + ' ' +
    (vehicle.type?.name || '')
  ).toUpperCase();

  // 3. Category matching logic
  if (rawCat.includes('BICYCLE') || rawCat.includes('CYCLE') || rawCat.includes('PEDAL') || rawName.includes('BICYCLE') || rawName.includes('CYCLE')) {
    return 'BICYCLE';
  }

  if (rawCat.includes('SCOOTER') || rawCat.includes('MOPED') || rawCat.includes('ACTIVA') || rawCat.includes('JUPITER') || rawCat.includes('NTORQ') || rawCat.includes('ACCESS') || rawName.includes('SCOOTER') || rawName.includes('MOPED') || rawName.includes('XL100')) {
    return isElectric ? 'EV' : 'SCOOTER';
  }

  if (rawCat.includes('MOTORCYCLE') || rawCat.includes('BIKE') || rawCat.includes('CRUISER') || rawCat.includes('BULLET') || rawCat.includes('ROYAL ENFIELD') || rawCat.includes('PULSAR') || rawCat.includes('APACHE') || rawCat.includes('FZ') || rawCat.includes('SPLENDOR') || rawCat.includes('SHINE') || rawName.includes('MOTORCYCLE') || rawName.includes('CRUISER')) {
    return isElectric ? 'EV' : 'MOTORCYCLE';
  }

  if (rawCat.includes('SUV') || rawCat.includes('CROSSOVER') || rawCat.includes('JEEP') || rawCat.includes('CRETA') || rawCat.includes('SELTOS') || rawCat.includes('BREZZA') || rawCat.includes('NEXON') || rawName.includes('SUV')) {
    return isElectric ? 'EV' : 'SUV';
  }

  if (rawCat.includes('VAN') || rawCat.includes('MINIVAN') || rawCat.includes('SHUTTLE') || rawCat.includes('BUS') || rawCat.includes('TEMPO') || rawCat.includes('OMNI') || rawCat.includes('EECO') || rawName.includes('VAN') || rawName.includes('SHUTTLE')) {
    return 'VAN';
  }

  if (rawCat.includes('CAR') || rawCat.includes('SEDAN') || rawCat.includes('HATCHBACK') || rawCat.includes('CAB') || rawName.includes('CAR') || rawName.includes('SWIFT') || rawName.includes('I20') || rawName.includes('CITY') || rawName.includes('DZIRE')) {
    return isElectric ? 'EV' : 'CAR';
  }

  if (rawCat.includes('EV') || rawCat.includes('ELECTRIC') || isElectric) {
    return 'EV';
  }

  return 'GENERIC';
}

/**
 * Metadata for each category including badge label, color accents, and icon title
 */
export const CATEGORY_META = {
  MOTORCYCLE: {
    label: 'Motorcycle',
    shortLabel: 'Bike',
    symbol: '🏍️',
    accentColor: 'text-indigo-600 dark:text-indigo-400',
    bgColor: 'bg-indigo-50 dark:bg-indigo-950/40',
    borderColor: 'border-indigo-200 dark:border-indigo-800/60',
    badgeBg: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/60 dark:text-indigo-300',
  },
  SCOOTER: {
    label: 'Scooter',
    shortLabel: 'Scooter',
    symbol: '🛵',
    accentColor: 'text-sky-600 dark:text-sky-400',
    bgColor: 'bg-sky-50 dark:bg-sky-950/40',
    borderColor: 'border-sky-200 dark:border-sky-800/60',
    badgeBg: 'bg-sky-100 text-sky-800 dark:bg-sky-900/60 dark:text-sky-300',
  },
  CAR: {
    label: 'Car / Sedan',
    shortLabel: 'Car',
    symbol: '🚗',
    accentColor: 'text-blue-600 dark:text-blue-400',
    bgColor: 'bg-blue-50 dark:bg-blue-950/40',
    borderColor: 'border-blue-200 dark:border-blue-800/60',
    badgeBg: 'bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300',
  },
  SUV: {
    label: 'SUV / Compact',
    shortLabel: 'SUV',
    symbol: '🚙',
    accentColor: 'text-amber-600 dark:text-amber-400',
    bgColor: 'bg-amber-50 dark:bg-amber-950/40',
    borderColor: 'border-amber-200 dark:border-amber-800/60',
    badgeBg: 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300',
  },
  VAN: {
    label: 'Campus Van / Shuttle',
    shortLabel: 'Van',
    symbol: '🚐',
    accentColor: 'text-purple-600 dark:text-purple-400',
    bgColor: 'bg-purple-50 dark:bg-purple-950/40',
    borderColor: 'border-purple-200 dark:border-purple-800/60',
    badgeBg: 'bg-purple-100 text-purple-800 dark:bg-purple-900/60 dark:text-purple-300',
  },
  BICYCLE: {
    label: 'Bicycle / Cycle',
    shortLabel: 'Bicycle',
    symbol: '🚲',
    accentColor: 'text-emerald-600 dark:text-emerald-400',
    bgColor: 'bg-emerald-50 dark:bg-emerald-950/40',
    borderColor: 'border-emerald-200 dark:border-emerald-800/60',
    badgeBg: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300',
  },
  EV: {
    label: 'Electric Vehicle (EV)',
    shortLabel: 'EV',
    symbol: '⚡',
    accentColor: 'text-teal-600 dark:text-teal-400',
    bgColor: 'bg-teal-50 dark:bg-teal-950/40',
    borderColor: 'border-teal-200 dark:border-teal-800/60',
    badgeBg: 'bg-teal-100 text-teal-800 dark:bg-teal-900/60 dark:text-teal-300',
  },
  GENERIC: {
    label: 'Campus Vehicle',
    shortLabel: 'Vehicle',
    symbol: '🚗',
    accentColor: 'text-slate-600 dark:text-slate-400',
    bgColor: 'bg-slate-50 dark:bg-slate-900/40',
    borderColor: 'border-slate-200 dark:border-slate-800/60',
    badgeBg: 'bg-slate-100 text-slate-800 dark:bg-slate-900/60 dark:text-slate-300',
  }
};

/**
 * Clean Minimal Vector SVG Icons
 */

// 🏍️ Clean Motorcycle Vector
function MotorcycleSVG({ className = 'w-full h-full' }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {/* Front Wheel */}
      <circle cx="16" cy="46" r="10" />
      <circle cx="16" cy="46" r="3" fill="currentColor" />
      {/* Rear Wheel */}
      <circle cx="48" cy="46" r="10" />
      <circle cx="48" cy="46" r="3" fill="currentColor" />
      {/* Front Fork & Handlebar */}
      <path d="M16 46 L24 22 L21 16" />
      <path d="M18 16 L27 16" />
      {/* Frame & Tank */}
      <path d="M24 22 L36 24 Q42 24 45 28 L48 46" />
      <path d="M24 22 L32 36 L48 46" />
      {/* Seat & Engine */}
      <path d="M34 24 Q38 22 46 25 L40 34 Z" fill="currentColor" fillOpacity="0.15" />
      <rect x="29" y="34" width="10" height="9" rx="2" fill="currentColor" fillOpacity="0.1" />
      {/* Exhaust Pipe */}
      <path d="M37 42 L52 42" strokeWidth="2" />
    </svg>
  );
}

// 🛵 Clean Scooter Vector
function ScooterSVG({ className = 'w-full h-full' }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {/* Front Wheel */}
      <circle cx="17" cy="47" r="8" />
      <circle cx="17" cy="47" r="2.5" fill="currentColor" />
      {/* Rear Wheel */}
      <circle cx="47" cy="47" r="8" />
      <circle cx="47" cy="47" r="2.5" fill="currentColor" />
      {/* Front Fairing & Stem */}
      <path d="M17 47 L23 20 L21 15" />
      <path d="M19 15 L26 15" />
      <path d="M23 20 Q20 28 22 36 L34 38" />
      {/* Floorboard */}
      <path d="M22 38 L36 38" strokeWidth="3" />
      {/* Rear Body & Seat */}
      <path d="M36 38 Q38 28 42 27 Q48 26 51 32 L47 47" fill="currentColor" fillOpacity="0.12" />
      <path d="M38 27 Q43 25 50 26" strokeWidth="3" />
      {/* Tail Light */}
      <path d="M51 32 L53 34" strokeWidth="2" stroke="currentColor" />
    </svg>
  );
}

// 🚗 Clean Car / Sedan Vector
function CarSVG({ className = 'w-full h-full' }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {/* Front Wheel */}
      <circle cx="19" cy="45" r="7" />
      <circle cx="19" cy="45" r="2" fill="currentColor" />
      {/* Rear Wheel */}
      <circle cx="45" cy="45" r="7" />
      <circle cx="45" cy="45" r="2" fill="currentColor" />
      {/* Underbody Line */}
      <path d="M12 45 L12 42 Q12 41 14 41 L19 41" />
      <path d="M26 45 L38 45" />
      <path d="M52 41 L54 41 Q56 41 56 43 L56 45" />
      {/* Car Body Profile */}
      <path d="M8 38 L14 38 L20 25 Q23 21 28 21 L40 21 Q44 21 47 26 L54 34 L57 37 Q58 39 58 42 L8 42 Q7 40 8 38 Z" fill="currentColor" fillOpacity="0.1" />
      {/* Windows & Pillar */}
      <path d="M22 25 L29 25 L29 34 L17 34 Z" fill="currentColor" fillOpacity="0.2" />
      <path d="M33 25 L41 25 L47 34 L33 34 Z" fill="currentColor" fillOpacity="0.2" />
      {/* Headlight & Taillight */}
      <path d="M9 37 L13 37" strokeWidth="2" />
      <path d="M55 36 L57 36" strokeWidth="2" />
    </svg>
  );
}

// 🚙 Clean SUV Vector
function SUVSVG({ className = 'w-full h-full' }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {/* Front Wheel */}
      <circle cx="19" cy="45" r="8" />
      <circle cx="19" cy="45" r="2.5" fill="currentColor" />
      {/* Rear Wheel */}
      <circle cx="45" cy="45" r="8" />
      <circle cx="45" cy="45" r="2.5" fill="currentColor" />
      {/* Roof Rails */}
      <path d="M24 16 L46 16" strokeWidth="2" />
      <path d="M26 16 L26 18" strokeWidth="2" />
      <path d="M44 16 L44 18" strokeWidth="2" />
      {/* SUV Body Outline */}
      <path d="M7 38 L14 38 L18 22 Q20 18 25 18 L50 18 Q53 18 54 22 L55 36 L57 38 Q58 40 58 42 L8 42 Z" fill="currentColor" fillOpacity="0.1" />
      {/* Windows */}
      <path d="M20 22 L31 22 L31 33 L15 33 Z" fill="currentColor" fillOpacity="0.2" />
      <path d="M35 22 L49 22 L50 33 L35 33 Z" fill="currentColor" fillOpacity="0.2" />
      {/* Ground clearance line */}
      <path d="M27 45 L37 45" />
    </svg>
  );
}

// 🚐 Clean Van / Shuttle Vector
function VanSVG({ className = 'w-full h-full' }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {/* Front Wheel */}
      <circle cx="18" cy="46" r="7.5" />
      <circle cx="18" cy="46" r="2" fill="currentColor" />
      {/* Rear Wheel */}
      <circle cx="46" cy="46" r="7.5" />
      <circle cx="46" cy="46" r="2" fill="currentColor" />
      {/* Van Body */}
      <path d="M8 43 L8 28 Q8 20 16 19 L50 19 Q55 19 56 24 L56 43 L8 43 Z" fill="currentColor" fillOpacity="0.1" />
      {/* Cab Windshield */}
      <path d="M12 23 L22 23 L22 33 L10 33 Q9 28 12 23 Z" fill="currentColor" fillOpacity="0.2" />
      {/* Passenger Windows */}
      <rect x="26" y="23" width="12" height="10" rx="1" fill="currentColor" fillOpacity="0.2" />
      <rect x="42" y="23" width="10" height="10" rx="1" fill="currentColor" fillOpacity="0.2" />
      {/* Sliding Door Seam */}
      <path d="M24 20 L24 43" strokeDasharray="2 2" strokeWidth="1.5" />
    </svg>
  );
}

// 🚲 Clean Bicycle Vector
function BicycleSVG({ className = 'w-full h-full' }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {/* Front Wheel */}
      <circle cx="16" cy="44" r="11" />
      <circle cx="16" cy="44" r="2" fill="currentColor" />
      {/* Rear Wheel */}
      <circle cx="48" cy="44" r="11" />
      <circle cx="48" cy="44" r="2" fill="currentColor" />
      {/* Frame Triangle */}
      <path d="M16 44 L25 24 L38 24 L48 44" />
      <path d="M25 24 L33 44 L48 44" />
      <path d="M38 24 L33 44" />
      {/* Seat & Post */}
      <path d="M33 44 L40 19" />
      <path d="M36 19 L44 19" strokeWidth="3" />
      {/* Handlebars */}
      <path d="M25 24 L22 17 L27 17" strokeWidth="2.5" />
      {/* Pedal / Crank */}
      <circle cx="33" cy="44" r="3" fill="currentColor" />
    </svg>
  );
}

// ⚡ Clean EV (Electric Vehicle) Vector
function EVSVG({ className = 'w-full h-full' }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {/* Wheels */}
      <circle cx="18" cy="45" r="7" />
      <circle cx="18" cy="45" r="2" fill="currentColor" />
      <circle cx="46" cy="45" r="7" />
      <circle cx="46" cy="45" r="2" fill="currentColor" />
      {/* Aerodynamic Eco Body */}
      <path d="M8 38 L14 37 L22 22 Q26 18 34 18 L46 22 L54 33 L57 37 Q58 39 58 42 L8 42 Z" fill="currentColor" fillOpacity="0.12" />
      {/* Panoramic Eco Glass */}
      <path d="M24 22 L44 22 L48 32 L20 32 Z" fill="currentColor" fillOpacity="0.25" />
      {/* Centered Energy Lightning Badge */}
      <path d="M32 23 L28 32 L33 32 L30 40 L37 30 L32 30 Z" fill="#10B981" stroke="#059669" strokeWidth="1.5" />
      {/* Battery / Charging Indicator Line */}
      <path d="M10 42 L14 42" stroke="#10B981" strokeWidth="2" />
      <path d="M50 42 L54 42" stroke="#10B981" strokeWidth="2" />
    </svg>
  );
}

// 🚗 Generic Vehicle Fallback
function GenericVehicleSVG({ className = 'w-full h-full' }) {
  return <CarSVG className={className} />;
}

/**
 * Single Unified Component: VehicleIcon
 * Returns the exact SVG for a vehicle or category string.
 */
export function VehicleIcon({ vehicle, category, className = 'w-6 h-6' }) {
  const cat = category || getVehicleCategory(vehicle);

  switch (cat) {
    case 'MOTORCYCLE':
      return <MotorcycleSVG className={className} />;
    case 'SCOOTER':
      return <ScooterSVG className={className} />;
    case 'CAR':
      return <CarSVG className={className} />;
    case 'SUV':
      return <SUVSVG className={className} />;
    case 'VAN':
      return <VanSVG className={className} />;
    case 'BICYCLE':
      return <BicycleSVG className={className} />;
    case 'EV':
      return <EVSVG className={className} />;
    default:
      return <GenericVehicleSVG className={className} />;
  }
}

/**
 * Full Showcase Visual Card Component: VehicleVisual
 * Replaces realistic photographs with a clean, modern, centered icon container.
 */
export function VehicleVisual({
  vehicle,
  category: explicitCategory,
  size = 'card', // 'thumbnail', 'small', 'preview', 'card', 'modal', 'hero'
  showBadge = true,
  className = '',
}) {
  const category = explicitCategory || getVehicleCategory(vehicle);
  const meta = CATEGORY_META[category] || CATEGORY_META.GENERIC;

  // Size configurations
  const sizeStyles = {
    thumbnail: 'w-11 h-11 rounded-xl p-1.5',
    small: 'w-14 h-14 rounded-xl p-2',
    preview: 'h-36 w-full rounded-2xl p-4',
    modal: 'w-20 h-20 rounded-2xl p-3',
    card: 'h-48 w-full rounded-2xl p-6',
    hero: 'h-64 sm:h-80 w-full rounded-3xl p-8',
  };

  const iconSizes = {
    thumbnail: 'w-7 h-7',
    small: 'w-8 h-8',
    preview: 'w-20 h-20',
    modal: 'w-12 h-12',
    card: 'w-28 h-28 sm:w-32 sm:h-32',
    hero: 'w-40 h-40 sm:w-48 sm:h-48',
  };

  const containerClass = sizeStyles[size] || sizeStyles.card;
  const iconClass = iconSizes[size] || iconSizes.card;

  return (
    <div
      className={`relative flex flex-col items-center justify-center border transition-all duration-300 select-none overflow-hidden ${meta.bgColor} ${meta.borderColor} ${containerClass} ${className}`}
    >
      {/* Subtle modern geometric background ring */}
      <div className="absolute inset-0 opacity-[0.05] pointer-events-none flex items-center justify-center">
        <div className="w-56 h-56 rounded-full border-4 border-current" />
      </div>

      {/* Centered Clean Minimal Vector Icon */}
      <div className={`relative z-10 transition-transform duration-300 group-hover:scale-105 ${meta.accentColor}`}>
        <VehicleIcon category={category} className={iconClass} />
      </div>

      {/* Optional Minimalist Category Tag/Badge (when size allows) */}
      {showBadge && (size === 'card' || size === 'preview' || size === 'hero') && (
        <div className="absolute bottom-2.5 right-2.5 z-10">
          <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider shadow-sm border border-black/5 dark:border-white/10 ${meta.badgeBg}`}>
            <span>{meta.symbol}</span>
            <span>{meta.shortLabel}</span>
          </span>
        </div>
      )}
    </div>
  );
}

export default VehicleVisual;
