import React from 'react';
import { Link } from 'react-router-dom';
import { Bike, Leaf, Shield, Heart, MapPin, Phone, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-12 pb-8 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          
          {/* Brand & Mission with Campus Mobility Logo */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-black border border-emerald-400/50 flex items-center justify-center overflow-hidden flex-shrink-0">
                <img
                  src="/campus-mobility-logo.jpg"
                  alt="Campus Mobility Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <span className="font-bold text-lg text-white tracking-tight">
                CAMPUS<span className="text-emerald-400"> MOBILITY</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Smart Campus Mobility System. Zero-emission fleet management, turn-by-turn navigation, and sustainable micro-transit infrastructure.
            </p>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-800/40 text-emerald-400 text-xs font-semibold">
              <Leaf className="w-4 h-4 text-emerald-400" />
              100% Eco-Green Campus Fleet
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-4">Quick Access</h3>
            <ul className="space-y-2.5 text-xs font-medium text-slate-400">
              <li>
                <Link to="/vehicles" className="hover:text-emerald-400 transition-colors">Browse Fleet & Zones</Link>
              </li>
              <li>
                <Link to="/recommend" className="hover:text-emerald-400 transition-colors">Smart Vehicle Matcher</Link>
              </li>
              <li>
                <Link to="/eco" className="hover:text-emerald-400 transition-colors">Eco Score & Carbon Offset</Link>
              </li>
              <li>
                <Link to="/emergency-rides" className="hover:text-emerald-400 transition-colors">Campus Ride Board</Link>
              </li>
              <li>
                <Link to="/how-it-works" className="hover:text-emerald-400 transition-colors">How QR Rentals Work</Link>
              </li>
            </ul>
          </div>

          {/* Campus Hubs */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-4">Designated Hubs</h3>
            <ul className="space-y-2 text-xs font-medium text-slate-400">
              <li className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-emerald-500" />
                Main Campus Gate (ZN-MG)
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-emerald-500" />
                Central Library Hub (ZN-LIB)
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-emerald-500" />
                Academic Block Alpha (ZN-ACAD)
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-emerald-500" />
                Hostel Village (ZN-HST)
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-emerald-500" />
                Sports & Tech Park (ZN-SPORTS)
              </li>
            </ul>
          </div>

          {/* Campus Support */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-4">Fleet Operations</h3>
            <div className="space-y-2.5 text-xs text-slate-400">
              <p className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                Fleet Control: ext. 4400 / +91 9876543210
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-slate-400" />
                fleet-help@campus.edu
              </p>
              <div className="pt-2">
                <p className="text-[11px] text-slate-500">
                  Fleet maintenance & recharging active daily from 06:00 to 23:00.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© 2026 Smart Campus Vehicle Rental & Mobility System. Capstone Project.</p>
          <div className="flex items-center gap-6">
            <Link to="/about" className="hover:text-slate-300 transition-colors">About System</Link>
            <Link to="/how-it-works" className="hover:text-slate-300 transition-colors">Rental Policies</Link>
            <span className="text-emerald-500 font-medium">Zero-Emission Campus</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
