import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotificationContext';
import { useBooking } from '../../context/BookingContext';
import { 
  Bike, Zap, Shield, Bell, User, LogOut, Compass, 
  Leaf, AlertTriangle, Calendar, Activity, CheckCircle2, ChevronDown, Building2,
  LayoutDashboard, ShieldCheck, Search, Wrench, Users, DollarSign,
  Truck, CheckSquare, Sparkles, Navigation, Layers, Menu, X, FileText, Download, ExternalLink
} from 'lucide-react';

import { SystemHealthModal } from './SystemHealthModal';
import RenterVerificationModal from '../security/RenterVerificationModal';

export function Navbar({ currentTab, setTab }) {
  const { user, isAuthenticated, isAdmin, isOwner, isStaff, isStudent, logout, refreshUser } = useAuth();
  const { notifications, unreadCount, markAllAsRead } = useNotifications();
  const { activeBooking } = useBooking();
  const [showNotifs, setShowNotifs] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showServicesMenu, setShowServicesMenu] = useState(false);
  const [showReportMenu, setShowReportMenu] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showHealthModal, setShowHealthModal] = useState(false);
  const [showKYCModal, setShowKYCModal] = useState(false);

  // Close dropdowns when clicking outside
  const navRef = useRef(null);
  useEffect(() => {
    function handleClickOutside(event) {
      if (navRef.current && !navRef.current.contains(event.target)) {
        setShowNotifs(false);
        setShowProfileMenu(false);
        setShowServicesMenu(false);
        setShowReportMenu(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Intelligent home routing based on user's active role
  const handleHomeClick = () => {
    if (isAdmin) {
      setTab('admin-dashboard');
    } else if (isStaff) {
      setTab('staff-dashboard');
    } else if (isOwner) {
      setTab('owner-dashboard');
    } else {
      setTab('dashboard');
    }
  };

  const isRiderHubActive = ['active-rental', 'my-bookings', 'eco-score', 'emergency-rides', 'bike-lookup'].includes(currentTab);

  return (
    <header className="sticky top-0 z-40 bg-campus-forest text-white shadow-xl border-b border-campus-emerald/50 backdrop-blur-md bg-opacity-95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Campus Mobility Brand */}
          <div className="flex items-center space-x-3 cursor-pointer py-1" onClick={handleHomeClick}>
            <div className="w-10 h-10 rounded-xl bg-black flex items-center justify-center shadow-lg border border-emerald-400/40 overflow-hidden flex-shrink-0 transition-transform hover:scale-105">
              <img
                src="/campus-mobility-logo.jpg"
                alt="Campus Mobility Logo"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <div className="font-extrabold text-base sm:text-lg tracking-tight flex items-center gap-2 font-display">
                <span className="text-white">CAMPUS <span className="text-emerald-400">MOBILITY</span></span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] uppercase font-bold tracking-widest bg-campus-gold/20 text-campus-gold border border-campus-gold/40 rounded-full">
                  {isAdmin ? 'ADMIN CONSOLE' : isStaff ? 'STAFF OPS' : isOwner ? 'OWNER PORTAL' : 'STUDENT PASS'}
                </span>
              </div>
              <p className="text-[10px] text-campus-mint/80 font-medium tracking-wide">
                {isAdmin ? 'Executive Estate & Security Management' : 
                 isStaff ? 'Fleet Operations, Dispatch & Health' :
                 isOwner ? 'Vehicle Host & Tariff Payouts' :
                 'Smart Micro-Mobility & Clean Transit'}
              </p>
            </div>
          </div>

          {/* ========================================================================= */}
          {/* DESKTOP ROLE-SPECIFIC NAVIGATION BAR */}
          {/* ========================================================================= */}
          <nav className="hidden lg:flex items-center space-x-1 text-xs font-semibold">
            
            {/* 1. STUDENT (OR PUBLIC / LOGGED OUT) MENU */}
            {(!isAuthenticated || isStudent) && (
              <>
                <button
                  onClick={() => setTab('dashboard')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 ${currentTab === 'dashboard' ? 'bg-campus-emerald text-white shadow-sm ring-1 ring-campus-mint/40' : 'text-gray-200 hover:bg-white/10'}`}
                >
                  <LayoutDashboard className="w-3.5 h-3.5 text-campus-mint" />
                  <span>Dashboard</span>
                </button>

                <button
                  onClick={() => setTab('vehicles')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 ${currentTab === 'vehicles' ? 'bg-campus-emerald text-white shadow-sm ring-1 ring-campus-mint/40' : 'text-gray-200 hover:bg-white/10'}`}
                >
                  <Bike className="w-3.5 h-3.5 text-campus-mint" />
                  <span>Vehicles</span>
                </button>

                <button
                  onClick={() => setTab('recommendation')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 ${currentTab === 'recommendation' ? 'bg-campus-emerald text-white shadow-sm ring-1 ring-campus-mint/40' : 'text-gray-200 hover:bg-white/10'}`}
                >
                  <Zap className="w-3.5 h-3.5 text-campus-gold" />
                  <span>Smart Match</span>
                </button>

                <button
                  onClick={() => setTab('live-gps')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 ${currentTab === 'live-gps' ? 'bg-campus-emerald text-white shadow-sm ring-1 ring-campus-mint/40' : 'text-gray-200 hover:bg-white/10'}`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  <span>Live GPS</span>
                </button>

                <button
                  onClick={() => setTab('ai-copilot')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 bg-gradient-to-r from-campus-emerald/80 to-emerald-900 border border-campus-mint/50 font-bold ${currentTab === 'ai-copilot' ? 'ring-2 ring-campus-mint text-white' : 'text-campus-mint hover:text-white'}`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-campus-gold" />
                  <span>AI Copilot</span>
                </button>

                {/* Secondary Hub Dropdown for Services */}
                {isAuthenticated && (
                  <div className="relative">
                    <button
                      onClick={() => setShowServicesMenu(!showServicesMenu)}
                      className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 border ${
                        isRiderHubActive 
                          ? 'bg-campus-emerald/80 text-white border-campus-mint/40 shadow-sm' 
                          : 'text-gray-200 border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <Layers className="w-3.5 h-3.5 text-campus-mint" />
                      <span>Rider Hub</span>
                      {activeBooking && (
                        <span className="w-2 h-2 rounded-full bg-campus-mint animate-ping"></span>
                      )}
                      <ChevronDown className="w-3 h-3 text-gray-300" />
                    </button>

                    {showServicesMenu && (
                      <div className="absolute left-0 mt-2 w-56 bg-white text-campus-charcoal rounded-2xl shadow-2xl border border-gray-200 overflow-hidden z-50 animate-in fade-in py-1.5">
                        <div className="px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-wider text-gray-400 border-b border-gray-100">
                          Rider Tools & History
                        </div>

                        <button
                          onClick={() => { setTab('active-rental'); setShowServicesMenu(false); }}
                          className={`w-full text-left px-3.5 py-2 text-xs font-semibold flex items-center justify-between transition ${
                            currentTab === 'active-rental' ? 'bg-campus-sand text-campus-forest font-bold' : 'hover:bg-campus-sand/40 text-gray-700'
                          }`}
                        >
                          <span className="flex items-center gap-2">
                            <Activity className="w-4 h-4 text-campus-emerald" />
                            <span>Live Ride HUD</span>
                          </span>
                          {activeBooking && (
                            <span className="px-1.5 py-0.2 bg-emerald-100 text-emerald-800 rounded-full text-[9px] font-bold">Active</span>
                          )}
                        </button>

                        <button
                          onClick={() => { setTab('my-bookings'); setShowServicesMenu(false); }}
                          className={`w-full text-left px-3.5 py-2 text-xs font-semibold flex items-center gap-2 transition ${
                            currentTab === 'my-bookings' ? 'bg-campus-sand text-campus-forest font-bold' : 'hover:bg-campus-sand/40 text-gray-700'
                          }`}
                        >
                          <Calendar className="w-4 h-4 text-blue-600" />
                          <span>My Rides & Receipts</span>
                        </button>

                        <button
                          onClick={() => { setTab('eco-score'); setShowServicesMenu(false); }}
                          className={`w-full text-left px-3.5 py-2 text-xs font-semibold flex items-center gap-2 transition ${
                            currentTab === 'eco-score' ? 'bg-campus-sand text-campus-forest font-bold' : 'hover:bg-campus-sand/40 text-gray-700'
                          }`}
                        >
                          <Leaf className="w-4 h-4 text-campus-mint" />
                          <span>Eco Score & Carbon</span>
                        </button>

                        <button
                          onClick={() => { setTab('emergency-rides'); setShowServicesMenu(false); }}
                          className={`w-full text-left px-3.5 py-2 text-xs font-semibold flex items-center gap-2 transition ${
                            currentTab === 'emergency-rides' ? 'bg-campus-sand text-campus-forest font-bold' : 'hover:bg-campus-sand/40 text-gray-700'
                          }`}
                        >
                          <AlertTriangle className="w-4 h-4 text-amber-500" />
                          <span>Carpool & Exam Rides</span>
                        </button>

                        <button
                          onClick={() => { setTab('bike-lookup'); setShowServicesMenu(false); }}
                          className={`w-full text-left px-3.5 py-2 text-xs font-semibold flex items-center gap-2 transition ${
                            currentTab === 'bike-lookup' ? 'bg-campus-sand text-campus-forest font-bold' : 'hover:bg-campus-sand/40 text-gray-700'
                          }`}
                        >
                          <Search className="w-4 h-4 text-purple-600" />
                          <span>Bike Owner Lookup</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </>
            )}

            {/* 2. OWNER MENU */}
            {isAuthenticated && isOwner && (
              <>
                <button
                  onClick={() => setTab('owner-dashboard')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 bg-campus-mint/20 text-campus-mint border border-campus-mint/50 font-bold ${currentTab === 'owner-dashboard' ? 'ring-2 ring-campus-mint bg-campus-mint/30 text-white' : 'hover:bg-campus-mint/30'}`}
                >
                  <Building2 className="w-4 h-4" />
                  <span>Owner Fleet Portal</span>
                </button>

                <button
                  onClick={() => setTab('live-gps')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 ${currentTab === 'live-gps' ? 'bg-campus-emerald text-white shadow' : 'text-gray-200 hover:bg-white/10'}`}
                >
                  <Navigation className="w-3.5 h-3.5 text-campus-gold" />
                  <span>Live Vehicle Map</span>
                </button>

                <button
                  onClick={() => setTab('bike-lookup')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 ${currentTab === 'bike-lookup' ? 'bg-campus-emerald text-white shadow' : 'text-gray-200 hover:bg-white/10'}`}
                >
                  <Search className="w-3.5 h-3.5 text-blue-300" />
                  <span>Bike Lookup</span>
                </button>
              </>
            )}

            {/* 3. STAFF (OPERATIONS & FLEET OPS) MENU */}
            {isAuthenticated && isStaff && (
              <>
                <button
                  onClick={() => setTab('staff-dashboard')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 bg-blue-500/20 text-blue-300 border border-blue-400/50 font-bold ${currentTab === 'staff-dashboard' ? 'ring-2 ring-blue-400 bg-blue-600/30 text-white' : 'hover:bg-blue-500/30'}`}
                >
                  <Wrench className="w-4 h-4 text-blue-400" />
                  <span>Operations Console</span>
                </button>

                <button
                  onClick={() => setTab('live-gps')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 ${currentTab === 'live-gps' ? 'bg-campus-emerald text-white shadow' : 'text-gray-200 hover:bg-white/10'}`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  <span>Fleet Radar</span>
                </button>

                <button
                  onClick={() => setTab('bike-lookup')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 ${currentTab === 'bike-lookup' ? 'bg-campus-emerald text-white shadow' : 'text-gray-200 hover:bg-white/10'}`}
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-blue-300" />
                  <span>Bike Security Lookup</span>
                </button>
              </>
            )}

            {/* 4. ADMIN MENU (EXECUTIVE OVERVIEW & ALL MODULES) */}
            {isAuthenticated && isAdmin && (
              <>
                <button
                  onClick={() => setTab('admin-dashboard')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 bg-campus-gold/20 text-campus-gold border border-campus-gold/50 font-bold ${currentTab === 'admin-dashboard' ? 'ring-2 ring-campus-gold bg-campus-gold/30 text-white' : 'hover:bg-campus-gold/30'}`}
                >
                  <Shield className="w-4 h-4 text-campus-gold" />
                  <span>Admin Hub</span>
                </button>

                <button
                  onClick={() => setTab('security-dashboard')}
                  className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 bg-blue-600/30 text-blue-300 border border-blue-400/50 font-bold ${currentTab === 'security-dashboard' ? 'ring-2 ring-blue-400 text-white' : 'hover:bg-blue-600/40'}`}
                >
                  <ShieldCheck className="w-4 h-4 text-blue-400" />
                  <span>Security & Verification</span>
                </button>

                <button
                  onClick={() => setTab('live-gps')}
                  className={`px-2.5 py-1.5 rounded-xl transition flex items-center gap-1.5 ${currentTab === 'live-gps' ? 'bg-campus-emerald text-white shadow' : 'text-gray-200 hover:bg-white/10'}`}
                >
                  <Compass className="w-3.5 h-3.5 text-campus-mint" />
                  <span>Live Radar</span>
                </button>

                <button
                  onClick={() => setTab('bike-lookup')}
                  className={`px-2.5 py-1.5 rounded-xl transition flex items-center gap-1.5 ${currentTab === 'bike-lookup' ? 'bg-campus-emerald text-white shadow' : 'text-gray-200 hover:bg-white/10'}`}
                >
                  <Search className="w-3.5 h-3.5 text-blue-300" />
                  <span>Bike Lookup</span>
                </button>
              </>
            )}

          </nav>

          {/* Right Actions (Role Badge, KYC Pill, Notifications, User Profile, Mobile Hamburger) */}
          <div className="flex items-center space-x-2">

            {/* Capstone Dissertation 70-Page Report Menu */}
            <div className="relative">
              <button
                onClick={() => setShowReportMenu(!showReportMenu)}
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-gradient-to-r from-campus-emerald/90 to-emerald-950 border border-campus-mint/50 rounded-xl text-xs font-bold text-campus-mint hover:text-white hover:border-campus-mint transition shadow-sm"
                title="Download or View 70-Page Capstone Dissertation Report"
              >
                <FileText className="w-4 h-4 text-campus-gold" />
                <span className="hidden md:inline">70-Page Report</span>
                <ChevronDown className="w-3 h-3 text-gray-300" />
              </button>

              {showReportMenu && (
                <div className="absolute right-0 mt-2 w-72 bg-white text-campus-charcoal rounded-2xl shadow-2xl border border-gray-200 overflow-hidden z-50 animate-in fade-in py-2">
                  <div className="px-3.5 py-2 bg-campus-forest text-white">
                    <p className="text-xs font-bold flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-campus-gold" />
                      <span>Capstone Project Dissertation</span>
                    </p>
                    <p className="text-[10px] text-campus-mint/90 mt-0.5">70–80 Pages • 100% Watermark-Free</p>
                  </div>

                  <div className="p-2 space-y-1">
                    <a
                      href="/report.docx"
                      download="Smart_Campus_Mobility_70_Pages_Report.docx"
                      onClick={() => setShowReportMenu(false)}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-emerald-50 text-gray-800 transition group"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 bg-blue-100 text-blue-700 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition">
                          <Download className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-gray-900">Word Document (.docx)</p>
                          <p className="text-[10px] text-gray-500">Editable 70-Page Dissertation</p>
                        </div>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-50 text-blue-700 rounded-md border border-blue-200">DOCX</span>
                    </a>

                    <a
                      href="/report.pdf"
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => setShowReportMenu(false)}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-emerald-50 text-gray-800 transition group"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 bg-red-100 text-red-700 rounded-lg group-hover:bg-red-600 group-hover:text-white transition">
                          <ExternalLink className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-gray-900">View PDF Document</p>
                          <p className="text-[10px] text-gray-500">73 Pages • Print-Ready</p>
                        </div>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-red-50 text-red-700 rounded-md border border-red-200">PDF</span>
                    </a>
                  </div>
                </div>
              )}
            </div>

            {isAuthenticated ? (
              <>
                {/* Role-Specific Metric Pill */}
                {isStudent && (
                  <div className="hidden sm:flex items-center space-x-1.5 px-3 py-1 bg-campus-emerald/60 border border-campus-mint/40 rounded-full text-xs font-semibold text-campus-mint">
                    <Leaf className="w-3.5 h-3.5 text-campus-mint" />
                    <span>{user?.eco_points || 0} pts</span>
                  </div>
                )}

                {/* Direct KYC Status / Verification Action Pill */}
                {isStudent && (
                  <button
                    onClick={() => setShowKYCModal(true)}
                    className={`hidden sm:flex items-center space-x-1.5 px-2.5 py-1 border rounded-full text-xs font-bold transition shadow-sm ${
                      user?.is_verified 
                        ? 'bg-blue-900/40 border-blue-400/50 text-blue-200 hover:bg-blue-800/60' 
                        : 'bg-amber-500/20 border-amber-400/60 text-amber-300 hover:bg-amber-500/40 animate-pulse'
                    }`}
                    title="Campus Renter KYC Verification"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-300" />
                    <span>{user?.is_verified ? 'KYC Verified ✓' : 'Verify KYC'}</span>
                  </button>
                )}

                {/* Notification Bell */}
                <div className="relative">
                  <button
                    onClick={() => {
                      setShowNotifs(!showNotifs);
                      if (!showNotifs) markAllAsRead();
                    }}
                    className="p-2 rounded-xl text-gray-200 hover:text-white hover:bg-white/10 relative transition"
                    title="Campus Notifications"
                  >
                    <Bell className="w-5 h-5" />
                    {unreadCount > 0 && (
                      <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center animate-pulse">
                        {unreadCount}
                      </span>
                    )}
                  </button>

                  {/* Notification Dropdown */}
                  {showNotifs && (
                    <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white text-campus-charcoal rounded-2xl shadow-2xl border border-gray-200 overflow-hidden z-50 animate-in fade-in">
                      <div className="p-3.5 bg-campus-forest text-white font-bold text-xs flex justify-between items-center">
                        <span className="flex items-center gap-1.5">
                          <Bell className="w-4 h-4 text-campus-gold" />
                          <span>Campus Notifications</span>
                        </span>
                        <span className="text-[10px] text-gray-300">Live Updates</span>
                      </div>
                      <div className="max-h-80 overflow-y-auto divide-y divide-gray-100">
                        {notifications.length === 0 ? (
                          <div className="p-6 text-center text-xs text-gray-400">
                            No notifications right now.
                          </div>
                        ) : (
                          notifications.map((n) => (
                            <div key={n.id} className="p-3 hover:bg-campus-cream/60 transition text-xs">
                              <div className="font-semibold text-campus-forest flex items-center justify-between">
                                <span>{n.title}</span>
                                <span className="text-[10px] text-gray-400 font-normal">{n.created_at}</span>
                              </div>
                              <p className="text-gray-600 mt-1">{n.message}</p>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* User Profile Pill */}
                <div className="relative">
                  <button
                    onClick={() => setShowProfileMenu(!showProfileMenu)}
                    className="flex items-center space-x-2 pl-2 pr-3 py-1 bg-white/10 hover:bg-white/20 border border-white/20 rounded-2xl transition"
                  >
                    <div className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs ${
                      isAdmin ? 'bg-gradient-to-tr from-campus-gold to-amber-500 text-campus-forest' :
                      isStaff ? 'bg-gradient-to-tr from-blue-500 to-indigo-600 text-white' :
                      isOwner ? 'bg-gradient-to-tr from-purple-500 to-indigo-600 text-white' :
                      'bg-gradient-to-tr from-campus-emerald to-campus-mint text-campus-forest'
                    }`}>
                      {user?.name?.charAt(0) || 'U'}
                    </div>
                    <div className="text-left hidden sm:block">
                      <div className="text-xs font-bold leading-tight">{user?.name?.split(' ')[0]}</div>
                      <div className={`text-[10px] uppercase font-bold ${
                        isAdmin ? 'text-campus-gold' :
                        isStaff ? 'text-blue-300' :
                        isOwner ? 'text-purple-300' :
                        'text-campus-mint'
                      }`}>
                        {user?.role}
                      </div>
                    </div>
                    <ChevronDown className="w-3.5 h-3.5 text-gray-300" />
                  </button>

                  {/* Profile Dropdown */}
                  {showProfileMenu && (
                    <div className="absolute right-0 mt-2 w-60 bg-white text-campus-charcoal rounded-2xl shadow-2xl border border-gray-200 overflow-hidden z-50 animate-in fade-in">
                      <div className="p-3.5 bg-campus-cream border-b border-gray-100">
                        <div className="font-bold text-xs text-campus-forest">{user?.name}</div>
                        <div className="text-[11px] text-gray-500 truncate">{user?.email}</div>
                        <div className="text-[10px] text-campus-emerald font-semibold mt-1">
                          Role: <strong className="uppercase font-bold">{user?.role}</strong>
                        </div>
                      </div>

                      <div className="p-1.5 space-y-1">
                        
                        {/* Student Dropdown Items */}
                        {isStudent && (
                          <>
                            <button
                              onClick={() => { setShowKYCModal(true); setShowProfileMenu(false); }}
                              className="w-full text-left px-3 py-2 text-xs font-semibold text-blue-600 bg-blue-50/70 hover:bg-blue-100 rounded-xl transition flex items-center gap-2"
                            >
                              <ShieldCheck className="w-4 h-4 text-blue-600" />
                              <span>Student KYC Verification</span>
                            </button>
                            <button
                              onClick={() => { setTab('my-bookings'); setShowProfileMenu(false); }}
                              className="w-full text-left px-3 py-2 text-xs font-medium text-gray-700 hover:bg-campus-sand/40 rounded-xl transition flex items-center gap-2"
                            >
                              <Calendar className="w-4 h-4 text-campus-forest" />
                              <span>My Rides & Receipts</span>
                            </button>
                            <button
                              onClick={() => { setTab('eco-score'); setShowProfileMenu(false); }}
                              className="w-full text-left px-3 py-2 text-xs font-medium text-gray-700 hover:bg-campus-sand/40 rounded-xl transition flex items-center gap-2"
                            >
                              <Leaf className="w-4 h-4 text-campus-emerald" />
                              <span>Eco Score & Carbon Stats</span>
                            </button>
                          </>
                        )}

                        {/* Owner Dropdown Items */}
                        {isOwner && (
                          <button
                            onClick={() => { setTab('owner-dashboard'); setShowProfileMenu(false); }}
                            className="w-full text-left px-3 py-2 text-xs font-bold text-campus-forest bg-campus-mint/20 hover:bg-campus-mint/30 rounded-xl transition flex items-center gap-2"
                          >
                            <Building2 className="w-4 h-4 text-campus-mint" />
                            <span>Owner Fleet Portal</span>
                          </button>
                        )}

                        {/* Staff Dropdown Items */}
                        {isStaff && (
                          <button
                            onClick={() => { setTab('staff-dashboard'); setShowProfileMenu(false); }}
                            className="w-full text-left px-3 py-2 text-xs font-bold text-blue-900 bg-blue-50 hover:bg-blue-100 rounded-xl transition flex items-center gap-2"
                          >
                            <Wrench className="w-4 h-4 text-blue-600" />
                            <span>Operations & Dispatch Console</span>
                          </button>
                        )}

                        {/* Admin Dropdown Items */}
                        {isAdmin && (
                          <>
                            <button
                              onClick={() => { setTab('admin-dashboard'); setShowProfileMenu(false); }}
                              className="w-full text-left px-3 py-2 text-xs font-bold text-campus-forest bg-campus-gold/20 hover:bg-campus-gold/30 rounded-xl transition flex items-center gap-2"
                            >
                              <Shield className="w-4 h-4 text-campus-gold" />
                              <span>Admin Master Hub</span>
                            </button>
                            <button
                              onClick={() => { setTab('security-dashboard'); setShowProfileMenu(false); }}
                              className="w-full text-left px-3 py-2 text-xs font-bold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-xl transition flex items-center gap-2"
                            >
                              <ShieldCheck className="w-4 h-4 text-blue-600" />
                              <span>Security & Verification Center</span>
                            </button>
                          </>
                        )}

                        <button
                          onClick={() => { setTab('bike-lookup'); setShowProfileMenu(false); }}
                          className="w-full text-left px-3 py-2 text-xs font-medium text-gray-700 hover:bg-campus-sand/40 rounded-xl transition flex items-center gap-2"
                        >
                          <Search className="w-4 h-4 text-blue-500" />
                          <span>Who Owns This Bike?</span>
                        </button>

                        <hr className="my-1 border-gray-100" />
                        <button
                          onClick={() => { logout(); setShowProfileMenu(false); setTab('dashboard'); }}
                          className="w-full text-left px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50 rounded-xl transition flex items-center gap-2"
                        >
                          <LogOut className="w-4 h-4" />
                          <span>Log Out</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setShowHealthModal(true)}
                  className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-[11px] font-bold text-campus-mint transition"
                  title="View Unified System & API Status"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>System Online</span>
                </button>

                <button
                  onClick={() => setTab('login')}
                  className="px-3 py-1.5 text-xs font-semibold text-white hover:bg-white/10 rounded-xl transition"
                >
                  Log In
                </button>
                <button
                  onClick={() => setTab('register')}
                  className="px-3.5 py-1.5 text-xs font-bold bg-campus-gold text-campus-forest rounded-xl shadow-lg hover:bg-amber-400 transition"
                >
                  Register
                </button>
              </div>
            )}

            {/* Mobile / Tablet Menu Hamburger Button */}
            <button
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="lg:hidden p-2 rounded-xl text-gray-200 hover:text-white hover:bg-white/10 transition"
              aria-label="Toggle Navigation Menu"
            >
              {showMobileMenu ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

          </div>

        </div>
      </div>

      {/* ========================================================================= */}
      {/* MOBILE / TABLET SLIDE-DOWN DRAWER MENU */}
      {/* ========================================================================= */}
      {showMobileMenu && (
        <div className="lg:hidden bg-campus-forest/98 border-t border-campus-emerald/50 px-4 pt-3 pb-6 space-y-2 animate-in slide-in-from-top duration-200">
          <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
            {(!isAuthenticated || isStudent) && (
              <>
                <button
                  onClick={() => { setTab('dashboard'); setShowMobileMenu(false); }}
                  className={`p-2.5 rounded-xl text-left flex items-center gap-2 ${currentTab === 'dashboard' ? 'bg-campus-emerald text-white font-bold' : 'bg-white/10 text-gray-200'}`}
                >
                  <LayoutDashboard className="w-4 h-4 text-campus-mint" />
                  <span>Dashboard</span>
                </button>

                <button
                  onClick={() => { setTab('vehicles'); setShowMobileMenu(false); }}
                  className={`p-2.5 rounded-xl text-left flex items-center gap-2 ${currentTab === 'vehicles' ? 'bg-campus-emerald text-white font-bold' : 'bg-white/10 text-gray-200'}`}
                >
                  <Bike className="w-4 h-4 text-campus-mint" />
                  <span>Vehicles</span>
                </button>

                <button
                  onClick={() => { setTab('recommendation'); setShowMobileMenu(false); }}
                  className={`p-2.5 rounded-xl text-left flex items-center gap-2 ${currentTab === 'recommendation' ? 'bg-campus-emerald text-white font-bold' : 'bg-white/10 text-gray-200'}`}
                >
                  <Zap className="w-4 h-4 text-campus-gold" />
                  <span>Smart Match</span>
                </button>

                <button
                  onClick={() => { setTab('live-gps'); setShowMobileMenu(false); }}
                  className={`p-2.5 rounded-xl text-left flex items-center gap-2 ${currentTab === 'live-gps' ? 'bg-campus-emerald text-white font-bold' : 'bg-white/10 text-gray-200'}`}
                >
                  <Navigation className="w-4 h-4 text-campus-gold" />
                  <span>Live GPS</span>
                </button>

                <button
                  onClick={() => { setTab('ai-copilot'); setShowMobileMenu(false); }}
                  className={`p-2.5 rounded-xl text-left flex items-center gap-2 ${currentTab === 'ai-copilot' ? 'bg-campus-emerald text-white font-bold' : 'bg-white/10 text-gray-200'}`}
                >
                  <Sparkles className="w-4 h-4 text-campus-gold" />
                  <span>AI Copilot</span>
                </button>

                {isAuthenticated && (
                  <>
                    <button
                      onClick={() => { setTab('active-rental'); setShowMobileMenu(false); }}
                      className={`p-2.5 rounded-xl text-left flex items-center gap-2 ${currentTab === 'active-rental' ? 'bg-campus-emerald text-white font-bold' : 'bg-white/10 text-gray-200'}`}
                    >
                      <Activity className="w-4 h-4 text-campus-mint" />
                      <span>Live Ride HUD</span>
                    </button>

                    <button
                      onClick={() => { setTab('my-bookings'); setShowMobileMenu(false); }}
                      className={`p-2.5 rounded-xl text-left flex items-center gap-2 ${currentTab === 'my-bookings' ? 'bg-campus-emerald text-white font-bold' : 'bg-white/10 text-gray-200'}`}
                    >
                      <Calendar className="w-4 h-4 text-blue-300" />
                      <span>My Rides</span>
                    </button>

                    <button
                      onClick={() => { setTab('eco-score'); setShowMobileMenu(false); }}
                      className={`p-2.5 rounded-xl text-left flex items-center gap-2 ${currentTab === 'eco-score' ? 'bg-campus-emerald text-white font-bold' : 'bg-white/10 text-gray-200'}`}
                    >
                      <Leaf className="w-4 h-4 text-campus-mint" />
                      <span>Eco Score</span>
                    </button>

                    <button
                      onClick={() => { setShowKYCModal(true); setShowMobileMenu(false); }}
                      className="p-2.5 rounded-xl text-left flex items-center gap-2 bg-blue-900/40 text-blue-200 border border-blue-400/40"
                    >
                      <ShieldCheck className="w-4 h-4 text-blue-300" />
                      <span>KYC Verification</span>
                    </button>

                    <button
                      onClick={() => { setTab('emergency-rides'); setShowMobileMenu(false); }}
                      className={`p-2.5 rounded-xl text-left flex items-center gap-2 ${currentTab === 'emergency-rides' ? 'bg-campus-emerald text-white font-bold' : 'bg-white/10 text-gray-200'}`}
                    >
                      <AlertTriangle className="w-4 h-4 text-amber-400" />
                      <span>Carpool Help</span>
                    </button>
                  </>
                )}
              </>
            )}

            {isAuthenticated && isOwner && (
              <>
                <button
                  onClick={() => { setTab('owner-dashboard'); setShowMobileMenu(false); }}
                  className="p-2.5 rounded-xl text-left flex items-center gap-2 bg-campus-mint/30 text-white font-bold"
                >
                  <Building2 className="w-4 h-4 text-campus-mint" />
                  <span>Owner Fleet Portal</span>
                </button>
                <button
                  onClick={() => { setTab('live-gps'); setShowMobileMenu(false); }}
                  className="p-2.5 rounded-xl text-left flex items-center gap-2 bg-white/10 text-gray-200"
                >
                  <Navigation className="w-4 h-4 text-campus-gold" />
                  <span>Live Vehicle Map</span>
                </button>
              </>
            )}

            {isAuthenticated && isStaff && (
              <>
                <button
                  onClick={() => { setTab('staff-dashboard'); setShowMobileMenu(false); }}
                  className="p-2.5 rounded-xl text-left flex items-center gap-2 bg-blue-600/40 text-white font-bold"
                >
                  <Wrench className="w-4 h-4 text-blue-300" />
                  <span>Operations Console</span>
                </button>
                <button
                  onClick={() => { setTab('live-gps'); setShowMobileMenu(false); }}
                  className="p-2.5 rounded-xl text-left flex items-center gap-2 bg-white/10 text-gray-200"
                >
                  <Navigation className="w-4 h-4 text-campus-gold" />
                  <span>Live Fleet Radar</span>
                </button>
              </>
            )}

            {isAuthenticated && isAdmin && (
              <>
                <button
                  onClick={() => { setTab('admin-dashboard'); setShowMobileMenu(false); }}
                  className="p-2.5 rounded-xl text-left flex items-center gap-2 bg-campus-gold/30 text-white font-bold"
                >
                  <Shield className="w-4 h-4 text-campus-gold" />
                  <span>Admin Master Hub</span>
                </button>
                <button
                  onClick={() => { setTab('security-dashboard'); setShowMobileMenu(false); }}
                  className="p-2.5 rounded-xl text-left flex items-center gap-2 bg-blue-600/40 text-blue-200"
                >
                  <ShieldCheck className="w-4 h-4 text-blue-300" />
                  <span>Security Dashboard</span>
                </button>
                <button
                  onClick={() => { setTab('live-gps'); setShowMobileMenu(false); }}
                  className="p-2.5 rounded-xl text-left flex items-center gap-2 bg-white/10 text-gray-200"
                >
                  <Navigation className="w-4 h-4 text-campus-gold" />
                  <span>Live Radar</span>
                </button>
              </>
            )}

            <button
              onClick={() => { setTab('bike-lookup'); setShowMobileMenu(false); }}
              className="p-2.5 rounded-xl text-left flex items-center gap-2 bg-white/10 text-gray-200"
            >
              <Search className="w-4 h-4 text-blue-300" />
              <span>Bike Lookup</span>
            </button>
          </div>
        </div>
      )}

      {/* Unified System Health Diagnostics Modal */}
      <SystemHealthModal
        isOpen={showHealthModal}
        onClose={() => setShowHealthModal(false)}
      />

      {/* Mandatory KYC Renter Verification Modal */}
      {showKYCModal && (
        <RenterVerificationModal
          isOpen={showKYCModal}
          onClose={() => setShowKYCModal(false)}
          onSuccess={() => {
            setShowKYCModal(false);
            if (refreshUser) refreshUser();
          }}
        />
      )}
    </header>
  );
}

export default Navbar;
