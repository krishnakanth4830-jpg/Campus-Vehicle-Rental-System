import React from 'react';
import { Loader2 } from 'lucide-react';

const LoadingSpinner = ({ message = 'Loading Campus Mobility data...' }) => {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 space-y-3">
      <div className="relative flex items-center justify-center">
        <div className="w-12 h-12 rounded-full border-2 border-emerald-500/30 border-t-emerald-500 animate-spin"></div>
        <div className="absolute w-8 h-8 rounded-full overflow-hidden bg-black border border-emerald-400/40">
          <img src="/campus-mobility-logo.jpg" alt="Loading" className="w-full h-full object-contain" />
        </div>
      </div>
      <p className="text-xs font-mono font-medium text-emerald-800 animate-pulse">{message}</p>
    </div>
  );
};

export default LoadingSpinner;
