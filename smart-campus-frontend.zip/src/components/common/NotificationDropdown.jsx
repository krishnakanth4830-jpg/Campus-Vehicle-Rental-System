import React from 'react';
import { useNotifications } from '../../context/NotificationContext';
import { Bell, CheckCheck, X, Calendar, AlertTriangle, Shield, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const NotificationDropdown = ({ onClose }) => {
  const { notifications, markAsRead, markAllAsRead } = useNotifications();
  const navigate = useNavigate();

  const getIcon = (type) => {
    switch (type) {
      case 'BOOKING':
        return <Calendar className="w-4 h-4 text-blue-600" />;
      case 'RENTAL_START':
      case 'RENTAL_END':
        return <Zap className="w-4 h-4 text-emerald-600" />;
      case 'DAMAGE_REPORT':
      case 'MAINTENANCE':
        return <AlertTriangle className="w-4 h-4 text-amber-600" />;
      default:
        return <Bell className="w-4 h-4 text-slate-600" />;
    }
  };

  const handleNotificationClick = (notif) => {
    markAsRead(notif.id);
    if (notif.link_url) {
      navigate(notif.link_url);
    }
    onClose();
  };

  return (
    <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 py-3 z-50 animate-in fade-in zoom-in-95 duration-150">
      <div className="flex items-center justify-between px-4 pb-2.5 border-b border-slate-100">
        <div className="flex items-center gap-1.5">
          <Bell className="w-4 h-4 text-emerald-600" />
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Campus Alerts</h4>
        </div>
        <div className="flex items-center gap-2">
          {notifications.some((n) => !n.is_read) && (
            <button
              onClick={markAllAsRead}
              className="text-[11px] font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              Mark all read
            </button>
          )}
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
        {notifications.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-400">
            <Bell className="w-8 h-8 text-slate-300 mx-auto mb-2 opacity-50" />
            No new notifications
          </div>
        ) : (
          notifications.map((notif) => (
            <div
              key={notif.id}
              onClick={() => handleNotificationClick(notif)}
              className={`px-4 py-3 cursor-pointer transition-colors flex items-start gap-3 hover:bg-slate-50 ${
                !notif.is_read ? 'bg-emerald-50/40' : ''
              }`}
            >
              <div className="p-2 rounded-xl bg-slate-100 shrink-0 mt-0.5">
                {getIcon(notif.notification_type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1 mb-0.5">
                  <p className="text-xs font-bold text-slate-900 truncate">{notif.title}</p>
                  {!notif.is_read && (
                    <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  )}
                </div>
                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">{notif.message}</p>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  {new Date(notif.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default NotificationDropdown;
