import React, { useState, useEffect } from 'react';

export function SplashScreen({ onFinish }) {
  const [progress, setProgress] = useState(0);
  const [statusIndex, setStatusIndex] = useState(0);
  const [isFadingOut, setIsFadingOut] = useState(false);

  const statusMessages = [
    'INITIALIZING CAMPUS MOBILITY KERNEL v2.4...',
    'SYNCING GNSS & REAL-TIME TELEMETRY...',
    'CONNECTING CAMPUS GEOFENCE RADAR...',
    'ESTABLISHING ENCRYPTED FLEET LINK...',
    'SYSTEM READY • LAUNCHING DASHBOARD'
  ];

  useEffect(() => {
    // Progress interval (reaches 100% in ~1.9s)
    const startTime = Date.now();
    const duration = 1900;

    const progressTimer = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const currentPct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(currentPct);

      // Cycle status message based on percentage
      const msgIdx = Math.min(
        statusMessages.length - 1,
        Math.floor((currentPct / 100) * statusMessages.length)
      );
      setStatusIndex(msgIdx);

      if (currentPct >= 100) {
        clearInterval(progressTimer);
        // Begin smooth fade out
        setTimeout(() => {
          setIsFadingOut(true);
          setTimeout(() => {
            if (onFinish) onFinish();
          }, 500);
        }, 250);
      }
    }, 30);

    return () => clearInterval(progressTimer);
  }, [onFinish]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 text-white overflow-hidden transition-opacity duration-500 ease-out select-none ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background Futuristic Grid & Ambient Glow */}
      <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px] opacity-15"></div>
      <div className="absolute w-96 h-96 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none animate-pulse"></div>
      <div className="absolute w-64 h-64 rounded-full bg-cyan-500/10 blur-2xl pointer-events-none"></div>

      <div className="relative z-10 flex flex-col items-center max-w-sm w-full px-6 space-y-6 text-center">
        
        {/* Centered Campus Mobility Logo with Futuristic Pulse Rings */}
        <div className="relative flex items-center justify-center">
          
          {/* Outer Rotating Radar Rings */}
          <div className="absolute w-36 h-36 rounded-full border border-emerald-500/30 border-t-emerald-400 animate-spin" style={{ animationDuration: '4s' }}></div>
          <div className="absolute w-44 h-44 rounded-full border border-dashed border-emerald-500/20 animate-spin" style={{ animationDuration: '10s', animationDirection: 'reverse' }}></div>
          <div className="absolute w-28 h-28 rounded-full bg-emerald-500/20 blur-xl animate-ping" style={{ animationDuration: '2.5s' }}></div>

          {/* Centered Logo Container */}
          <div className="relative w-28 h-28 rounded-full bg-black border-2 border-emerald-400/80 shadow-[0_0_35px_rgba(16,185,129,0.35)] overflow-hidden flex items-center justify-center">
            <img
              src="/campus-mobility-logo.jpg"
              alt="Campus Mobility Logo"
              className="w-full h-full object-contain transform transition-transform duration-700 hover:scale-105"
            />
          </div>
        </div>

        {/* Brand Titles */}
        <div className="space-y-1">
          <div className="flex items-center justify-center gap-2">
            <span className="h-0.5 w-6 bg-gradient-to-r from-transparent to-emerald-400"></span>
            <h1 className="text-2xl font-black tracking-widest text-white font-display uppercase drop-shadow">
              CAMPUS<span className="text-emerald-400"> MOBILITY</span>
            </h1>
            <span className="h-0.5 w-6 bg-gradient-to-l from-transparent to-emerald-400"></span>
          </div>
          <p className="text-[11px] font-mono tracking-widest text-emerald-300/80 uppercase font-semibold">
            SMART TRANSIT & TELEMETRY SYSTEM
          </p>
        </div>

        {/* Futuristic Telemetry Progress Bar & Status */}
        <div className="w-full space-y-2 pt-2">
          
          {/* Progress Bar */}
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden p-0.5 border border-emerald-500/30 shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 rounded-full transition-all duration-100 ease-out shadow-[0_0_10px_#10b981]"
              style={{ width: `${progress}%` }}
            ></div>
          </div>

          {/* Status readout & Percentage */}
          <div className="flex items-center justify-between text-[10px] font-mono text-gray-400">
            <span className="flex items-center gap-1.5 text-emerald-400/90 font-medium">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
              <span>{statusMessages[statusIndex]}</span>
            </span>
            <span className="font-bold text-white tracking-wider">{progress}%</span>
          </div>
        </div>

        {/* Quick Click to Skip */}
        <button
          onClick={() => {
            setIsFadingOut(true);
            setTimeout(() => {
              if (onFinish) onFinish();
            }, 300);
          }}
          className="text-[10px] font-mono text-gray-500 hover:text-emerald-400 transition tracking-widest uppercase pt-2"
        >
          [ Click to Skip ]
        </button>

      </div>
    </div>
  );
}

export default SplashScreen;
