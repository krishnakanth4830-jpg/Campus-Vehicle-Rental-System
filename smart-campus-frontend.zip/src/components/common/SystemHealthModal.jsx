import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { 
  Activity, CheckCircle2, Radio, Sparkles, Server, 
  RefreshCw, X, Shield, ChevronRight, ExternalLink, Database 
} from 'lucide-react';
import { apiRequest } from '../../api/client';

export function SystemHealthModal({ isOpen, onClose }) {
  const [healthData, setHealthData] = useState({
    frontend: { status: 'ONLINE', latency: '0ms', version: '2.0.0' },
    backend: { status: 'CHECKING', latency: '...', service: '', database: '' },
    gps: { status: 'CHECKING', total_vehicles: 0, moving: 0 },
    ai: { status: 'CHECKING', model: 'AURA-NLP-v2.4' }
  });
  const [activeJsonTab, setActiveJsonTab] = useState('health');
  const [rawJson, setRawJson] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isOpen) {
      const handleKeyDown = (e) => {
        if (e.key === 'Escape') onClose();
      };
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = 'auto';
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [isOpen, onClose]);

  const checkAllServices = async () => {
    setLoading(true);
    const startTime = performance.now();

    try {
      // 1. Backend Health
      const bRes = await apiRequest('/health');
      const bLatency = Math.round(performance.now() - startTime);

      // 2. GPS Telemetry
      const gRes = await apiRequest('/gps/live-fleet');

      // 3. AI Copilot Ping
      const aiRes = await apiRequest('/ai/predict-demand');

      setHealthData({
        frontend: { status: 'ONLINE', latency: '1ms', version: '2.0.0 React SPA' },
        backend: {
          status: bRes.status === 'online' ? 'ONLINE' : 'DEGRADED',
          latency: `${bLatency}ms`,
          service: bRes.service || 'Flask REST API',
          database: bRes.database || 'Connected'
        },
        gps: {
          status: gRes.success ? 'ONLINE' : 'DEGRADED',
          total_vehicles: gRes.total_vehicles || 20,
          moving: gRes.moving_vehicles || 0
        },
        ai: {
          status: aiRes.success ? 'ONLINE' : 'DEGRADED',
          model: aiRes.model_version || 'AURA-FleetDemand-v2.4'
        }
      });

      if (activeJsonTab === 'health') setRawJson(bRes);
      else if (activeJsonTab === 'gps') setRawJson(gRes);
      else if (activeJsonTab === 'ai') setRawJson(aiRes);

    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      checkAllServices();
    }
  }, [isOpen, activeJsonTab]);

  if (!isOpen) return null;

  const modalContent = (
    <div 
      className="fixed inset-0 z-[9999] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="bg-white rounded-3xl max-w-2xl w-full border border-campus-border/80 shadow-2xl overflow-hidden flex flex-col max-h-[90vh] my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Top Header */}
        <div className="p-5 bg-gradient-to-r from-campus-forest via-emerald-950 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-campus-emerald/60 flex items-center justify-center border border-campus-mint/40">
              <Activity className="w-5 h-5 text-campus-mint animate-pulse" />
            </div>
            <div>
              <div className="font-extrabold text-sm tracking-wide font-display flex items-center gap-2">
                <span>ALL-IN-ONE SYSTEM & API MONITOR</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              </div>
              <p className="text-[11px] text-gray-300 font-mono">Unified Real-Time Architecture Diagnostics</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-gray-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 4 Core Combined Services Cards */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1 text-xs">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            {/* 1. Frontend Web App */}
            <div className="p-4 bg-campus-sand/20 border border-campus-border/70 rounded-2xl space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-campus-forest text-xs flex items-center gap-1.5">
                  <Server className="w-4 h-4 text-blue-600" />
                  <span>Frontend Web App</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-emerald-100 text-emerald-800">
                  {healthData.frontend.status}
                </span>
              </div>
              <p className="text-[11px] text-gray-500">React 18 SPA + Vite + Tailwind CSS</p>
              <div className="text-[10px] font-mono text-gray-600 flex justify-between pt-1 border-t border-gray-100">
                <span>Latency: {healthData.frontend.latency}</span>
                <span className="text-blue-700 font-bold">Port 5000 / 5173</span>
              </div>
            </div>

            {/* 2. Flask REST API Core */}
            <div className="p-4 bg-campus-sand/20 border border-campus-border/70 rounded-2xl space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-campus-forest text-xs flex items-center gap-1.5">
                  <Database className="w-4 h-4 text-campus-emerald" />
                  <span>Flask REST API Core</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-emerald-100 text-emerald-800">
                  {healthData.backend.status}
                </span>
              </div>
              <p className="text-[11px] text-gray-500">Python 3.12 + SQLAlchemy + JWT</p>
              <div className="text-[10px] font-mono text-gray-600 flex justify-between pt-1 border-t border-gray-100">
                <span>Ping: {healthData.backend.latency}</span>
                <span className="text-emerald-700 font-bold">DB: Connected</span>
              </div>
            </div>

            {/* 3. Live GPS Telemetry */}
            <div className="p-4 bg-campus-sand/20 border border-campus-border/70 rounded-2xl space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-campus-forest text-xs flex items-center gap-1.5">
                  <Radio className="w-4 h-4 text-purple-600" />
                  <span>Live GPS Telemetry</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-emerald-100 text-emerald-800">
                  {healthData.gps.status}
                </span>
              </div>
              <p className="text-[11px] text-gray-500">DGPS RTK • 12 GNSS Satellites Lock</p>
              <div className="text-[10px] font-mono text-gray-600 flex justify-between pt-1 border-t border-gray-100">
                <span>Fleet: {healthData.gps.total_vehicles} Units Tracked</span>
                <span className="text-purple-700 font-bold">Geofence: 1.5km</span>
              </div>
            </div>

            {/* 4. AURA AI Copilot */}
            <div className="p-4 bg-campus-sand/20 border border-campus-border/70 rounded-2xl space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-campus-forest text-xs flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-campus-gold" />
                  <span>AURA AI Copilot Model</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-emerald-100 text-emerald-800">
                  {healthData.ai.status}
                </span>
              </div>
              <p className="text-[11px] text-gray-500">NLP Intent Parser & Fleet Demand Model</p>
              <div className="text-[10px] font-mono text-gray-600 flex justify-between pt-1 border-t border-gray-100">
                <span>Model: {healthData.ai.model}</span>
                <span className="text-amber-700 font-bold">Real-time NLP</span>
              </div>
            </div>

          </div>

          {/* Live Raw JSON Response Viewer */}
          <div className="bg-slate-900 text-gray-200 rounded-2xl p-3.5 space-y-2 border border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex gap-2">
                {[
                  { id: 'health', label: 'API Health' },
                  { id: 'gps', label: 'Live GPS Data' },
                  { id: 'ai', label: 'AI Demand Forecast' }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveJsonTab(tab.id)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold font-mono transition ${
                      activeJsonTab === tab.id ? 'bg-campus-emerald text-white' : 'bg-slate-800 text-gray-400 hover:text-white'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <button
                onClick={checkAllServices}
                className="text-[10px] font-mono text-campus-mint hover:underline flex items-center gap-1"
              >
                <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
                <span>Re-Test</span>
              </button>
            </div>

            <pre className="text-[10px] font-mono text-emerald-400 max-h-40 overflow-y-auto p-2 bg-black/40 rounded-xl">
              {rawJson ? JSON.stringify(rawJson, null, 2) : 'Loading live API response...'}
            </pre>
          </div>

        </div>

        {/* Footer */}
        <div className="p-3.5 bg-campus-sand/30 border-t border-campus-border/60 flex items-center justify-between text-xs">
          <span className="text-gray-500 text-[11px]">All 4 sub-services unified into one single platform</span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-campus-forest hover:bg-campus-emerald text-white rounded-xl font-bold text-xs shadow transition"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalContent, document.body) : null;
}
