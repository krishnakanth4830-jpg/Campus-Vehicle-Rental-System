import React from 'react';
import { Clock, BarChart2 } from 'lucide-react';

const VehicleDemandChart = ({ peakHours = [] }) => {
  const maxBookings = Math.max(...peakHours.map((h) => h.bookings || 0), 1);

  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-emerald-600" />
            24-Hour Campus Booking Demand Curve
          </h3>
          <p className="text-xs text-slate-500">Hourly student & staff rental load distribution</p>
        </div>
      </div>

      {/* Hourly Bar Histogram */}
      <div className="pt-6 pb-2">
        <div className="h-44 flex items-end gap-1.5 sm:gap-2">
          {peakHours.map((item) => {
            const heightPercent = Math.max(8, (item.bookings / maxBookings) * 100);
            const isPeak = item.bookings === maxBookings && maxBookings > 0;

            return (
              <div key={item.hour_num} className="flex-1 flex flex-col items-center gap-1 group relative h-full justify-end">
                
                {/* Tooltip on hover */}
                <div className="absolute -top-9 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 text-white text-[10px] font-bold px-2 py-1 rounded-lg pointer-events-none z-10 whitespace-nowrap shadow-lg">
                  {item.hour}: {item.bookings} bookings
                </div>

                {/* Bar */}
                <div
                  className={`w-full rounded-t-lg transition-all duration-300 ${
                    isPeak
                      ? 'bg-gradient-to-t from-emerald-600 to-teal-400 shadow-md shadow-emerald-500/20'
                      : item.bookings > 0
                      ? 'bg-emerald-500/70 hover:bg-emerald-600'
                      : 'bg-slate-100'
                  }`}
                  style={{ height: `${heightPercent}%` }}
                />

                {/* Hour Label */}
                <span className="text-[9px] text-slate-400 font-mono mt-1 scale-90">
                  {item.hour_num % 3 === 0 ? item.hour.split(':')[0] : ''}
                </span>
              </div>
            );
          })}
        </div>
        <div className="flex justify-between text-[10px] text-slate-400 pt-2 border-t border-slate-100">
          <span>00:00 (Midnight)</span>
          <span>08:00 (Morning Rush)</span>
          <span>13:00 (Off-Peak)</span>
          <span>17:00 (Evening Rush)</span>
          <span>23:00</span>
        </div>
      </div>
    </div>
  );
};

export default VehicleDemandChart;
