import React from 'react';
import { MapPin, TrendingUp, TrendingDown, Repeat, ArrowRight } from 'lucide-react';

const ZoneHeatmapVisualization = ({ heatmapData = [], recentMovements = [] }) => {
  return (
    <div className="space-y-6">
      {/* Zone Demand Matrix */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <MapPin className="w-4 h-4 text-emerald-600" />
            Campus Zone Demand & Redistribution Heatmap
          </h3>
          <p className="text-xs text-slate-500">Live fleet distribution, pickup load, and net vehicle influx</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {heatmapData.map((z) => {
            const isHighDemand = z.demand_level === 'HIGH';
            const isNetDeficit = z.net_flow < 0;

            return (
              <div
                key={z.zone_id}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50/70 space-y-3 relative overflow-hidden"
              >
                {/* Demand Level Indicator */}
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-800">
                    {z.code}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      isHighDemand
                        ? 'bg-rose-100 text-rose-800'
                        : z.demand_level === 'MEDIUM'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {z.demand_level} DEMAND
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-slate-900">{z.name}</h4>
                  <p className="text-xs text-slate-500">
                    {z.available_vehicles} Available / {z.current_vehicles} Stationed (Cap: {z.capacity})
                  </p>
                </div>

                {/* Flow statistics */}
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Pickups</span>
                    <span className="font-bold text-slate-800">{z.pickup_count} trips</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Returns</span>
                    <span className="font-bold text-slate-800">{z.return_count} trips</span>
                  </div>
                </div>

                {/* Net Movement Flow */}
                <div className="flex items-center justify-between text-xs pt-1">
                  <span className="text-slate-500 text-[11px]">Net Fleet Influx:</span>
                  <span
                    className={`font-bold flex items-center gap-1 ${
                      z.net_flow > 0
                        ? 'text-emerald-600'
                        : z.net_flow < 0
                        ? 'text-rose-600'
                        : 'text-slate-600'
                    }`}
                  >
                    {z.net_flow > 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                    {z.net_flow > 0 ? `+${z.net_flow}` : z.net_flow} vehicles
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Vehicle Movements Flux Log */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Repeat className="w-4 h-4 text-blue-600" />
            Live Return-to-Pool Movement Stream
          </h3>
          <p className="text-xs text-slate-500">Real-time vehicle redistribution events across campus</p>
        </div>

        <div className="divide-y divide-slate-100 max-h-60 overflow-y-auto">
          {recentMovements.length === 0 ? (
            <p className="py-6 text-center text-xs text-slate-400">No recorded movements yet.</p>
          ) : (
            recentMovements.map((m) => (
              <div key={m.id} className="py-3 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-blue-50 text-blue-700 font-mono font-bold text-[10px]">
                    {m.vehicle_number}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5 font-bold text-slate-800">
                      <span>{m.from_zone_name}</span>
                      <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                      <span className="text-emerald-700">{m.to_zone_name}</span>
                    </div>
                    <span className="text-[10px] text-slate-400 uppercase font-medium">{m.movement_type.replace('_', ' ')}</span>
                  </div>
                </div>

                <span className="text-[11px] text-slate-400">
                  {new Date(m.recorded_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default ZoneHeatmapVisualization;
