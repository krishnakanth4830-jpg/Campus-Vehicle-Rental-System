import React from 'react';
import { Leaf, Award, Zap, Fuel, Trees } from 'lucide-react';
import { Link } from 'react-router-dom';

const EcoScoreCard = ({ ecoStats }) => {
  const userStats = ecoStats?.user_stats || {
    eco_score: 0,
    trips_count: 0,
    distance_km: 0,
    co2_saved_kg: 0,
    petrol_saved_litres: 0,
  };

  const treesOffset = (userStats.co2_saved_kg / 21.77).toFixed(2);

  return (
    <div className="bg-gradient-to-br from-emerald-800 via-teal-900 to-slate-900 text-white p-6 rounded-3xl shadow-xl relative overflow-hidden">
      {/* Background Graphic Effect */}
      <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-emerald-500/10 rounded-full blur-2xl" />

      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2.5 bg-emerald-500/20 backdrop-blur-md rounded-2xl text-emerald-400 border border-emerald-500/30">
            <Leaf className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold tracking-tight">Your Green Mobility Impact</h3>
            <p className="text-[11px] text-emerald-300">Clean Campus Commute</p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-2xl font-black text-emerald-400 leading-none">
            {userStats.eco_score}
          </span>
          <p className="text-[10px] text-emerald-200 uppercase font-bold tracking-wider">Eco Score Pts</p>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-3 gap-3 my-5">
        <div className="bg-white/10 backdrop-blur-md p-3 rounded-2xl border border-white/10 text-center">
          <p className="text-base font-black text-white">{userStats.co2_saved_kg} kg</p>
          <p className="text-[10px] text-emerald-200 font-medium mt-0.5">CO₂ Offset</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md p-3 rounded-2xl border border-white/10 text-center">
          <p className="text-base font-black text-white">{userStats.distance_km} km</p>
          <p className="text-[10px] text-emerald-200 font-medium mt-0.5">Clean Travel</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md p-3 rounded-2xl border border-white/10 text-center">
          <p className="text-base font-black text-white">{userStats.trips_count}</p>
          <p className="text-[10px] text-emerald-200 font-medium mt-0.5">Green Trips</p>
        </div>
      </div>

      {/* Sustainability equivalency banner */}
      <div className="flex items-center justify-between pt-3 border-t border-white/10 text-xs">
        <div className="flex items-center gap-1.5 text-emerald-300 text-[11px]">
          <Trees className="w-4 h-4 text-emerald-400" />
          <span>Equiv. to ~{treesOffset} trees absorbing carbon!</span>
        </div>

        <Link
          to="/eco"
          className="text-[11px] font-bold text-white hover:text-emerald-300 underline underline-offset-2"
        >
          View Leaderboard →
        </Link>
      </div>
    </div>
  );
};

export default EcoScoreCard;
