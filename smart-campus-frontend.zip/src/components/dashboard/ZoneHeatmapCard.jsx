import React from 'react';
import { MapPin, Bike, Navigation, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const ZoneHeatmapCard = ({ zones = [] }) => {
  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-emerald-600" />
            Campus Mobility Hubs & Availability
          </h3>
          <p className="text-xs text-slate-500">Real-time stationed vehicles across campus zones</p>
        </div>

        <Link
          to="/vehicles"
          className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
        >
          View Map <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {zones.map((zone) => {
          const occupancy = zone.occupancy_pct || 0;
          const isHighAvailability = zone.available_vehicles > 3;

          return (
            <div
              key={zone.id}
              className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/70 hover:bg-emerald-50/50 hover:border-emerald-200 transition-all space-y-2 group"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-slate-200 text-slate-700">
                  {zone.code}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    isHighAvailability
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {zone.available_vehicles} Available
                </span>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-900 group-hover:text-emerald-800 truncate">
                  {zone.name}
                </h4>
                <p className="text-[10px] text-slate-500">Cap: {zone.capacity} vehicles</p>
              </div>

              {/* Occupancy bar */}
              <div className="space-y-1">
                <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      occupancy > 80
                        ? 'bg-rose-500'
                        : occupancy > 50
                        ? 'bg-emerald-500'
                        : 'bg-blue-500'
                    }`}
                    style={{ width: `${Math.min(100, occupancy)}%` }}
                  />
                </div>
                <div className="flex justify-between text-[9px] text-slate-400">
                  <span>Occupancy</span>
                  <span>{occupancy}%</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ZoneHeatmapCard;
