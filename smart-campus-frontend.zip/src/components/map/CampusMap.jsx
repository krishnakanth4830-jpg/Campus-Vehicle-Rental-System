import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet';
import L from 'leaflet';
import { MapPin, Bike, Zap, Users } from 'lucide-react';

// Custom Map Marker Icon
const createCustomIcon = (color = '#133e2b', availableCount = 0) => {
  return L.divIcon({
    className: 'custom-hub-pin',
    html: `
      <div style="
        background: ${color};
        color: white;
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border: 3px solid #ffffff;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        font-weight: 800;
        font-size: 13px;
        font-family: sans-serif;
      ">
        ${availableCount}
      </div>
    `,
    iconSize: [38, 38],
    iconAnchor: [19, 19],
    popupAnchor: [0, -20]
  });
};

export function CampusMap({ zones = [], selectedZoneId, onSelectZone }) {
  const defaultCenter = [10.9385, 76.9558]; // SKCET Coimbatore campus center

  return (
    <div className="bg-white rounded-3xl border border-campus-border/80 shadow-md overflow-hidden flex flex-col h-[480px]">
      
      {/* Map Header */}
      <div className="p-4 bg-campus-forest text-white flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MapPin className="w-4 h-4 text-campus-gold" />
          <span className="font-extrabold text-xs font-display tracking-wide">
            LIVE CAMPUS MOBILITY ZONES
          </span>
        </div>
        <span className="text-[10px] text-campus-mint font-semibold bg-campus-emerald/60 px-2.5 py-0.5 rounded-full border border-campus-mint/30">
          6 Active Hubs Connected
        </span>
      </div>

      {/* Leaflet Map Frame */}
      <div className="flex-1 relative z-0">
        <MapContainer
          center={defaultCenter}
          zoom={16}
          scrollWheelZoom={false}
          className="h-full w-full"
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          {zones.map((zone) => {
            const isSelected = selectedZoneId === zone.id;
            const available = zone.available_vehicles || 0;
            const pinColor = available > 3 ? '#133e2b' : available > 0 ? '#d97706' : '#991b1b';

            return (
              <React.Fragment key={zone.id}>
                {/* Zone Coverage Circle */}
                <Circle
                  center={[zone.latitude, zone.longitude]}
                  radius={60}
                  pathOptions={{
                    fillColor: pinColor,
                    fillOpacity: isSelected ? 0.25 : 0.12,
                    color: pinColor,
                    weight: isSelected ? 3 : 1
                  }}
                />

                {/* Zone Marker */}
                <Marker
                  position={[zone.latitude, zone.longitude]}
                  icon={createCustomIcon(pinColor, available)}
                  eventHandlers={{
                    click: () => onSelectZone && onSelectZone(zone)
                  }}
                >
                  <Popup>
                    <div className="p-1 space-y-1 text-xs">
                      <div className="font-extrabold text-campus-forest">{zone.name}</div>
                      <p className="text-[11px] text-gray-500">{zone.description}</p>
                      <div className="flex justify-between font-bold pt-1 border-t border-gray-100 text-campus-emerald">
                        <span>Available Fleet:</span>
                        <span>{available} / {zone.capacity}</span>
                      </div>
                      {onSelectZone && (
                        <button
                          onClick={() => onSelectZone(zone)}
                          className="w-full mt-2 py-1 px-2 bg-campus-forest text-white rounded-lg text-[10px] font-bold"
                        >
                          Filter Vehicles Here
                        </button>
                      )}
                    </div>
                  </Popup>
                </Marker>
              </React.Fragment>
            );
          })}
        </MapContainer>
      </div>

      {/* Map Legend */}
      <div className="p-2.5 bg-campus-cream border-t border-campus-border/60 flex items-center justify-around text-[10px] font-semibold text-gray-600">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-campus-forest inline-block"></span>
          <span>Ample Vehicles (4+)</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-600 inline-block"></span>
          <span>Limited Fleet (1-3)</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-red-700 inline-block"></span>
          <span>Zone Empty (0)</span>
        </div>
      </div>

    </div>
  );
}
