import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import { 
  Navigation, Radio, Zap, Fuel, Shield, MapPin, Gauge, Play, Pause, 
  RefreshCw, Compass, AlertCircle, Sparkles, GraduationCap, ChevronRight,
  Crosshair, Flag, CheckCircle2, AlertTriangle, ArrowRight, CornerUpRight, RotateCcw, X
} from 'lucide-react';
import { apiRequest } from '../../api/client';
import { useGeolocation } from '../../hooks/useGeolocation';
import { 
  fetchNavigationRoute, 
  calculateDistanceMeters, 
  calculateDistanceToPolyline 
} from '../../utils/navigationService';

// Controller to smoothly fit bounds, fly to user location, or center on target area
function MapController({ 
  selectedCollege, 
  zones = [], 
  selectedVehicleId, 
  fleetGPS = [], 
  userLocation, 
  recenterTrigger, 
  destination,
  routeCoordinates 
}) {
  const map = useMap();
  const lastCollegeRef = useRef(null);
  const lastVehicleRef = useRef(null);
  const lastRecenterRef = useRef(0);

  // 1. Recenter on user's real GPS position
  useEffect(() => {
    if (!map || !userLocation || recenterTrigger === lastRecenterRef.current) return;
    lastRecenterRef.current = recenterTrigger;
    map.flyTo([userLocation.latitude, userLocation.longitude], 17, { duration: 1.2 });
  }, [recenterTrigger, userLocation, map]);

  // 2. Fit bounds to active navigation route
  useEffect(() => {
    if (!map || !routeCoordinates || routeCoordinates.length < 2) return;
    try {
      const bounds = L.latLngBounds(routeCoordinates);
      map.fitBounds(bounds, { padding: [60, 60], maxZoom: 17, animate: true });
    } catch (e) {
      console.warn("Could not fit route bounds:", e);
    }
  }, [routeCoordinates, map]);

  // 3. Single vehicle focus
  useEffect(() => {
    if (!map || !selectedVehicleId || selectedVehicleId === lastVehicleRef.current) return;
    lastVehicleRef.current = selectedVehicleId;
    const targetVeh = fleetGPS.find(v => v.id === selectedVehicleId);
    if (targetVeh && targetVeh.latitude && targetVeh.longitude) {
      map.flyTo([targetVeh.latitude, targetVeh.longitude], 17, { duration: 1.0 });
    }
  }, [selectedVehicleId, fleetGPS, map]);

  // 4. College selection change
  useEffect(() => {
    if (!map || selectedCollege === lastCollegeRef.current) return;
    lastCollegeRef.current = selectedCollege;

    if (selectedCollege) {
      const collegeZones = zones.filter(z => z.college_name === selectedCollege && z.latitude && z.longitude);
      if (collegeZones.length > 1) {
        const bounds = L.latLngBounds(collegeZones.map(z => [z.latitude, z.longitude]));
        map.fitBounds(bounds, { padding: [50, 50], maxZoom: 16, animate: true, duration: 1.0 });
      } else if (collegeZones.length === 1) {
        map.flyTo([collegeZones[0].latitude, collegeZones[0].longitude], 16, { duration: 1.0 });
      }
    } else if (zones.length > 0) {
      const validCoords = zones.filter(z => z.latitude && z.longitude).map(z => [z.latitude, z.longitude]);
      if (validCoords.length > 0) {
        const allBounds = L.latLngBounds(validCoords);
        map.fitBounds(allBounds, { padding: [50, 50], maxZoom: 14, animate: true, duration: 1.0 });
      }
    }
  }, [selectedCollege, zones, map]);

  return null;
}

// User Real GPS Location Marker Icon Generator
const createUserLocationIcon = (heading = 0) => {
  return L.divIcon({
    className: 'custom-user-gps-pin',
    html: `
      <div style="position: relative; width: 48px; height: 48px; display: flex; align-items: center; justify-content: center;">
        <!-- Pulsing Aura Ring -->
        <div class="user-gps-pulse-disk" style="
          position: absolute;
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: rgba(37, 99, 235, 0.4);
        "></div>

        <!-- Solid Center Beacon with Heading Indicator -->
        <div style="
          background: #2563EB;
          color: white;
          width: 22px;
          height: 22px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 3px solid #ffffff;
          box-shadow: 0 2px 10px rgba(0,0,0,0.5);
          position: relative;
          z-index: 2;
        ">
          <!-- Direction Arrow -->
          <div style="
            width: 0;
            height: 0;
            border-left: 4px solid transparent;
            border-right: 4px solid transparent;
            border-bottom: 7px solid white;
            transform: rotate(${heading || 0}deg);
            transform-origin: center;
          "></div>
        </div>
      </div>
    `,
    iconSize: [48, 48],
    iconAnchor: [24, 24],
    popupAnchor: [0, -20]
  });
};

// Destination Flag Marker Icon
const createDestinationIcon = (title = 'Destination') => {
  return L.divIcon({
    className: 'custom-destination-pin',
    html: `
      <div style="position: relative; display: flex; flex-direction: column; align-items: center;">
        <div style="
          background: #dc2626;
          color: white;
          padding: 4px 8px;
          border-radius: 12px;
          font-size: 11px;
          font-weight: 800;
          font-family: sans-serif;
          box-shadow: 0 4px 12px rgba(0,0,0,0.35);
          border: 2px solid white;
          display: flex;
          align-items: center;
          gap: 3px;
          white-space: nowrap;
        ">
          <span>🏁</span>
          <span>${title}</span>
        </div>
        <div style="
          width: 0;
          height: 0;
          border-left: 6px solid transparent;
          border-right: 6px solid transparent;
          border-top: 8px solid #dc2626;
        "></div>
      </div>
    `,
    iconSize: [80, 40],
    iconAnchor: [40, 40],
    popupAnchor: [0, -38]
  });
};

// Vehicle Category Marker Icon Generator
const createVehicleGPSIcon = (vehicle) => {
  const isMoving = vehicle.is_moving || (vehicle.speed_kmh && vehicle.speed_kmh > 0);
  const isInUse = vehicle.status === 'IN_USE';
  const heading = Math.round(vehicle.heading_degrees || 0);
  
  const iconEmoji = vehicle.category === 'CRUISER' ? '🦅' :
                    vehicle.category === 'MOTORCYCLE' ? '🏍️' :
                    vehicle.category === 'CAR' ? '🚗' : '🛵';

  const badgeColor = isInUse ? '#2563eb' : (isMoving ? '#059669' : '#0f172a');

  return L.divIcon({
    className: 'custom-vehicle-gps-pin',
    html: `
      <div style="position: relative; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;">
        ${isMoving ? '<div class="gps-pulse-ring"></div>' : ''}
        
        <div style="
          background: ${badgeColor};
          color: white;
          width: 36px;
          height: 36px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 2.5px solid #ffffff;
          box-shadow: 0 4px 14px rgba(0,0,0,0.35);
          font-size: 16px;
          position: relative;
          z-index: 2;
        ">
          ${iconEmoji}
        </div>

        <div style="
          position: absolute;
          top: -6px;
          left: 50%;
          transform: translateX(-50%) rotate(${heading}deg);
          transform-origin: 50% 28px;
          width: 0; 
          height: 0; 
          border-left: 5px solid transparent;
          border-right: 5px solid transparent;
          border-bottom: 9px solid ${badgeColor};
          z-index: 1;
        "></div>

        ${isMoving ? `
          <div style="
            position: absolute;
            bottom: -8px;
            background: #0f172a;
            color: #38bdf8;
            font-size: 8px;
            font-weight: 900;
            padding: 1px 5px;
            border-radius: 6px;
            border: 1px solid rgba(56,189,248,0.4);
            white-space: nowrap;
            z-index: 3;
            box-shadow: 0 2px 6px rgba(0,0,0,0.4);
          ">
            ${Math.round(vehicle.speed_kmh)} km/h
          </div>
        ` : ''}
      </div>
    `,
    iconSize: [44, 44],
    iconAnchor: [22, 22],
    popupAnchor: [0, -22]
  });
};

// Campus Zone Hub Marker Icon
const createHubIcon = (zone, availableCount = 0) => {
  const pinColor = availableCount > 3 ? '#0f172a' : availableCount > 0 ? '#d97706' : '#64748b';
  return L.divIcon({
    className: 'custom-hub-gps-pin',
    html: `
      <div style="
        background: ${pinColor};
        color: white;
        min-width: 32px;
        height: 32px;
        padding: 0 6px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 3px;
        border: 2.5px solid #ffffff;
        box-shadow: 0 4px 10px rgba(0,0,0,0.25);
        font-weight: 800;
        font-size: 11px;
        font-family: sans-serif;
      ">
        <span>📍</span>
        <span>${availableCount}</span>
      </div>
    `,
    iconSize: [32, 32],
    iconAnchor: [16, 16],
    popupAnchor: [0, -18]
  });
};

// Stable Animated Vehicle Marker
function AnimatedVehicleMarker({ vehicle, onSelectBooking, onSetDestination }) {
  const markerRef = useRef(null);

  const icon = useMemo(() => {
    return createVehicleGPSIcon(vehicle);
  }, [
    vehicle.category,
    vehicle.status,
    vehicle.is_moving,
    Math.round((vehicle.speed_kmh || 0) / 2),
    Math.round((vehicle.heading_degrees || 0) / 15)
  ]);

  useEffect(() => {
    if (markerRef.current && vehicle.latitude && vehicle.longitude) {
      markerRef.current.setLatLng([vehicle.latitude, vehicle.longitude]);
    }
  }, [vehicle.latitude, vehicle.longitude]);

  return (
    <Marker
      ref={markerRef}
      position={[vehicle.latitude, vehicle.longitude]}
      icon={icon}
    >
      <Popup>
        <div className="p-2 space-y-2 text-xs min-w-[210px]">
          <div className="flex items-center justify-between border-b pb-1">
            <span className="font-mono font-black text-xs text-campus-forest">
              {vehicle.vehicle_number}
            </span>
            <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
              vehicle.status === 'AVAILABLE' ? 'bg-emerald-100 text-emerald-800' :
              vehicle.status === 'IN_USE' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
            }`}>
              {vehicle.status}
            </span>
          </div>

          <div>
            <div className="font-extrabold text-sm text-gray-900">{vehicle.brand} {vehicle.model}</div>
            <div className="text-[10px] text-gray-500 font-medium truncate">{vehicle.college_name} • {vehicle.city}</div>
            <div className="text-[11px] text-gray-700 mt-0.5">
              <span className="text-gray-400">Owner:</span> <strong className="text-gray-800">{vehicle.owner_name || 'Campus Host'}</strong>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-1.5 bg-campus-sand/40 p-2 rounded-xl text-[11px]">
            <div className="flex items-center gap-1">
              <Gauge className="w-3 h-3 text-campus-emerald" />
              <span className="font-bold font-mono">{Math.round(vehicle.speed_kmh || 0)} km/h</span>
            </div>
            <div className="flex items-center gap-1">
              <Fuel className="w-3 h-3 text-campus-forest" />
              <span className="font-bold">⛽ {vehicle.fuel_level_percentage || 85}%</span>
            </div>
            <div className="flex items-center gap-1">
              <Compass className="w-3 h-3 text-indigo-600" />
              <span className="font-mono font-bold">{Math.round(vehicle.heading_degrees || 0)}° Heading</span>
            </div>
            <div className="flex items-center gap-1">
              <Shield className="w-3 h-3 text-campus-emerald" />
              <span className="font-bold text-[10px] text-emerald-700">Inside Campus</span>
            </div>
          </div>

          <div className="space-y-1 pt-1">
            {vehicle.status === 'AVAILABLE' && onSelectBooking && (
              <button
                onClick={() => onSelectBooking(vehicle)}
                className="w-full py-1.5 bg-campus-forest hover:bg-campus-emerald text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 shadow"
              >
                <span>Book This Vehicle</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}

            {onSetDestination && (
              <button
                onClick={() => onSetDestination({
                  latitude: vehicle.latitude,
                  longitude: vehicle.longitude,
                  name: `${vehicle.brand} ${vehicle.model} (${vehicle.vehicle_number})`
                })}
                className="w-full py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 border border-blue-200"
              >
                <Navigation className="w-3 h-3 text-blue-600" />
                <span>🧭 Navigate to Vehicle</span>
              </button>
            )}
          </div>
        </div>
      </Popup>
    </Marker>
  );
}

export function CampusLiveGPSMap({ 
  zones = [], 
  selectedVehicleId, 
  onSelectVehicle, 
  onSelectBooking,
  onFleetUpdate,
  selectedCollegeProp,
  onCollegeChangeProp,
  height = "560px" 
}) {
  const [fleetGPS, setFleetGPS] = useState([]);
  const [loadingFleet, setLoadingFleet] = useState(true);
  const [isSimulating, setIsSimulating] = useState(true);
  const [internalCollege, setInternalCollege] = useState('');
  const [filterMode, setFilterMode] = useState('ALL'); // ALL, MOVING, IN_USE
  const [lastTelemetryTime, setLastTelemetryTime] = useState(new Date().toLocaleTimeString());

  // Navigation and Geolocation State
  const {
    userLocation,
    loading: loadingGps,
    error: gpsError,
    isTracking,
    getCurrentLocation,
    startTracking,
    stopTracking
  } = useGeolocation({ enableHighAccuracy: true, timeout: 10000, maximumAge: 3000 });

  const [destination, setDestination] = useState(null);
  const [routeData, setRouteData] = useState(null);
  const [isNavigating, setIsNavigating] = useState(false);
  const [isCalculatingRoute, setIsCalculatingRoute] = useState(false);
  const [isOffRoute, setIsOffRoute] = useState(false);
  const [hasArrived, setHasArrived] = useState(false);
  const [recenterCounter, setRecenterCounter] = useState(0);
  const lastRerouteTimeRef = useRef(0);

  const selectedCollege = selectedCollegeProp !== undefined ? selectedCollegeProp : internalCollege;
  const setSelectedCollege = onCollegeChangeProp || setInternalCollege;

  // PSG Tech Coimbatore default coordinate fallback
  const defaultCenter = [11.0244, 76.9942];

  // Extract unique colleges
  const colleges = useMemo(() => {
    const list = Array.from(new Set(zones.map(z => z.college_name).filter(Boolean))).sort();
    return list;
  }, [zones]);

  // Fetch Live Fleet GPS positions
  const fetchLiveGPS = useCallback(async () => {
    try {
      const url = `/gps/live-fleet?college=${encodeURIComponent(selectedCollege || '')}`;
      const res = await apiRequest(url);
      if (res.success && res.fleet) {
        setFleetGPS(res.fleet);
        setLastTelemetryTime(new Date().toLocaleTimeString());
        if (onFleetUpdate) {
          onFleetUpdate(res.fleet);
        }
      }
      setLoadingFleet(false);
    } catch (e) {
      console.error("GPS telemetry fetch error:", e);
      setLoadingFleet(false);
    }
  }, [selectedCollege, onFleetUpdate]);

  useEffect(() => {
    fetchLiveGPS();
    const interval = setInterval(fetchLiveGPS, 3500);
    return () => clearInterval(interval);
  }, [fetchLiveGPS]);

  // Simulation step loop for offline vehicle movements
  useEffect(() => {
    if (!isSimulating) return;
    const simInterval = setInterval(async () => {
      try {
        await apiRequest('/gps/simulate-step', { method: 'POST' });
        fetchLiveGPS();
      } catch (e) {
        setFleetGPS(prev => prev.map(v => {
          if (!v.is_moving && v.status !== 'IN_USE') return v;
          const delta = 0.00010 * ((v.speed_kmh || 20) / 25.0);
          const heading = (v.heading_degrees + (Math.random() * 20 - 10)) % 360;
          const rad = (heading * Math.PI) / 180;
          return {
            ...v,
            latitude: v.latitude + delta * Math.cos(rad),
            longitude: v.longitude + delta * Math.sin(rad),
            heading_degrees: heading,
            speed_kmh: Math.min(35, Math.max(12, (v.speed_kmh || 20) + (Math.random() * 4 - 2)))
          };
        }));
      }
    }, 3500);
    return () => clearInterval(simInterval);
  }, [isSimulating, fetchLiveGPS]);

  // Route calculation routine
  const calculateRouteToDestination = useCallback(async (startPos, destPos) => {
    if (!startPos || !destPos) return;
    setIsCalculatingRoute(true);
    setHasArrived(false);
    setIsOffRoute(false);

    try {
      const result = await fetchNavigationRoute(
        startPos.latitude,
        startPos.longitude,
        destPos.latitude,
        destPos.longitude
      );
      setRouteData(result);
    } catch (err) {
      console.error("Failed to calculate navigation route:", err);
    } finally {
      setIsCalculatingRoute(false);
    }
  }, []);

  // Recalculate route when destination changes if user location exists
  useEffect(() => {
    if (destination && userLocation) {
      calculateRouteToDestination(userLocation, destination);
    }
  }, [destination, userLocation?.latitude, userLocation?.longitude]);

  // Monitor live navigation, off-route deviation, and arrival checks
  useEffect(() => {
    if (!isNavigating || !userLocation || !destination || !routeData) return;

    // 1. Arrival check (within 20m of destination)
    const distToDest = calculateDistanceMeters(
      userLocation.latitude,
      userLocation.longitude,
      destination.latitude,
      destination.longitude
    );

    if (distToDest <= 20) {
      setHasArrived(true);
      return;
    }

    // 2. Off-Route Detection (perpendicular deviation > 45 meters)
    if (routeData.coordinates && routeData.coordinates.length >= 2) {
      const offRouteDist = calculateDistanceToPolyline(
        userLocation.latitude,
        userLocation.longitude,
        routeData.coordinates
      );

      const now = Date.now();
      if (offRouteDist > 45) {
        setIsOffRoute(true);
        // Throttle automatic rerouting to at most once every 6 seconds
        if (now - lastRerouteTimeRef.current > 6000) {
          lastRerouteTimeRef.current = now;
          calculateRouteToDestination(userLocation, destination);
        }
      } else {
        setIsOffRoute(false);
      }
    }
  }, [isNavigating, userLocation, destination, routeData, calculateRouteToDestination]);

  // Handle "Locate Me" / Recenter
  const handleLocateMe = async () => {
    try {
      if (!isTracking) {
        startTracking();
      }
      await getCurrentLocation();
      setRecenterCounter(c => c + 1);
    } catch (err) {
      // Handled by useGeolocation hook error state
    }
  };

  // Start Navigation Action
  const handleStartNavigation = async () => {
    if (!userLocation) {
      await handleLocateMe();
    }
    if (!destination && zones.length > 0) {
      // Default to first college zone if no destination explicitly picked
      const defaultDest = zones[0];
      setDestination({
        latitude: defaultDest.latitude,
        longitude: defaultDest.longitude,
        name: defaultDest.name
      });
    }
    startTracking();
    setIsNavigating(true);
    setRecenterCounter(c => c + 1);
  };

  // Stop Navigation Action
  const handleStopNavigation = () => {
    setIsNavigating(false);
    setDestination(null);
    setRouteData(null);
    setIsOffRoute(false);
    setHasArrived(false);
    stopTracking();
  };

  // Filtered vehicles for map display
  const displayedVehicles = useMemo(() => {
    return fleetGPS.filter(v => {
      if (filterMode === 'MOVING') return v.is_moving || v.speed_kmh > 0;
      if (filterMode === 'IN_USE') return v.status === 'IN_USE';
      return true;
    });
  }, [fleetGPS, filterMode]);

  return (
    <div className="bg-white rounded-3xl border border-campus-border/80 shadow-lg overflow-hidden flex flex-col relative" style={{ height }}>
      
      {/* 1. Top GPS Radar & Navigation Control Bar */}
      <div className="p-3 sm:p-4 bg-gradient-to-r from-slate-900 via-slate-800 to-blue-950 text-white flex flex-wrap items-center justify-between gap-3 shadow-md z-10">
        
        {/* Left: Telemetry & Satellite Lock Status */}
        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center">
            <span className="w-3 h-3 rounded-full bg-sky-400 animate-ping absolute"></span>
            <span className="w-3 h-3 rounded-full bg-sky-500 relative"></span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <Radio className="w-4 h-4 text-sky-300 animate-pulse" />
              <span className="font-extrabold text-xs tracking-wider uppercase font-display">
                {isNavigating ? 'GPS TURN-BY-TURN NAVIGATION' : 'LIVE GPS RADAR & TELEMETRY'}
              </span>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-white/15 text-sky-300 border border-white/20 font-mono">
                {userLocation ? `ACCURACY ±${userLocation.accuracy}m` : 'GNSS 12 SAT'}
              </span>
            </div>
            <p className="text-[10px] text-gray-300 font-mono">
              {userLocation 
                ? `Current Position: ${userLocation.latitude.toFixed(5)}°N, ${userLocation.longitude.toFixed(5)}°E`
                : `Updated: ${lastTelemetryTime} • High Precision DGPS`}
            </p>
          </div>
        </div>

        {/* Center: Destination Selector */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <MapPin className="w-3.5 h-3.5 text-campus-gold absolute left-2.5 top-2.5" />
            <select
              value={destination ? `${destination.latitude},${destination.longitude}` : ''}
              onChange={(e) => {
                if (!e.target.value) {
                  setDestination(null);
                  return;
                }
                const [latStr, lngStr] = e.target.value.split(',');
                const zone = zones.find(z => z.latitude === Number(latStr) && z.longitude === Number(lngStr));
                setDestination({
                  latitude: Number(latStr),
                  longitude: Number(lngStr),
                  name: zone ? zone.name : 'Selected Hub'
                });
              }}
              className="pl-8 pr-4 py-1.5 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-xs font-semibold text-white focus:outline-none focus:ring-2 focus:ring-sky-400 cursor-pointer max-w-[200px] truncate"
            >
              <option value="" className="text-gray-900">📍 Choose Nav Destination...</option>
              {zones.map(z => (
                <option key={z.id} value={`${z.latitude},${z.longitude}`} className="text-gray-900">
                  {z.name} ({z.college_name?.split(' ')[0]})
                </option>
              ))}
            </select>
          </div>

          {/* College Filter */}
          <div className="relative hidden md:block">
            <GraduationCap className="w-3.5 h-3.5 text-sky-300 absolute left-2.5 top-2.5" />
            <select
              value={selectedCollege}
              onChange={(e) => setSelectedCollege(e.target.value)}
              className="pl-8 pr-3 py-1.5 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-xs font-semibold text-white focus:outline-none focus:ring-2 focus:ring-sky-400 cursor-pointer max-w-[170px] truncate"
            >
              <option value="" className="text-gray-900">🎓 All Campuses</option>
              {colleges.map(c => (
                <option key={c} value={c} className="text-gray-900">{c}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Right: GPS Actions (Locate Me, Start/Stop Nav) */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Locate Me / Recenter Button */}
          <button
            onClick={handleLocateMe}
            disabled={loadingGps}
            className="px-3 py-1.5 bg-blue-600/80 hover:bg-blue-600 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-blue-400/50 shadow-sm disabled:opacity-50"
            title="Acquire real browser GPS coordinates"
          >
            <Crosshair className={`w-3.5 h-3.5 ${loadingGps ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">{userLocation ? 'My Location' : 'Locate Me'}</span>
          </button>

          {/* Navigation Toggle CTA */}
          {isNavigating ? (
            <button
              onClick={handleStopNavigation}
              className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md"
            >
              <X className="w-3.5 h-3.5" />
              <span>Stop Nav</span>
            </button>
          ) : (
            <button
              onClick={handleStartNavigation}
              className="px-3.5 py-1.5 bg-campus-emerald hover:bg-emerald-600 text-white rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 shadow-md"
            >
              <Navigation className="w-3.5 h-3.5 text-campus-gold fill-campus-gold" />
              <span>Start Navigation</span>
            </button>
          )}
        </div>

      </div>

      {/* 2. Floating Turn-by-Turn Navigation HUD Overlay (When Navigating) */}
      {isNavigating && routeData && (
        <div className="absolute top-16 left-3 right-3 sm:left-6 sm:right-auto sm:w-96 z-20 bg-slate-900/95 text-white rounded-2xl p-4 shadow-2xl border border-sky-400/40 backdrop-blur-md space-y-2.5 animate-in slide-in-from-top-4">
          
          {/* Top Line: Turn Instruction & Distance */}
          <div className="flex items-start justify-between gap-3 border-b border-white/10 pb-2">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center shrink-0 shadow">
                <CornerUpRight className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-xs font-black text-sky-300 uppercase tracking-wide">
                  {routeData.steps?.[0]?.instruction || `Navigate towards ${destination?.name || 'Destination'}`}
                </div>
                <div className="text-[11px] text-gray-300 font-medium">
                  Remaining: <strong>{routeData.distanceFormatted}</strong> • ~{routeData.durationFormatted}
                </div>
              </div>
            </div>

            <button
              onClick={handleStopNavigation}
              className="p-1 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white transition"
              title="Close Navigation"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Bottom Line: Live Speedometer & Off-Route Status */}
          <div className="flex items-center justify-between text-xs pt-0.5">
            <div className="flex items-center gap-3">
              <span className="font-mono font-bold text-campus-gold flex items-center gap-1">
                <Gauge className="w-3.5 h-3.5" />
                <span>{Math.round(userLocation?.speed || 0)} km/h</span>
              </span>
              <span className="text-[10px] text-gray-400 font-mono">
                Heading: {userLocation?.heading ? `${userLocation.heading}°` : '0°'}
              </span>
            </div>

            {isOffRoute ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-400/40 flex items-center gap-1 animate-pulse">
                <RotateCcw className="w-3 h-3 animate-spin" />
                <span>Rerouting...</span>
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                <span>On Route</span>
              </span>
            )}
          </div>

          {hasArrived && (
            <div className="p-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold text-center flex items-center justify-center gap-1.5 animate-bounce shadow-lg">
              <Flag className="w-4 h-4" />
              <span>🎉 You have arrived at your destination!</span>
            </div>
          )}

        </div>
      )}

      {/* 3. Geolocation Error Alert Bar */}
      {gpsError && (
        <div className="bg-amber-500 text-slate-950 px-4 py-2 text-xs font-bold flex items-center justify-between z-10 border-b border-amber-600 shadow">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{gpsError}</span>
          </div>
          <button
            onClick={handleLocateMe}
            className="px-2.5 py-1 bg-slate-900 text-white rounded-lg text-[11px] font-bold hover:bg-slate-800 transition"
          >
            Retry GPS
          </button>
        </div>
      )}

      {/* 4. Leaflet Map Body */}
      <div className="flex-1 relative z-0">
        <MapContainer
          center={defaultCenter}
          zoom={15}
          scrollWheelZoom={true}
          className="h-full w-full"
        >
          <MapController 
            selectedCollege={selectedCollege} 
            zones={zones} 
            selectedVehicleId={selectedVehicleId} 
            fleetGPS={fleetGPS}
            userLocation={userLocation}
            recenterTrigger={recenterCounter}
            destination={destination}
            routeCoordinates={routeData?.coordinates}
          />

          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          {/* Render Route Polyline */}
          {routeData?.coordinates && routeData.coordinates.length > 0 && (
            <>
              {/* Outer Glow Backing Line */}
              <Polyline
                positions={routeData.coordinates}
                pathOptions={{
                  color: '#1d4ed8',
                  weight: 8,
                  opacity: 0.4,
                  lineCap: 'round',
                  lineJoin: 'round'
                }}
              />
              {/* Core Route Line */}
              <Polyline
                positions={routeData.coordinates}
                pathOptions={{
                  color: '#2563eb',
                  weight: 5,
                  opacity: 0.95,
                  lineCap: 'round',
                  lineJoin: 'round'
                }}
              />
            </>
          )}

          {/* Render Destination Pin */}
          {destination && destination.latitude && destination.longitude && (
            <Marker
              position={[destination.latitude, destination.longitude]}
              icon={createDestinationIcon(destination.name || 'Drop-off Station')}
            >
              <Popup>
                <div className="p-1 text-xs">
                  <div className="font-extrabold text-campus-forest">{destination.name}</div>
                  <div className="text-[10px] text-gray-500 font-mono">
                    {destination.latitude.toFixed(5)}°N, {destination.longitude.toFixed(5)}°E
                  </div>
                </div>
              </Popup>
            </Marker>
          )}

          {/* Render User Real GPS Location Marker */}
          {userLocation && userLocation.latitude && userLocation.longitude && (
            <>
              {/* User GPS Accuracy Radius Circle */}
              <Circle
                center={[userLocation.latitude, userLocation.longitude]}
                radius={Math.max(10, userLocation.accuracy || 15)}
                pathOptions={{
                  fillColor: '#3b82f6',
                  fillOpacity: 0.15,
                  color: '#2563eb',
                  weight: 1.5
                }}
              />

              {/* User Position Beacon */}
              <Marker
                position={[userLocation.latitude, userLocation.longitude]}
                icon={createUserLocationIcon(userLocation.heading)}
              >
                <Popup>
                  <div className="p-1 space-y-1 text-xs">
                    <div className="font-extrabold text-blue-700 flex items-center gap-1">
                      <Crosshair className="w-3.5 h-3.5" />
                      <span>Your Real GPS Location</span>
                    </div>
                    <div className="text-[10px] text-gray-500 font-mono">
                      {userLocation.latitude.toFixed(5)}°N, {userLocation.longitude.toFixed(5)}°E
                    </div>
                    <div className="text-[10px] text-gray-600">
                      Accuracy: ±{userLocation.accuracy}m • Speed: {Math.round(userLocation.speed || 0)} km/h
                    </div>
                  </div>
                </Popup>
              </Marker>
            </>
          )}

          {/* Render Campus Geofenced Hubs */}
          {zones.map((zone) => {
            const isTargetCollege = !selectedCollege || zone.college_name === selectedCollege;
            if (!isTargetCollege || !zone.latitude || !zone.longitude) return null;

            return (
              <React.Fragment key={`zone-${zone.id}`}>
                <Circle
                  center={[zone.latitude, zone.longitude]}
                  radius={450}
                  pathOptions={{
                    fillColor: '#2563EB',
                    fillOpacity: 0.08,
                    color: '#2563EB',
                    weight: 1.5,
                    dashArray: '4, 6'
                  }}
                />

                <Marker
                  position={[zone.latitude, zone.longitude]}
                  icon={createHubIcon(zone, zone.available_vehicles || 0)}
                >
                  <Popup>
                    <div className="p-1.5 space-y-1.5 text-xs">
                      <span className="text-[10px] font-bold text-campus-emerald uppercase">{zone.college_name}</span>
                      <div className="font-extrabold text-campus-forest text-sm">{zone.name}</div>
                      <p className="text-[11px] text-gray-500">{zone.description}</p>
                      
                      <div className="pt-1 border-t flex justify-between font-bold text-[11px]">
                        <span>Available Fleet:</span>
                        <span className="text-campus-emerald">{zone.available_vehicles} / {zone.capacity}</span>
                      </div>

                      <button
                        onClick={() => {
                          setDestination({
                            latitude: zone.latitude,
                            longitude: zone.longitude,
                            name: zone.name
                          });
                          if (!isNavigating) {
                            handleStartNavigation();
                          }
                        }}
                        className="w-full mt-1 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 shadow"
                      >
                        <Navigation className="w-3 h-3" />
                        <span>Navigate Here</span>
                      </button>
                    </div>
                  </Popup>
                </Marker>
              </React.Fragment>
            );
          })}

          {/* Render Live Fleet GPS Vehicles */}
          {displayedVehicles.map((veh) => {
            if (!veh.latitude || !veh.longitude) return null;
            return (
              <AnimatedVehicleMarker
                key={`veh-${veh.id}`}
                vehicle={veh}
                onSelectBooking={onSelectBooking}
                onSetDestination={(dest) => {
                  setDestination(dest);
                  if (!isNavigating) {
                    handleStartNavigation();
                  }
                }}
              />
            );
          })}

        </MapContainer>
      </div>

      {/* 5. Bottom Status Bar */}
      <div className="p-2.5 bg-campus-sand/40 border-t border-campus-border/60 flex flex-wrap items-center justify-between text-[11px] font-semibold text-gray-600">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1 text-campus-forest font-bold">
            <Radio className="w-3.5 h-3.5 text-campus-emerald" />
            <span>Telemetry: {isNavigating ? 'Active Turn-by-Turn Navigation' : 'Live Fleet Stream'}</span>
          </span>
          <span className="text-gray-500">
            GPS Signal: <strong className="text-campus-emerald">{userLocation ? 'Real-Time Locked' : 'DGPS Standby'}</strong>
          </span>
          <span className="text-gray-500 hidden sm:inline">
            Geofence Boundary: <strong className="text-campus-forest">1500m Campus Enforced</strong>
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 text-blue-700 font-bold">
            <span className="w-2 h-2 rounded-full bg-blue-600 inline-block"></span>
            <span>Blue = Real GPS / Active Ride</span>
          </span>
          <span className="flex items-center gap-1 text-emerald-700 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block"></span>
            <span>Green = Available Pool</span>
          </span>
        </div>
      </div>

    </div>
  );
}

export default CampusLiveGPSMap;
