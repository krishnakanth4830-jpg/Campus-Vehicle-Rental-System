import React from 'react';
import { Search, Filter, SlidersHorizontal, RotateCcw } from 'lucide-react';

const VehicleFilterBar = ({
  search,
  setSearch,
  selectedType,
  setSelectedType,
  selectedZone,
  setSelectedZone,
  selectedElectric,
  setSelectedElectric,
  minBattery,
  setMinBattery,
  sortBy,
  setSortBy,
  types = [],
  zones = [],
  onReset
}) => {
  return (
    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
      {/* Top Search & Filter Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        
        {/* Keyword Search */}
        <div className="relative md:col-span-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search brand, model, vehicle #..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
          />
        </div>

        {/* Campus Zone Filter */}
        <div>
          <select
            value={selectedZone}
            onChange={(e) => setSelectedZone(e.target.value)}
            className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
          >
            <option value="">All Campus Zones</option>
            {zones.map((z) => (
              <option key={z.id} value={z.id}>
                📍 {z.name} ({z.available_vehicles} available)
              </option>
            ))}
          </select>
        </div>

        {/* Vehicle Type Filter */}
        <div>
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
          >
            <option value="">All Vehicle Categories</option>
            {types.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} (₹{t.base_rate_per_hour}/hr)
              </option>
            ))}
          </select>
        </div>

        {/* Sort Select */}
        <div>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
          >
            <option value="default">Sort by: Default</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="battery_desc">Highest Battery %</option>
            <option value="health_desc">Best Health Score</option>
          </select>
        </div>
      </div>

      {/* Secondary Quick Toggles */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-bold text-slate-500 flex items-center gap-1">
            <SlidersHorizontal className="w-3.5 h-3.5" />
            Propulsion:
          </span>

          <button
            onClick={() => setSelectedElectric('')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
              selectedElectric === ''
                ? 'bg-slate-900 text-white shadow-sm'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Fleets
          </button>

          <button
            onClick={() => setSelectedElectric('true')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
              selectedElectric === 'true'
                ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/20'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            ⚡ Electric Only
          </button>

          <button
            onClick={() => setSelectedElectric('false')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
              selectedElectric === 'false'
                ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/20'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            🚲 Mechanical / Pedal
          </button>
        </div>

        {/* Reset Filters button */}
        {(search || selectedType || selectedZone || selectedElectric || sortBy !== 'default') && (
          <button
            onClick={onReset}
            className="flex items-center gap-1.5 text-xs font-bold text-rose-600 hover:text-rose-700 bg-rose-50 px-3 py-1.5 rounded-xl transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Filters
          </button>
        )}
      </div>
    </div>
  );
};

export default VehicleFilterBar;
