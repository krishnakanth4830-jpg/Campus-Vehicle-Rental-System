import React from 'react';
import { BatteryCharging, Battery, BatteryMedium, BatteryLow, BatteryWarning } from 'lucide-react';

const BatteryIndicator = ({ percentage = 100, isCharging = false, estimatedRange = 0 }) => {
  const getBatteryColor = () => {
    if (percentage >= 60) return 'text-emerald-600 bg-emerald-50 border-emerald-200';
    if (percentage >= 25) return 'text-amber-600 bg-amber-50 border-amber-200';
    return 'text-rose-600 bg-rose-50 border-rose-200';
  };

  const getBarColor = () => {
    if (percentage >= 60) return 'bg-emerald-500';
    if (percentage >= 25) return 'bg-amber-500';
    return 'bg-rose-500';
  };

  const getIcon = () => {
    if (isCharging) return <BatteryCharging className="w-4 h-4 animate-pulse text-emerald-600" />;
    if (percentage >= 80) return <Battery className="w-4 h-4" />;
    if (percentage >= 40) return <BatteryMedium className="w-4 h-4" />;
    if (percentage >= 20) return <BatteryLow className="w-4 h-4" />;
    return <BatteryWarning className="w-4 h-4 animate-bounce" />;
  };

  return (
    <div className={`flex items-center gap-2 px-2.5 py-1 rounded-xl border text-xs font-semibold ${getBatteryColor()}`}>
      <div className="flex items-center gap-1">
        {getIcon()}
        <span>{percentage}%</span>
      </div>

      {/* Mini Progress Bar */}
      <div className="w-10 h-2 bg-slate-200 rounded-full overflow-hidden shrink-0">
        <div
          className={`h-full rounded-full transition-all duration-500 ${getBarColor()}`}
          style={{ width: `${Math.min(100, Math.max(0, percentage))}%` }}
        />
      </div>

      {estimatedRange > 0 && (
        <span className="text-[10px] text-slate-500 font-medium">
          (~{estimatedRange} km)
        </span>
      )}
    </div>
  );
};

export default BatteryIndicator;
