import React from 'react';
import { Activity, ShieldCheck, AlertCircle } from 'lucide-react';

const HealthScoreBadge = ({ score = 100, condition = 'EXCELLENT' }) => {
  const getScoreStyle = () => {
    if (score >= 90) return 'text-emerald-700 bg-emerald-50 border-emerald-200';
    if (score >= 75) return 'text-blue-700 bg-blue-50 border-blue-200';
    if (score >= 60) return 'text-amber-700 bg-amber-50 border-amber-200';
    return 'text-rose-700 bg-rose-50 border-rose-200';
  };

  return (
    <div
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl border text-xs font-bold ${getScoreStyle()}`}
      title={`Vehicle Diagnostic Health: ${score}/100 • Condition: ${condition}`}
    >
      <Activity className="w-3.5 h-3.5" />
      <span>Health: {score}/100</span>
      <span className="text-[10px] font-medium opacity-80 uppercase tracking-wider">({condition.replace('_', ' ')})</span>
    </div>
  );
};

export default HealthScoreBadge;
