import React from 'react';
import { Link } from 'react-router-dom';
import BatteryIndicator from './BatteryIndicator';
import HealthScoreBadge from './HealthScoreBadge';
import { VehicleVisual } from '../common/VehicleVisual';
import {
  Bike,
  Zap,
  MapPin,
  Users,
  Star,
  QrCode,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

const VehicleCard = ({ vehicle, onBook, onShowQR, showRecommendationBadge = false, recommendationScore = null, explanation = null }) => {
  const isAvailable = vehicle.status === 'AVAILABLE';
  const isReserved = vehicle.status === 'RESERVED';
  const isMaintenance = vehicle.status === 'MAINTENANCE';

  const getStatusBadge = () => {
    switch (vehicle.status) {
      case 'AVAILABLE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Available Now
          </span>
        );
      case 'RESERVED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
            Reserved
          </span>
        );
      case 'IN_USE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800">
            On Campus Trip
          </span>
        );
      case 'MAINTENANCE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800">
            Under Inspection
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-700">
            {vehicle.status}
          </span>
        );
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group relative">
      
      {/* Smart Match Recommendation Ribbon */}
      {showRecommendationBadge && (
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white px-4 py-1.5 flex items-center justify-between text-xs font-bold">
          <span className="flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 fill-current" />
            AI Smart Match Score
          </span>
          <span className="bg-white/20 px-2 py-0.5 rounded-full text-[11px]">
            {recommendationScore}% Match
          </span>
        </div>
      )}

      {/* Clean Vector Vehicle Visual Container (No Photographs) */}
      <div className="relative overflow-hidden">
        <VehicleVisual vehicle={vehicle} size="card" showBadge={false} />

        {/* Status Badge Overlay */}
        <div className="absolute top-3 left-3 z-10">{getStatusBadge()}</div>

        {/* Electric / Engine Type Badge */}
        <div className="absolute top-3 right-3 z-10">
          {vehicle.is_electric ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold bg-white/90 backdrop-blur-md text-emerald-800 shadow-sm border border-emerald-100">
              <Zap className="w-3.5 h-3.5 text-emerald-600" />
              Electric
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold bg-white/90 backdrop-blur-md text-slate-700 shadow-sm border border-slate-100">
              <Bike className="w-3.5 h-3.5 text-slate-600" />
              {vehicle.engine_cc ? `${vehicle.engine_cc}cc Petrol` : 'Petrol'}
            </span>
          )}
        </div>

        {/* Current Zone Tag */}
        <div className="absolute bottom-3 left-3 right-3 z-10 flex items-center justify-between">
          <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold bg-slate-900/80 backdrop-blur-md text-white shadow">
            <MapPin className="w-3.5 h-3.5 text-emerald-400" />
            <span className="truncate max-w-[180px]">{vehicle.current_zone_name || vehicle.current_zone?.name || 'Main Hub'}</span>
          </div>

          <span className="text-[11px] font-bold text-slate-300 bg-slate-900/80 px-2 py-1 rounded-xl font-mono">
            {vehicle.vehicle_number}
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div>
          {/* Brand & Model Header */}
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-emerald-600">{vehicle.type_name}</p>
              <h4 className="text-base font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                {vehicle.brand} {vehicle.model}
              </h4>
            </div>

            {/* Price Badge */}
            <div className="text-right shrink-0">
              <p className="text-lg font-black text-slate-900 leading-none">
                ₹{vehicle.hourly_rate}
              </p>
              <p className="text-[10px] text-slate-500 font-medium">per hour</p>
            </div>
          </div>

          {/* Vehicle Number & Owner Name Badge */}
          <div className="mt-2.5 p-2.5 bg-slate-50 rounded-xl border border-slate-200/80 flex flex-col gap-1 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">Vehicle Number:</span>
              <span className="font-mono font-bold text-emerald-800 bg-white px-2 py-0.5 rounded border border-slate-200 shadow-xs">{vehicle.vehicle_number}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">Owner Name:</span>
              <span className="font-semibold text-slate-800">{vehicle.owner_name || vehicle.owner?.name || 'Campus Host'}</span>
            </div>
          </div>

          {/* Quick Explanation if recommended */}
          {explanation && (
            <p className="mt-2 text-xs text-slate-600 bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-100 leading-relaxed">
              💡 <span className="font-semibold text-emerald-900">{explanation}</span>
            </p>
          )}

          {/* Battery & Health Indicators */}
          <div className="mt-4 flex flex-wrap items-center gap-2">
            {vehicle.is_electric && (
              <BatteryIndicator
                percentage={vehicle.battery_percentage}
                isCharging={vehicle.is_charging}
                estimatedRange={vehicle.estimated_range_km}
              />
            )}
            <HealthScoreBadge score={vehicle.health_score} condition={vehicle.condition_status} />
          </div>

          {/* Capacity and Ratings */}
          <div className="mt-3.5 flex items-center justify-between text-xs text-slate-500 pt-3 border-t border-slate-100">
            <div className="flex items-center gap-1.5">
              <Users className="w-4 h-4 text-slate-400" />
              <span>{vehicle.passenger_capacity} Rider{vehicle.passenger_capacity > 1 ? 's' : ''}</span>
            </div>

            <div className="flex items-center gap-1">
              <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span className="font-bold text-slate-800">{vehicle.average_rating > 0 ? vehicle.average_rating : 'New'}</span>
              {vehicle.review_count > 0 && (
                <span className="text-slate-400">({vehicle.review_count})</span>
              )}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-2">
          <Link
            to={`/vehicles/${vehicle.id}`}
            className="px-3 py-2.5 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors text-center"
          >
            Details
          </Link>

          {isAvailable ? (
            <button
              onClick={() => onBook && onBook(vehicle)}
              className="px-3 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-md shadow-emerald-600/20 hover:shadow-lg transition-all text-center flex items-center justify-center gap-1.5"
            >
              <span>Reserve</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              disabled
              className="px-3 py-2.5 rounded-xl text-xs font-bold text-slate-400 bg-slate-100 cursor-not-allowed text-center"
            >
              Unavailable
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default VehicleCard;
