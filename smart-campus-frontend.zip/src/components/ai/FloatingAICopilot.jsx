import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, Send, X, Bot, User as UserIcon, 
  ChevronRight, Radio, Shield, Zap, Fuel, RefreshCw, MessageSquare, ExternalLink 
} from 'lucide-react';
import { apiRequest } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { useBooking } from '../../context/BookingContext';
import { BookingModal } from '../booking/BookingModal';
import { VehicleVisual } from '../common/VehicleVisual';

function renderFormattedSpan(text) {
  if (!text) return text;
  const parts = [];
  const regex = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
  let lastIndex = 0;
  let match;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(text.substring(lastIndex, match.index));
    }
    const token = match[0];
    if (token.startsWith('**') && token.endsWith('**')) {
      parts.push(<strong key={match.index} className="font-bold text-campus-forest">{token.slice(2, -2)}</strong>);
    } else if (token.startsWith('*') && token.endsWith('*')) {
      parts.push(<em key={match.index} className="italic text-gray-700">{token.slice(1, -1)}</em>);
    } else if (token.startsWith('`') && token.endsWith('`')) {
      parts.push(<code key={match.index} className="px-1 py-0.5 bg-campus-sand font-mono text-[10px] rounded text-campus-emerald font-semibold">{token.slice(1, -1)}</code>);
    }
    lastIndex = match.index + token.length;
  }
  if (lastIndex < text.length) {
    parts.push(text.substring(lastIndex));
  }
  return parts.length > 0 ? parts : text;
}

function FormattedMessage({ text }) {
  if (!text) return null;
  const lines = text.split('\n');

  return (
    <div className="space-y-1.5 leading-relaxed text-xs">
      {lines.map((line, idx) => {
        const trimmed = line.trim();
        if (!trimmed) {
          return <div key={idx} className="h-1" />;
        }
        if (trimmed.startsWith('### ')) {
          return (
            <div key={idx} className="font-extrabold text-xs text-campus-forest pt-1 pb-0.5 border-b border-campus-border/60">
              {renderFormattedSpan(trimmed.slice(4))}
            </div>
          );
        }
        if (trimmed.startsWith('## ')) {
          return (
            <div key={idx} className="font-extrabold text-sm text-campus-forest pt-1 pb-0.5">
              {renderFormattedSpan(trimmed.slice(3))}
            </div>
          );
        }
        if (trimmed.startsWith('* ') || trimmed.startsWith('- ')) {
          return (
            <div key={idx} className="flex items-start gap-1.5 pl-1 text-[11px]">
              <span className="text-campus-emerald font-bold">•</span>
              <span className="flex-1">{renderFormattedSpan(trimmed.slice(2))}</span>
            </div>
          );
        }
        const numMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
        if (numMatch) {
          return (
            <div key={idx} className="flex items-start gap-1.5 pl-1 text-[11px]">
              <span className="text-campus-emerald font-bold">{numMatch[1]}.</span>
              <span className="flex-1">{renderFormattedSpan(numMatch[2])}</span>
            </div>
          );
        }
        return (
          <div key={idx} className="text-[11px]">
            {renderFormattedSpan(line)}
          </div>
        );
      })}
    </div>
  );
}

export function FloatingAICopilot({ onSelectBooking, setTab }) {
  const { user } = useAuth();
  const { zones } = useBooking();
  const [isOpen, setIsOpen] = useState(false);
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedVehicleForBooking, setSelectedVehicleForBooking] = useState(null);

  const initialMessage = {
    id: 1,
    sender: 'ai',
    text: "👋 Hi! I'm **AURA AI**, your built-in Smart Campus Mobility Copilot. How can I assist your travel across campus today?",
    suggestions: [
      "Find available scooters near me",
      "Fastest ride for exam in 10 mins",
      "What are the campus speed limits?",
      "Show Royal Enfield cruisers"
    ],
    cards: []
  };

  const [messages, setMessages] = useState([initialMessage]);
  const chatBottomRef = useRef(null);

  useEffect(() => {
    if (isOpen) {
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleClearChat = () => {
    setMessages([initialMessage]);
    setInputQuery('');
  };

  const handleSend = async (queryText) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || loading) return;

    const userMsg = {
      id: Date.now(),
      sender: 'user',
      text: textToSend
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');
    setLoading(true);

    try {
      const res = await apiRequest('/ai/chat', {
        method: 'POST',
        body: JSON.stringify({
          query: textToSend,
          user_id: user?.id
        })
      });

      if (res.success && res.result) {
        const aiMsg = {
          id: Date.now() + 1,
          sender: 'ai',
          text: res.result.response,
          suggestions: res.result.suggestions || [],
          cards: res.result.cards || []
        };
        setMessages(prev => [...prev, aiMsg]);
      } else {
        setMessages(prev => [...prev, {
          id: Date.now() + 1,
          sender: 'ai',
          text: "I couldn't process that request right now. Please ask about available campus vehicles or rules.",
          suggestions: ["Show all available vehicles", "View Live GPS Radar"]
        }]);
      }
    } catch (e) {
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        sender: 'ai',
        text: "Connecting to AI engine... Please ensure the backend server is running.",
        suggestions: ["Find available scooters near me", "What are the campus speed limits?"]
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleReserveClick = (vehicle) => {
    if (onSelectBooking) {
      onSelectBooking(vehicle);
      setIsOpen(false);
    } else {
      setSelectedVehicleForBooking(vehicle);
    }
  };

  return (
    <>
      <div className="fixed bottom-6 right-6 z-40">
        
        {/* Floating Launcher Button */}
        {!isOpen && (
          <button
            onClick={() => setIsOpen(true)}
            className="group relative flex items-center gap-2.5 px-5 py-3.5 bg-gradient-to-r from-slate-900 via-slate-800 to-blue-600 text-white rounded-full shadow-2xl hover:shadow-sky-500/50 transition-all transform hover:scale-105 border border-sky-400/40"
          >
            <div className="relative">
              <span className="w-3 h-3 rounded-full bg-sky-400 animate-ping absolute"></span>
              <Sparkles className="w-5 h-5 text-sky-300 relative" />
            </div>
            <span className="font-extrabold text-xs tracking-wider uppercase font-display">
              AURA AI Copilot
            </span>
            <span className="hidden group-hover:inline-block px-2 py-0.5 rounded-full text-[10px] bg-white/20 text-sky-300 font-mono font-bold">
              Ask Anything
            </span>
          </button>
        )}

        {/* Interactive AI Chat Drawer */}
        {isOpen && (
          <div className="w-[380px] sm:w-[430px] h-[600px] bg-white rounded-3xl shadow-2xl border-2 border-campus-border/90 flex flex-col overflow-hidden animate-in slide-in-from-bottom-5">
            
            {/* Top AI Header */}
            <div className="p-4 bg-gradient-to-r from-slate-900 via-slate-800 to-blue-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-campus-emerald/60 flex items-center justify-center border border-sky-400/40">
                  <Bot className="w-5 h-5 text-sky-300" />
                </div>
                <div>
                  <div className="font-extrabold text-xs tracking-wider flex items-center gap-1.5 font-display">
                    <span>AURA AI MOBILITY ASSISTANT</span>
                    <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse"></span>
                  </div>
                  <p className="text-[10px] text-gray-300 font-mono">Real-time Campus NLP & Telemetry Engine</p>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={handleClearChat}
                  title="Reset Chat"
                  className="p-1.5 rounded-xl hover:bg-white/10 text-gray-300 hover:text-white transition"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
                {setTab && (
                  <button
                    onClick={() => {
                      setIsOpen(false);
                      setTab('ai-copilot');
                    }}
                    title="Open Full AI Suite"
                    className="p-1.5 rounded-xl hover:bg-white/10 text-gray-300 hover:text-white transition"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => setIsOpen(false)}
                  title="Close Assistant"
                  className="p-1.5 rounded-xl hover:bg-white/10 text-gray-300 hover:text-white transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Chat Messages Body */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-campus-sand/20 text-xs">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.sender === 'ai' && (
                    <div className="w-6 h-6 rounded-full bg-campus-forest text-sky-300 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Sparkles className="w-3.5 h-3.5" />
                    </div>
                  )}

                  <div className="max-w-[85%] space-y-2">
                    <div
                      className={`p-3.5 rounded-2xl ${
                        msg.sender === 'user'
                          ? 'bg-campus-forest text-white rounded-tr-none'
                          : 'bg-white border border-campus-border/80 text-gray-800 shadow-sm rounded-tl-none'
                      }`}
                    >
                      {msg.sender === 'ai' ? (
                        <FormattedMessage text={msg.text} />
                      ) : (
                        <div className="whitespace-pre-line leading-relaxed text-xs">
                          {msg.text}
                        </div>
                      )}
                    </div>

                    {/* Render Embedded Vehicle Cards (if any returned by AI) */}
                    {msg.cards && msg.cards.length > 0 && (
                      <div className="space-y-2 pt-1">
                        {msg.cards.map((c) => (
                          <div
                            key={c.id}
                            className="p-3 bg-white border border-campus-border/90 rounded-2xl shadow-sm space-y-2 hover:border-campus-emerald/60 transition"
                          >
                            <div className="flex items-center gap-2.5">
                              <VehicleVisual
                                vehicle={c}
                                size="thumbnail"
                                showBadge={false}
                                className="flex-shrink-0"
                              />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between">
                                  <span className="font-mono font-black text-[10px] text-campus-forest bg-campus-sand px-1.5 py-0.5 rounded truncate">
                                    {c.vehicle_number}
                                  </span>
                                  <span className="text-xs font-black text-campus-emerald">
                                    ₹{c.hourly_rate}/hr
                                  </span>
                                </div>
                                <div className="font-bold text-gray-900 text-xs truncate mt-0.5">{c.title}</div>
                                {c.college_name && (
                                  <div className="text-[10px] text-gray-500 font-medium truncate">
                                    📍 {c.current_zone_name || c.college_name}
                                  </div>
                                )}
                              </div>
                            </div>

                            <div className="flex items-center justify-between text-[10px] text-gray-600 bg-campus-sand/40 p-1.5 rounded-lg font-mono">
                              <span>⛽ {c.fuel_level_percentage}% Tank</span>
                              <span>{c.mileage_kmpl} km/l</span>
                              <span>{c.engine_cc}cc</span>
                            </div>

                            <button
                              onClick={() => handleReserveClick(c)}
                              className="w-full py-1.5 bg-campus-forest hover:bg-campus-emerald text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 mt-1 shadow-sm"
                            >
                              <span>1-Click Reserve</span>
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Suggestion Chips */}
                    {msg.suggestions && msg.suggestions.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {msg.suggestions.map((s, idx) => (
                          <button
                            key={idx}
                            onClick={() => handleSend(s)}
                            className="px-2.5 py-1 bg-white hover:bg-campus-sand/80 border border-campus-border/90 rounded-full text-[10px] font-semibold text-campus-forest transition text-left shadow-2xs"
                          >
                            💡 {s}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {msg.sender === 'user' && (
                    <div className="w-6 h-6 rounded-full bg-campus-emerald text-white flex items-center justify-center flex-shrink-0 mt-0.5">
                      <UserIcon className="w-3.5 h-3.5" />
                    </div>
                  )}
                </div>
              ))}

              {loading && (
                <div className="flex items-center gap-2 text-xs text-gray-500 pl-8">
                  <span className="w-2 h-2 rounded-full bg-campus-emerald animate-ping"></span>
                  <span>AURA AI is analyzing campus telemetry...</span>
                </div>
              )}

              <div ref={chatBottomRef} />
            </div>

            {/* Bottom Chat Input Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="p-3 bg-white border-t border-campus-border/70 flex items-center gap-2"
            >
              <input
                type="text"
                placeholder="Ask AURA AI (e.g. 'Bikes under ₹25/hr')..."
                value={inputQuery}
                onChange={(e) => setInputQuery(e.target.value)}
                className="flex-1 px-3.5 py-2.5 bg-campus-sand/30 border border-campus-border/80 rounded-2xl text-xs text-campus-charcoal focus:outline-none focus:ring-2 focus:ring-campus-emerald/40 placeholder:text-gray-400"
              />
              <button
                type="submit"
                disabled={loading || !inputQuery.trim()}
                className="p-2.5 bg-campus-forest hover:bg-campus-emerald disabled:opacity-50 text-white rounded-2xl shadow transition"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>

          </div>
        )}

      </div>

      {/* Floating Modal for 1-Click Reservation */}
      {selectedVehicleForBooking && (
        <BookingModal
          vehicle={selectedVehicleForBooking}
          zones={zones}
          onClose={() => setSelectedVehicleForBooking(null)}
          onSuccess={(booking) => {
            setSelectedVehicleForBooking(null);
            setIsOpen(false);
            if (setTab) {
              setTab('active-rental');
            }
          }}
        />
      )}
    </>
  );
}
