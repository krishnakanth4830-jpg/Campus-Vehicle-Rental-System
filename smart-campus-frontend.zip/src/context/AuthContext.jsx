import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiRequest } from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('campus_mobility_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem('campus_mobility_token'));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function checkAuth() {
      if (token) {
        const res = await apiRequest('/auth/me');
        if (res.success && res.user) {
          setUser(res.user);
          localStorage.setItem('campus_mobility_user', JSON.stringify(res.user));
        } else {
          logout();
        }
      }
      setLoading(false);
    }
    checkAuth();
  }, [token]);

  const login = async (email, password) => {
    const res = await apiRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });

    if (res.success && res.token) {
      setToken(res.token);
      setUser(res.user);
      localStorage.setItem('campus_mobility_token', res.token);
      localStorage.setItem('campus_mobility_user', JSON.stringify(res.user));
    }
    return res;
  };

  const register = async (userData) => {
    const res = await apiRequest('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    });

    if (res.success && res.token) {
      setToken(res.token);
      setUser(res.user);
      localStorage.setItem('campus_mobility_token', res.token);
      localStorage.setItem('campus_mobility_user', JSON.stringify(res.user));
    }
    return res;
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('campus_mobility_token');
    localStorage.removeItem('campus_mobility_user');
  };

  const refreshUser = async () => {
    if (token) {
      const res = await apiRequest('/auth/me');
      if (res.success && res.user) {
        setUser(res.user);
        localStorage.setItem('campus_mobility_user', JSON.stringify(res.user));
      }
    }
  };

  const updateUser = (updatedFields) => {
    setUser(prev => {
      const nextUser = { ...(prev || {}), ...updatedFields };
      localStorage.setItem('campus_mobility_user', JSON.stringify(nextUser));
      return nextUser;
    });
  };

  return (
    <AuthContext.Provider value={{
      user,
      token,
      loading,
      isAuthenticated: !!user,
      isAdmin: user?.role === 'ADMIN',
      isOwner: user?.role === 'OWNER',
      isStaff: user?.role === 'STAFF',
      isStudent: user?.role === 'STUDENT' || !user,
      login,
      register,
      logout,
      refreshUser,
      updateUser
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
