import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { apiRequest } from '../api/client';
import { useAuth } from './AuthContext';

const BookingContext = createContext(null);

export function BookingProvider({ children }) {
  const { isAuthenticated } = useAuth();
  const [activeBooking, setActiveBooking] = useState(null);
  const [zones, setZones] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchActiveBooking = useCallback(async () => {
    if (!isAuthenticated) return;
    const res = await apiRequest('/bookings/active');
    if (res.success) {
      setActiveBooking(res.booking);
    }
  }, [isAuthenticated]);

  const fetchZones = useCallback(async () => {
    const res = await apiRequest('/zones/');
    if (res.success && res.zones) {
      setZones(res.zones);
    }
  }, []);

  const fetchVehicles = useCallback(async (filters = {}) => {
    setLoading(true);
    const query = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '' && v !== 'ALL') {
        query.append(k, v);
      }
    });
    const res = await apiRequest(`/vehicles/?${query.toString()}`);
    if (res.success && res.vehicles) {
      setVehicles(res.vehicles);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchZones();
    if (isAuthenticated) {
      fetchActiveBooking();
    }
  }, [isAuthenticated, fetchZones, fetchActiveBooking]);

  const startRental = async (bookingId, qrToken = '') => {
    const res = await apiRequest(`/bookings/${bookingId}/start`, {
      method: 'POST',
      body: JSON.stringify({ qr_token: qrToken })
    });
    if (res.success) {
      await fetchActiveBooking();
      await fetchVehicles();
    }
    return res;
  };

  const returnRental = async (bookingId, returnData) => {
    const res = await apiRequest(`/bookings/${bookingId}/return`, {
      method: 'POST',
      body: JSON.stringify(returnData)
    });
    if (res.success) {
      setActiveBooking(null);
      await fetchVehicles();
    }
    return res;
  };

  const cancelBooking = async (bookingId) => {
    const res = await apiRequest(`/bookings/${bookingId}/cancel`, {
      method: 'POST'
    });
    if (res.success) {
      await fetchActiveBooking();
      await fetchVehicles();
    }
    return res;
  };

  return (
    <BookingContext.Provider value={{
      activeBooking,
      zones,
      vehicles,
      loading,
      fetchActiveBooking,
      fetchZones,
      fetchVehicles,
      startRental,
      returnRental,
      cancelBooking
    }}>
      {children}
    </BookingContext.Provider>
  );
}

export const useBooking = () => useContext(BookingContext);
